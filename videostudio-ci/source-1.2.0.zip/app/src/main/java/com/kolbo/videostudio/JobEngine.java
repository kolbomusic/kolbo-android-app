package com.kolbo.videostudio;
import android.content.Context;import org.json.*;import java.io.*;import java.lang.ref.WeakReference;import java.util.concurrent.*;
public class JobEngine{
 public interface Sink{void event(JSONObject event);}
 private static JobEngine instance;private final JobStore store;private final SecretStore secrets;private final File imageDirectory,renderDirectory;private String activeImage;
 private final ExecutorService worker=Executors.newSingleThreadExecutor();private final JobPolicy.Gate gate=new JobPolicy.Gate();
 private CloudClient client=new CloudClient();private WeakReference<Sink> sink=new WeakReference<Sink>(null);
 private JobEngine(Context c){Context app=c.getApplicationContext();store=new JobStore(app);secrets=new SecretStore(app);imageDirectory=app.getFilesDir();renderDirectory=new File(app.getFilesDir(),"renders");renderDirectory.mkdirs();store.removeLegacyDemo(app);}
 public synchronized void selectImage(JSONObject image){store.image(image);ImageFiles.retain(imageDirectory,image.optString("file"),activeImage);}
 private synchronized void releaseImage(){activeImage=null;JSONObject image=store.image();ImageFiles.retain(imageDirectory,image==null?null:image.optString("file"),null);}
 public static synchronized JobEngine get(Context c){if(instance==null)instance=new JobEngine(c);return instance;}
 public synchronized void attach(Sink value){sink=new WeakReference<Sink>(value);}
 public synchronized void detach(Sink value){if(sink.get()==value)sink.clear();}
 public void event(JSONObject data){Sink s;synchronized(this){s=sink.get();}if(s!=null)s.event(data);}
 public JobStore store(){return store;}public SecretStore secrets(){return secrets;}public CloudClient client(){return client;}
 private void changed(Json.Obj job){store.put(job);event(new Json.Obj().put("type","job").put("job",job));}
 public JSONObject connections(){return new Json.Obj().put("ltx",!secrets.load("ltx").isEmpty()).put("agnes",!secrets.load("agnes").isEmpty());}
 public void bootstrap(){
  event(new Json.Obj().put("type","snapshot").put("jobs",store.jobs()).put("connections",connections()).put("image",JobStore.publicImage(store.image())));
  if(gate.busy())return;JSONArray list=store.jobs();for(int i=0;i<list.length();i++){Json.Obj j=Json.object(list.optJSONObject(i));if(j==null)continue;String action=JobPolicy.restoreAction(j);if("resume".equals(action)){resume(j.optString("id"));break;}if("interrupted".equals(action)){j.put("phase","error").put("error","Connection interrupted before an event ID was confirmed. No new task was submitted.");changed(j);}}
 }
 public synchronized boolean create(final JSONObject draft){
  final boolean textOnly="text".equals(draft.optString("mode"));final boolean director=!textOnly&&draft.optBoolean("director");final JSONObject image=textOnly?null:store.image();
  final String id=draft.optString("id"),provider=draft.optString("provider"),story=draft.optString("story"),preset=draft.optString("preset","story");final boolean soundtrack=draft.optBoolean("soundtrack",true);int seconds=draft.optInt("duration");
  if((image==null&&!textOnly)||!id.matches("[A-Za-z0-9_-]{4,80}")||store.find(id)!=null||!JobPolicy.availableProvider(provider)||seconds!=3&&seconds!=6&&seconds!=8||story.length()>2500)return false;
  final Json.Obj job=new Json.Obj().put("id",id).put("provider",provider).put("mode",textOnly?"text":"image").put("director",director).put("phase",StoryPlanner.hasHebrew(story)?"planning":director?"directing":textOnly?"waiting":"uploading").put("createdAt",System.currentTimeMillis()).put("story",story).put("duration",seconds).put("preset",preset).put("soundtrack",soundtrack);
  if(!gate.beginPrepared(id,new Runnable(){public void run(){changed(job);}}))return false;activeImage=image==null?null:image.optString("file");
  worker.execute(new Runnable(){public void run(){final String token=secrets.load(provider);File staged=null;try{
    String english=story;
    if(StoryPlanner.hasHebrew(story)){job.put("phase","planning").put("message","מתרגמים את ההנחיה מעברית לאנגלית כדי שמנועי הווידאו יבינו את סדר הפעולות");changed(job);try{english=client.translateToEnglish(story);job.put("translated",true);}catch(Exception translateError){job.put("translationFallback",true).put("translationError",CloudClient.safeError(translateError.getMessage(),null));english=story;}}
    String timeline=StoryPlanner.timeline(english,draft.optInt("duration"));job.put("translatedStory",english).put("timeline",timeline);
    File source=image==null?null:new File(image.optString("file"));String sourceMime=image==null?null:image.optString("mime","image/png");String renderPrompt=(director?SmartDirector.videoPrompt(preset,english,draft.optInt("duration")):Prompts.build(preset,english,false,textOnly))+" "+timeline;
    String fallbackPrompt=director?SmartDirector.fallbackVideoPrompt(preset,english,draft.optInt("duration"))+" "+timeline:renderPrompt;
    if(director){job.put("phase","directing").put("message","במאי חכם מכין סצנת פתיחה שתאפשר לבצע את כל הפעולות");changed(job);staged=new File(imageDirectory,"director-"+id+".png");try{sourceMime=client.stageImage(source,sourceMime,SmartDirector.stagePrompt(english),staged,new CloudClient.Listener(){public void created(String event,String endpoint){}public void progress(String message){job.put("phase","directing").put("message",message);changed(job);}});source=staged;job.put("phase","uploading").put("message","הסצנה מוכנה. שולחים אותה להנפשה לפי ציר הזמן");changed(job);}catch(Exception stageError){if(staged.exists())staged.delete();staged=null;renderPrompt=fallbackPrompt;job.put("directorFallback",true).put("phase","uploading").put("message","שירות הבמאי עמוס. ממשיכים אוטומטית עם תמונת המקור ופרומפט מחמיר");changed(job);}}
    String url=client.create(provider,source,sourceMime,renderPrompt,draft.optInt("duration"),draft.optInt("canvasW",image==null?768:image.optInt("width")),draft.optInt("canvasH",image==null?512:image.optInt("height")),token,videoListener(job));job.put("videoFallback",CloudClient.isWanVideo(url));finishVideo(job,url,english,timeline,soundtrack,draft.optInt("duration"));
   }catch(Exception e){failure(job,e,token);}finally{if(staged!=null)staged.delete();releaseImage();gate.finish(id);changed(job);}
  }});return true;
 }
 private void finishVideo(Json.Obj job,String visualUrl,String english,String timeline,boolean soundtrack,int seconds)throws IOException{
  String id=job.optString("id");File raw=new File(renderDirectory,id+"-visual.mp4"),finalFile=new File(renderDirectory,id+".mp4");raw.delete();finalFile.delete();job.put("phase","caching").put("message","מורידים את הסרטון לטלפון לתצוגה מקדימה יציבה").put("visualUrl",visualUrl).put("visualFile",raw.getAbsolutePath());changed(job);client.download(visualUrl,"ltx",raw);if(!MediaFiles.hasVideo(raw))throw new IOException("Downloaded render has no video track");
  String finalUrl=visualUrl;boolean audioOk=false;
  if(soundtrack){job.put("phase","audio").put("message","מייצרים סאונד AI מסונכרן למה שקורה על המסך");changed(job);try{String audioUrl=client.addSound(raw,StoryPlanner.audioPrompt(english,timeline),seconds,audioListener(job));client.download(audioUrl,"mmaudio",finalFile);if(!MediaFiles.hasVideo(finalFile)||!MediaFiles.hasAudio(finalFile))throw new IOException("MMAudio output did not contain both video and audio");finalUrl=audioUrl;audioOk=true;job.remove("audioError");}catch(Exception audioError){copy(raw,finalFile);job.put("audioFailed",true).put("audioError",CloudClient.safeError(audioError.getMessage(),null));}}
  else copy(raw,finalFile);
  raw.delete();job.remove("visualFile");job.put("phase","done").put("url",finalUrl).put("localFile",finalFile.getAbsolutePath()).put("audio",audioOk).put("message",audioOk?"הסרטון והסאונד מוכנים לצפייה":"הסרטון מוכן; שירות הסאונד לא השלים ולכן נשמרה גם גרסת הווידאו ללא סאונד").remove("error");
 }
 private static void copy(File from,File to)throws IOException{try(InputStream in=new FileInputStream(from);OutputStream out=new FileOutputStream(to)){byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1)out.write(b,0,n);out.flush();}}
 private CloudClient.Listener videoListener(final Json.Obj job){return new CloudClient.Listener(){public void created(String id,String endpoint){job.put("eventId",id).put("eventEndpoint",endpoint).put("phase","waiting");changed(job);}public void progress(String message){job.put("phase","rendering").put("message",message);changed(job);}};}
 private CloudClient.Listener audioListener(final Json.Obj job){return new CloudClient.Listener(){public void created(String id,String endpoint){job.put("eventId",id).put("eventEndpoint",endpoint).put("phase","audio");changed(job);}public void progress(String message){job.put("phase","audio").put("message",message);changed(job);}};}
 private static void failure(Json.Obj job,Exception e,String token){String message=CloudClient.safeError(e.getMessage(),token);boolean interrupted=JobPolicy.recoverable(e)&&CloudClient.validEventId(job.optString("eventId"));job.put("phase",interrupted?"interrupted":"error").put("error",message).put("errorKind",interrupted?"network":"provider");job.remove("url");}
 public boolean resume(final String id){
  final Json.Obj job=Json.object(store.find(id));if(job==null||!CloudClient.validEventId(job.optString("eventId"))||"done".equals(job.optString("phase"))||"error".equals(job.optString("phase")))return false;if(!gate.beginPrepared(id,new Runnable(){public void run(){job.put("phase","waiting");changed(job);}}))return false;
  worker.execute(new Runnable(){public void run(){String token=secrets.load(job.optString("provider"));try{String endpoint=job.optString("eventEndpoint","generate_video"),url=client.resume(job.optString("provider"),job.optString("eventId"),endpoint,token,"mmaudio_video_to_audio".equals(endpoint)?audioListener(job):videoListener(job));if("mmaudio_video_to_audio".equals(endpoint)){File finalFile=new File(renderDirectory,id+".mp4"),raw=new File(job.optString("visualFile"));client.download(url,"mmaudio",finalFile);if(!MediaFiles.hasAudio(finalFile))throw new IOException("Resumed audio output has no audio track");if(raw.isFile())raw.delete();job.remove("visualFile");job.put("phase","done").put("url",url).put("localFile",finalFile.getAbsolutePath()).put("audio",true);job.remove("error");}else finishVideo(job,url,job.optString("translatedStory",job.optString("story")),job.optString("timeline"),job.optBoolean("soundtrack",true),job.optInt("duration",6));}catch(Exception e){failure(job,e,token);}finally{gate.finish(id);changed(job);}}});return true;
 }
}
