package com.kolbo.videostudio;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import javax.net.ssl.HttpsURLConnection;
import org.json.*;

public class CloudClient {
    /** Primary video provider. Verified live for text-to-video and image-to-video. */
    public static final String LTX="https://lightricks-ltx-video-distilled.hf.space";
    /** Identity-preserving scene staging used only by Smart Director. */
    public static final String QWEN="https://kulkas2pintu-qwen-edit-image.hf.space";
    /** Verified image-to-video fallback. No user token is sent to this provider. */
    public static final String WAN="https://zerogpu-aoti-wan2-2-fp8da-aoti-faster.hf.space";
    /** Video-to-audio model. Receives only the rendered MP4 and an English sound brief. */
    public static final String MMAUDIO="https://hkchengrex-mmaudio.hf.space";
    /** Lightweight translation endpoint used only when the story contains Hebrew. */
    public static final String TRANSLATE="https://translate.googleapis.com";
    /** Kept only so old saved video links / legacy events remain recognized. */
    public static final String LTX23="https://lightricks-ltx-2-3.hf.space";
    public static final int MAX_IMAGE=12*1024*1024;
    public static final long MAX_VIDEO=80L*1024*1024;
    public interface Listener {void created(String id,String endpoint);void progress(String message);}
    public interface Transport {Reply request(String method,String url,String contentType,byte[] body,String token)throws IOException;}
    public static class Reply implements Closeable {
        public final int status;public final String type;public final InputStream body;
        private final HttpsURLConnection connection;
        public Reply(int status,String type,InputStream body){this(status,type,body,null);}
        public Reply(int status,String type,InputStream body,HttpsURLConnection c){this.status=status;this.type=type==null?"":type;this.body=body;this.connection=c;}
        public void close()throws IOException{try{if(body!=null)body.close();}finally{if(connection!=null)connection.disconnect();}}
    }
    public static class HttpTransport implements Transport {
        public Reply request(String method,String value,String contentType,byte[] bytes,String token)throws IOException{
            URI uri;try{uri=URI.create(value);}catch(Exception e){throw new IOException("Invalid service URL");}
            if(!trustedApi(uri))throw new IOException("Untrusted service URL");
            HttpsURLConnection c=(HttpsURLConnection)uri.toURL().openConnection();
            c.setConnectTimeout(30000);c.setReadTimeout(240000);c.setInstanceFollowRedirects(false);
            c.setRequestMethod(method);c.setRequestProperty("Accept","application/json, text/event-stream, video/mp4, image/png, image/jpeg, image/webp");
            c.setRequestProperty("User-Agent","Kolbo-Video-Studio/1.2.0");
            if(token!=null&&!token.isEmpty())c.setRequestProperty("Authorization","Bearer "+token);
            if(bytes!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type",contentType);c.setFixedLengthStreamingMode(bytes.length);try(OutputStream out=c.getOutputStream()){out.write(bytes);}}
            int status=c.getResponseCode();InputStream input=status<400?c.getInputStream():c.getErrorStream();if(input==null)input=new ByteArrayInputStream(new byte[0]);
            return new Reply(status,c.getContentType(),input,c);
        }
    }
    private final Transport transport;
    public CloudClient(){this(new HttpTransport());}
    public CloudClient(Transport transport){this.transport=transport;}
    public static boolean trustedApi(URI u){
        if(!"https".equalsIgnoreCase(u.getScheme())||u.getUserInfo()!=null||u.getPort()!=-1&&u.getPort()!=443)return false;
        String h=u.getHost();return "lightricks-ltx-video-distilled.hf.space".equals(h)||"lightricks-ltx-2-3.hf.space".equals(h)||"kulkas2pintu-qwen-edit-image.hf.space".equals(h)||"zerogpu-aoti-wan2-2-fp8da-aoti-faster.hf.space".equals(h)||"hkchengrex-mmaudio.hf.space".equals(h)||"translate.googleapis.com".equals(h);
    }
    public static boolean trustedVideo(String value,String provider){
        try{URI u=URI.create(value);if(!trustedApi(u)||!("ltx".equals(provider)||"mmaudio".equals(provider)||"output".equals(provider)))return false;String h=u.getHost();return "lightricks-ltx-video-distilled.hf.space".equals(h)||"lightricks-ltx-2-3.hf.space".equals(h)||"zerogpu-aoti-wan2-2-fp8da-aoti-faster.hf.space".equals(h)||"hkchengrex-mmaudio.hf.space".equals(h);}catch(Exception e){return false;}
    }
    public static boolean trustedImage(String value){
        try{URI u=URI.create(value);return trustedApi(u)&&"kulkas2pintu-qwen-edit-image.hf.space".equals(u.getHost())&&u.getPath()!=null&&u.getPath().startsWith("/gradio_api/file=");}catch(Exception e){return false;}
    }
    public static boolean validEventId(String id){return id!=null&&id.matches("[A-Za-z0-9_-]{1,120}");}
    public static boolean validEndpoint(String endpoint){return "image_to_video".equals(endpoint)||"text_to_video".equals(endpoint)||"generate_video".equals(endpoint)||"wan_generate_video".equals(endpoint)||"mmaudio_video_to_audio".equals(endpoint);}
    private static void validate(String prompt,int duration){if(prompt==null||prompt.trim().length()<5||prompt.length()>7000)throw new IllegalArgumentException("Invalid prompt");if(duration!=3&&duration!=6&&duration!=8)throw new IllegalArgumentException("Invalid duration");}
    private static int[] canvas(int width,int height){if(width<=0||height<=0)throw new IllegalArgumentException("Invalid canvas");if(height>width*1.2)return new int[]{512,768};if(width>height*1.2)return new int[]{768,512};return new int[]{768,768};}
    /** LTX Video Fast public API payload (13 inputs). path=null selects text-to-video. */
    public static JSONObject ltxPayload(String path,String mime,String prompt,int duration,int width,int height){
        validate(prompt,duration);if(path!=null&&!path.startsWith("/"))throw new IllegalArgumentException("Invalid uploaded image");
        int[] size=canvas(width,height);Object image=path==null?JSONObject.NULL:new Json.Obj().put("path",path).put("orig_name","input").put("mime_type",mime==null?"image/png":mime).put("meta",new Json.Obj().put("_type","gradio.FileData"));
        String negative="worst quality, inconsistent motion, blurry, jittery, distorted, still image, slideshow, duplicated objects, duplicated limbs";
        String mode=path==null?"text-to-video":"image-to-video";
        JSONArray data=new JSONArray();try{data.put(prompt).put(negative).put(image).put(JSONObject.NULL).put(size[1]).put(size[0]).put(mode).put(duration).put(9).put(42).put(false).put(3.0).put(false);}catch(JSONException e){throw new IllegalArgumentException("Invalid LTX payload",e);}
        return new Json.Obj().put("data",data);
    }
    /** Wan2.2 Fast fallback payload. The live endpoint was verified to return MP4. */
    public static JSONObject wanPayload(String path,String mime,String prompt){
        if(path==null||!path.startsWith("/")||prompt==null||prompt.trim().length()<5||prompt.length()>7000)throw new IllegalArgumentException("Invalid Wan payload");
        Object image=new Json.Obj().put("path",path).put("orig_name","input").put("mime_type",mime==null?"image/png":mime).put("meta",new Json.Obj().put("_type","gradio.FileData"));
        String negative="static image, still frame, jitter, drift in place, sway, blurry, distorted subject, duplicated subject, low quality";
        JSONArray data=new JSONArray();try{data.put(image).put(prompt).put(6).put(negative).put(3.5).put(1).put(1).put(42).put(false);}catch(JSONException e){throw new IllegalArgumentException("Invalid Wan payload",e);}
        return new Json.Obj().put("data",data);
    }
    /** Qwen Edit public API payload verified against the live /edit endpoint. */
    public static JSONObject directorPayload(String path,String mime,String prompt){return directorPayload(path,mime,prompt,75,768);}
    public static JSONObject directorPayload(String path,String mime,String prompt,int identityStrength,int outputSize){
        if(path==null||!path.startsWith("/")||prompt==null||prompt.trim().length()<5||prompt.length()>7000)throw new IllegalArgumentException("Invalid director payload");
        if(identityStrength<40||identityStrength>90||outputSize<512||outputSize>1280)throw new IllegalArgumentException("Invalid director tuning");
        Object image=new Json.Obj().put("path",path).put("orig_name","input").put("mime_type",mime==null?"image/png":mime).put("meta",new Json.Obj().put("_type","gradio.FileData"));
        JSONArray data=new JSONArray();try{data.put(image).put(prompt).put("").put(JSONObject.NULL).put(42).put(false).put(1.0).put(4).put(true).put(identityStrength).put(outputSize).put(false).put(false);}catch(JSONException e){throw new IllegalArgumentException("Invalid director payload",e);}
        return new Json.Obj().put("data",data);
    }
    /** Backward-compatible helper used by older tests/callers. */
    public static JSONObject ltxPayload(String path,String prompt,int duration,int width,int height){return ltxPayload(path,"image/png",prompt,duration,width,height);}
    public static JSONObject audioPayload(String path,String prompt,int duration){
        if(path==null||!path.startsWith("/")||prompt==null||prompt.trim().length()<5||prompt.length()>7000)throw new IllegalArgumentException("Invalid audio payload");
        Object video=new Json.Obj().put("path",path).put("orig_name","input.mp4").put("mime_type","video/mp4").put("meta",new Json.Obj().put("_type","gradio.FileData"));
        JSONArray data=new JSONArray();try{data.put(video).put(prompt).put("music, speech, narration, singing, unrelated sound effects").put(0).put(20).put(4.5).put(Math.max(3,Math.min(8,duration)));}catch(JSONException e){throw new IllegalArgumentException("Invalid audio payload",e);}
        return new Json.Obj().put("data",data);
    }
    public String translateToEnglish(String text)throws IOException{
        String source=text==null?"":text.trim();if(source.isEmpty()||!StoryPlanner.hasHebrew(source))return source;
        String url=TRANSLATE+"/translate_a/single?client=gtx&sl=he&tl=en&dt=t&q="+URLEncoder.encode(source,"UTF-8");
        String raw=jsonRequest("GET",url,null,null,null);
        try{
            JSONArray root=new JSONArray(raw),pieces=root.optJSONArray(0);StringBuilder out=new StringBuilder();
            if(pieces!=null)for(int i=0;i<pieces.length();i++){JSONArray item=pieces.optJSONArray(i);if(item!=null){String part=item.optString(0,"").trim();if(!part.isEmpty()){if(out.length()>0)out.append(' ');out.append(part);}}}
            String result=out.toString().trim();if(result.length()<3)throw new IOException("Translation returned no text");return result;
        }catch(JSONException e){throw new IOException("Translation response was invalid",e);}
    }
    private String uploadFile(String base,File file,String mime,String token)throws IOException{
        byte[] picture=readBounded(new FileInputStream(file),MAX_IMAGE);String safeMime=(mime==null||!mime.startsWith("image/"))?"image/png":mime;String ext="image/png".equals(safeMime)?".png":"image/webp".equals(safeMime)?".webp":".jpg";
        String boundary="KolboVideo"+UUID.randomUUID().toString().replace("-","");ByteArrayOutputStream form=new ByteArrayOutputStream();
        form.write(("--"+boundary+"\r\nContent-Disposition: form-data; name=\"files\"; filename=\"input"+ext+"\"\r\nContent-Type: "+safeMime+"\r\n\r\n").getBytes(StandardCharsets.UTF_8));
        form.write(picture);form.write(("\r\n--"+boundary+"--\r\n").getBytes(StandardCharsets.UTF_8));
        String uploaded=jsonRequest("POST",base+"/gradio_api/upload","multipart/form-data; boundary="+boundary,form.toByteArray(),token);JSONArray files=Json.array(uploaded);if(files.length()!=1)throw new IOException("Invalid upload result");String path=files.optString(0);if(path==null||!path.startsWith("/"))throw new IOException("Invalid upload result");return path;
    }
    private String uploadVideo(String base,File file)throws IOException{
        byte[] video=readBoundedLong(new FileInputStream(file),MAX_VIDEO);String boundary="KolboVideo"+UUID.randomUUID().toString().replace("-","");ByteArrayOutputStream form=new ByteArrayOutputStream();
        form.write(("--"+boundary+"\r\nContent-Disposition: form-data; name=\"files\"; filename=\"input.mp4\"\r\nContent-Type: video/mp4\r\n\r\n").getBytes(StandardCharsets.UTF_8));
        form.write(video);form.write(("\r\n--"+boundary+"--\r\n").getBytes(StandardCharsets.UTF_8));
        String uploaded=jsonRequest("POST",base+"/gradio_api/upload","multipart/form-data; boundary="+boundary,form.toByteArray(),null);JSONArray files=Json.array(uploaded);if(files.length()!=1)throw new IOException("Invalid video upload result");String path=files.optString(0);if(path==null||!path.startsWith("/"))throw new IOException("Invalid video upload result");return path;
    }
    public String create(String provider,File image,String mime,String prompt,int seconds,int width,int height,String token,Listener listener)throws IOException{
        if(!"ltx".equals(provider))throw new IOException("Invalid provider");
        IOException last=null;
        for(int attempt=0;attempt<2;attempt++){
            try{
                if(listener!=null&&attempt>0)listener.progress("LTX לא השלים את ההפקה. מנסים שוב אוטומטית");
                return createLtxOnce(image,mime,prompt,seconds,width,height,token,listener);
            }catch(IOException e){last=e;if(attempt<1&&transport instanceof HttpTransport)sleepRetry(1400L);}
        }
        if(image!=null){
            if(listener!=null)listener.progress("LTX עדיין לא זמין. עוברים אוטומטית למנוע הגיבוי Wan2.2");
            try{return createWanOnce(image,mime,prompt,listener);}catch(IOException wan){throw new IOException("Both video engines failed. LTX: "+safeError(last==null?null:last.getMessage(),token)+"; Wan2.2: "+safeError(wan.getMessage(),null));}
        }
        throw last==null?new IOException("Video generation failed"):last;
    }
    private String createLtxOnce(File image,String mime,String prompt,int seconds,int width,int height,String token,Listener listener)throws IOException{
        String path=image==null?null:uploadFile(LTX,image,mime,token);String endpoint=path==null?"text_to_video":"image_to_video";
        String result=jsonRequest("POST",LTX+"/gradio_api/call/"+endpoint,"application/json",ltxPayload(path,mime,prompt,seconds,width,height).toString().getBytes(StandardCharsets.UTF_8),token);
        String id=Json.object(result).optString("event_id");if(!validEventId(id))throw new IOException("No generation event ID returned");if(listener!=null)listener.created(id,endpoint);
        return resume("ltx",id,endpoint,token,listener);
    }
    private String createWanOnce(File image,String mime,String prompt,Listener listener)throws IOException{
        String path=uploadFile(WAN,image,mime,null);
        String result=jsonRequest("POST",WAN+"/gradio_api/call/generate_video","application/json",wanPayload(path,mime,prompt).toString().getBytes(StandardCharsets.UTF_8),null);
        String id=Json.object(result).optString("event_id");if(!validEventId(id))throw new IOException("Wan2.2 returned no generation event ID");if(listener!=null)listener.created(id,"wan_generate_video");
        return resume("ltx",id,"wan_generate_video",null,listener);
    }
    private static void sleepRetry(long ms)throws IOException{try{Thread.sleep(ms);}catch(InterruptedException e){Thread.currentThread().interrupt();throw new IOException("Retry interrupted",e);}}
    public static boolean isWanVideo(String value){try{return value!=null&&"zerogpu-aoti-wan2-2-fp8da-aoti-faster.hf.space".equals(URI.create(value).getHost());}catch(Exception e){return false;}}
    public String addSound(File video,String prompt,int duration,Listener listener)throws IOException{
        if(video==null||!video.isFile())throw new IOException("Rendered video is missing before audio generation");
        IOException last=null;
        for(int attempt=0;attempt<2;attempt++){
            try{
                if(listener!=null)listener.progress(attempt==0?"מייצרים סאונד מסונכרן לפעולות":"מנוע הסאונד עמוס. מנסים שוב אוטומטית");
                String path=uploadVideo(MMAUDIO,video);
                String result=jsonRequest("POST",MMAUDIO+"/gradio_api/call/video_to_audio","application/json",audioPayload(path,prompt,duration).toString().getBytes(StandardCharsets.UTF_8),null);
                String id=Json.object(result).optString("event_id");if(!validEventId(id))throw new IOException("MMAudio returned no event ID");if(listener!=null)listener.created(id,"mmaudio_video_to_audio");
                String url;try(Reply response=transport.request("GET",MMAUDIO+"/gradio_api/call/video_to_audio/"+id,null,null,null)){checkStatus(response,null);url=readSse(response.body,listener,"mmaudio");}
                if(!trustedVideo(url,"mmaudio"))throw new IOException("Untrusted audio-video output");verifyVideo(url,"mmaudio");return url;
            }catch(IOException e){last=e;if(attempt<1&&transport instanceof HttpTransport)sleepRetry(1500L);}
        }
        throw new IOException("MMAudio failed after 2 attempts: "+safeError(last==null?null:last.getMessage(),null));
    }
    /** Builds a new starting frame for complex stories. The user's LTX token is never sent to Qwen.
     * Free Spaces can transiently fail, so three bounded attempts are made with progressively lighter output. */
    public String stageImage(File image,String mime,String prompt,File target,Listener listener)throws IOException{
        if(image==null||target==null)throw new IOException("Smart Director requires an image");
        final int[] strengths={75,65,55};final int[] sizes={768,512,512};IOException last=null;
        for(int attempt=0;attempt<3;attempt++){
            try{
                if(listener!=null)listener.progress(attempt==0?"במאי חכם מכין את סביבת הפתיחה":"במאי חכם מנסה שוב אוטומטית ("+(attempt+1)+"/3)");
                String path=uploadFile(QWEN,image,mime,null);
                String result=jsonRequest("POST",QWEN+"/gradio_api/call/edit","application/json",directorPayload(path,mime,prompt,strengths[attempt],sizes[attempt]).toString().getBytes(StandardCharsets.UTF_8),null);
                String id=Json.object(result).optString("event_id");if(!validEventId(id))throw new IOException("Smart Director returned no event ID");
                String url;try(Reply response=transport.request("GET",QWEN+"/gradio_api/call/edit/"+id,null,null,null)){checkStatus(response,null);url=readDirectorSse(response.body,listener);}
                if(!trustedImage(url))throw new IOException("Smart Director returned an untrusted image");return downloadImage(url,target);
            }catch(IOException e){last=e;target.delete();if(attempt<2&&transport instanceof HttpTransport){try{Thread.sleep(1200L*(attempt+1));}catch(InterruptedException interrupted){Thread.currentThread().interrupt();throw new IOException("Smart Director retry interrupted",interrupted);}}}
        }
        throw new IOException("Smart Director staging failed after 3 attempts: "+safeError(last==null?null:last.getMessage(),null));
    }
    public String resume(String provider,String id,String token,Listener listener)throws IOException{return resume(provider,id,"generate_video",token,listener);}
    public String resume(String provider,String id,String endpoint,String token,Listener listener)throws IOException{
        if(!"ltx".equals(provider)||!validEventId(id)||!validEndpoint(endpoint))throw new IOException("Invalid generation task");
        boolean wan="wan_generate_video".equals(endpoint),audio="mmaudio_video_to_audio".equals(endpoint);String base=audio?MMAUDIO:wan?WAN:"generate_video".equals(endpoint)?LTX23:LTX;String apiEndpoint=audio?"video_to_audio":wan?"generate_video":endpoint;String result;String useToken=(wan||audio)?null:token;
        try(Reply response=transport.request("GET",base+"/gradio_api/call/"+apiEndpoint+"/"+id,null,null,useToken)){checkStatus(response,useToken);result=readSse(response.body,listener,audio?"mmaudio":"ltx");}
        String trustProvider=audio?"mmaudio":provider;if(!trustedVideo(result,trustProvider))throw new IOException("Untrusted video output");verifyVideo(result,trustProvider);return result;
    }
    private String jsonRequest(String method,String url,String contentType,byte[] bytes,String token)throws IOException{
        try(Reply reply=transport.request(method,url,contentType,bytes,token)){checkStatus(reply,token);return new String(readBounded(reply.body,1024*1024),StandardCharsets.UTF_8);}
    }
    private static void checkStatus(Reply reply,String token)throws IOException{if(reply.status<200||reply.status>=300)throw new IOException("HTTP "+reply.status+": "+safeError(new String(readBounded(reply.body,65536),StandardCharsets.UTF_8),token));}
    public static String safeError(String raw,String secret){
        String s=raw==null||raw.trim().isEmpty()||"null".equalsIgnoreCase(raw.trim())?"Generation failed":raw;if(secret!=null&&!secret.isEmpty())s=s.replace(secret,"[redacted]");
        s=s.replaceAll("hf_[A-Za-z0-9_-]+","[redacted]").replaceAll("(?i)(bearer\\s+)[A-Za-z0-9._-]+","$1[redacted]");return s.length()>800?s.substring(0,800):s;
    }
    public static String readSse(InputStream input,Listener listener)throws IOException{return readSse(input,listener,"ltx");}
    public static String readSse(InputStream input,Listener listener,String provider)throws IOException{
        BufferedReader reader=new BufferedReader(new InputStreamReader(input,StandardCharsets.UTF_8));String event="",line;StringBuilder data=new StringBuilder();long until=System.currentTimeMillis()+10*60*1000L;
        while(System.currentTimeMillis()<until&&(line=boundedLine(reader))!=null){
            if(line.length()>1024*1024||data.length()>2*1024*1024)throw new IOException("Oversized event");
            if(line.isEmpty()){
                String value=data.toString();if("error".equals(event))throw new IOException(safeError(value,null));
                if("complete".equals(event)){try{String url=findVideo(new JSONTokener(value).nextValue(),provider,0);if(url==null)throw new IOException("No valid video returned");return url;}catch(JSONException e){throw new IOException("Malformed video response");}}
                if(("generating".equals(event)||"heartbeat".equals(event))&&listener!=null)listener.progress("השירות מעבד את הסרטון בענן");event="";data.setLength(0);
            }else if(line.startsWith("event:"))event=line.substring(6).trim();else if(line.startsWith("data:")){if(data.length()>0)data.append('\n');data.append(line.substring(5).trim());}
        }
        throw new IOException("Connection interrupted before video completion");
    }
    public static String readDirectorSse(InputStream input,Listener listener)throws IOException{
        BufferedReader reader=new BufferedReader(new InputStreamReader(input,StandardCharsets.UTF_8));String event="",line;StringBuilder data=new StringBuilder();long until=System.currentTimeMillis()+8*60*1000L;
        while(System.currentTimeMillis()<until&&(line=boundedLine(reader))!=null){
            if(line.length()>1024*1024||data.length()>2*1024*1024)throw new IOException("Oversized director event");
            if(line.isEmpty()){
                String value=data.toString();if("error".equals(event))throw new IOException("Smart Director staging failed: "+safeError(value,null));
                if("complete".equals(event)){try{String url=findImage(new JSONTokener(value).nextValue(),0);if(url==null)throw new IOException("Smart Director returned no image");return url;}catch(JSONException e){throw new IOException("Malformed Smart Director response");}}
                if(("generating".equals(event)||"heartbeat".equals(event))&&listener!=null)listener.progress("במאי חכם בונה פריים פתיחה חדש");event="";data.setLength(0);
            }else if(line.startsWith("event:"))event=line.substring(6).trim();else if(line.startsWith("data:")){if(data.length()>0)data.append('\n');data.append(line.substring(5).trim());}
        }
        throw new IOException("Smart Director connection interrupted");
    }
    private static String boundedLine(Reader reader)throws IOException{StringBuilder line=new StringBuilder();int ch;while((ch=reader.read())!=-1){if(ch=='\n')break;if(line.length()>=65536)throw new IOException("Oversized event line");line.append((char)ch);}if(ch==-1&&line.length()==0)return null;if(line.length()>0&&line.charAt(line.length()-1)=='\r')line.setLength(line.length()-1);return line.toString();}
    public static String findVideo(Object object,String provider,int depth){
        if(depth>10)return null;if(object instanceof JSONObject){JSONObject j=(JSONObject)object;for(String name:new String[]{"url","video_url","output_url"}){String u=j.optString(name,"");if(trustedVideo(u,provider))return u;}Iterator<String> keys=j.keys();while(keys.hasNext()){String found=findVideo(j.opt(keys.next()),provider,depth+1);if(found!=null)return found;}}
        else if(object instanceof JSONArray){JSONArray a=(JSONArray)object;for(int i=0;i<a.length();i++){String found=findVideo(a.opt(i),provider,depth+1);if(found!=null)return found;}}return null;
    }
    public static String findImage(Object object,int depth){
        if(depth>10)return null;if(object instanceof JSONObject){JSONObject j=(JSONObject)object;String u=j.optString("url","");if(trustedImage(u))return u;Iterator<String> keys=j.keys();while(keys.hasNext()){String found=findImage(j.opt(keys.next()),depth+1);if(found!=null)return found;}}
        else if(object instanceof JSONArray){JSONArray a=(JSONArray)object;for(int i=0;i<a.length();i++){String found=findImage(a.opt(i),depth+1);if(found!=null)return found;}}return null;
    }
    public static boolean mp4Header(byte[] bytes){return bytes!=null&&bytes.length>=12&&bytes[4]=='f'&&bytes[5]=='t'&&bytes[6]=='y'&&bytes[7]=='p';}
    public static boolean imageHeader(byte[] b){return b!=null&&((b.length>=8&&(b[0]&255)==137&&b[1]=='P'&&b[2]=='N'&&b[3]=='G')||(b.length>=2&&(b[0]&255)==255&&(b[1]&255)==216)||(b.length>=12&&b[0]=='R'&&b[1]=='I'&&b[2]=='F'&&b[3]=='F'&&b[8]=='W'&&b[9]=='E'&&b[10]=='B'&&b[11]=='P'));}
    private String downloadImage(String url,File target)throws IOException{
        if(!trustedImage(url))throw new IOException("Untrusted Smart Director image URL");try(Reply r=transport.request("GET",url,null,null,null)){checkStatus(r,null);byte[] bytes=readBounded(r.body,MAX_IMAGE);if(bytes.length<1000||!imageHeader(bytes))throw new IOException("Smart Director returned an invalid image");File parent=target.getParentFile();if(parent!=null)parent.mkdirs();try(OutputStream out=new FileOutputStream(target)){out.write(bytes);}if(bytes.length>=8&&(bytes[0]&255)==137)return "image/png";if(bytes.length>=2&&(bytes[0]&255)==255&&(bytes[1]&255)==216)return "image/jpeg";return "image/webp";}catch(IOException e){target.delete();throw e;}
    }
    public void verifyVideo(String url,String provider)throws IOException{
        if(!trustedVideo(url,provider))throw new IOException("Untrusted video URL");try(Reply r=transport.request("GET",url,null,null,null)){checkStatus(r,null);byte[] first=new byte[32];int count=0,n;while(count<first.length&&(n=r.body.read(first,count,first.length-count))>0)count+=n;if(count<12||!mp4Header(first))throw new IOException("Invalid MP4 video");}
    }
    public void download(String url,String provider,File target)throws IOException{
        if(!trustedVideo(url,provider))throw new IOException("Untrusted video URL");try(Reply r=transport.request("GET",url,null,null,null);OutputStream out=new FileOutputStream(target)){checkStatus(r,null);byte[] block=new byte[65536];int n;long total=0;boolean checked=false;while((n=r.body.read(block))!=-1){if(n==0)continue;if(!checked){if(n<12){ByteArrayOutputStream head=new ByteArrayOutputStream();head.write(block,0,n);while(head.size()<12){int more=r.body.read();if(more<0)break;head.write(more);}byte[] b=head.toByteArray();if(!mp4Header(b))throw new IOException("Invalid MP4 video");out.write(b);total+=b.length;checked=true;continue;}if(!mp4Header(block))throw new IOException("Invalid MP4 video");checked=true;}total+=n;if(total>MAX_VIDEO)throw new IOException("Video exceeds download limit");out.write(block,0,n);}if(!checked||total<12)throw new IOException("Empty video");}catch(IOException e){target.delete();throw e;}
    }
    public static byte[] readBounded(InputStream in,int max)throws IOException{try(InputStream input=in;ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[65536];int n,total=0;while((n=input.read(b))!=-1){total+=n;if(total>max)throw new IOException("Input exceeds limit");out.write(b,0,n);}return out.toByteArray();}}
    public static byte[] readBoundedLong(InputStream in,long max)throws IOException{try(InputStream input=in;ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[65536];int n;long total=0;while((n=input.read(b))!=-1){total+=n;if(total>max)throw new IOException("Input exceeds limit");out.write(b,0,n);}return out.toByteArray();}}
}
