package com.kolbo.videostudio;
import java.io.*;
public final class ImageFiles{
 private ImageFiles(){}
 public static void copy(InputStream input,File target,long limit)throws IOException{try(InputStream in=input;OutputStream out=new FileOutputStream(target)){
  if(in==null)throw new IOException("No image input");byte[] block=new byte[65536];long size=0;int n;
  while((n=in.read(block))!=-1){size+=n;if(size>limit)throw new IOException("Image exceeds 12 MB limit");out.write(block,0,n);}
 }catch(IOException e){target.delete();throw e;}}
 public static void converted(File original,File prepared){if(!original.equals(prepared))original.delete();}
 public static void retain(File directory,String selected,String active){File[] files=directory.listFiles();if(files==null)return;
  for(File f:files)if(f.isFile()&&f.getName().startsWith("image-")&&(f.getName().endsWith(".source")||f.getName().endsWith(".jpg"))&&!f.getAbsolutePath().equals(selected)&&!f.getAbsolutePath().equals(active))f.delete();
 }
}
