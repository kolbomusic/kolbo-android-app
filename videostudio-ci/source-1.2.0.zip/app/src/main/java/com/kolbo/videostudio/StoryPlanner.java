package com.kolbo.videostudio;
import java.util.*;

/** Converts a translated story into an explicit time-ordered plan and an audio brief. */
public final class StoryPlanner{
 private StoryPlanner(){}
 public static boolean hasHebrew(String s){if(s==null)return false;for(int i=0;i<s.length();i++){char c=s.charAt(i);if(c>=0x0590&&c<=0x05ff)return true;}return false;}
 private static String clean(String s){return s==null?"":s.trim().replaceAll("\\s+"," ");}
 public static String timeline(String english,int seconds){
  String s=clean(english);if(s.isEmpty())return "";
  String normalized=s.replaceAll("(?i)\\b(after that|afterwards|next|then|finally|and then)\\b","|").replace(';','|');
  String[] rough=normalized.split("\\|");ArrayList<String> parts=new ArrayList<String>();
  for(String p:rough){for(String q:p.split("(?<=[.!?])\\s+")){q=clean(q);if(q.length()>2)parts.add(q);}}
  if(parts.size()<2&&s.contains(",")){parts.clear();for(String q:s.split(",")){q=clean(q);if(q.length()>2)parts.add(q);}}
  if(parts.isEmpty())parts.add(s);while(parts.size()>4){int n=parts.size();parts.set(n-2,parts.get(n-2)+", then "+parts.get(n-1));parts.remove(n-1);}
  StringBuilder out=new StringBuilder("MANDATORY ACTION TIMELINE. Execute every step visibly and in order; do not skip or replace any step. ");
  double slot=((double)seconds)/parts.size();for(int i=0;i<parts.size();i++){double a=i*slot,b=(i==parts.size()-1)?seconds:(i+1)*slot;out.append(String.format(Locale.US,"%.1f-%.1fs: %s. ",a,b,parts.get(i)));}
  out.append("No captions, subtitles, letters, logos or invented on-screen text. Do not merely sway, drift, rotate in place or loop one motion.");return out.toString();
 }
 public static String audioPrompt(String english,String timeline){
  String s=clean(english);String lower=s.toLowerCase(Locale.ROOT);StringBuilder p=new StringBuilder();
  p.append("Create realistic synchronized sound effects and ambience that match the visible actions in the video. Follow the action timing closely. Natural footsteps, doors, clothing movement, object contact and room ambience should occur only when visually appropriate. ");
  if(lower.contains("fart")||lower.contains("flatulence")||lower.contains("passes gas")||lower.contains("gas sound"))p.append("When the requested gas/fart action occurs, include one brief clearly audible realistic-comedic fart sound at that exact moment, followed by natural room ambience. ");
  if(lower.contains("toilet")||lower.contains("bathroom")||lower.contains("restroom"))p.append("Use subtle indoor bathroom/restroom ambience when the scene is there. ");
  p.append("Do not add narration, dialogue, singing or background music unless explicitly requested. Do not add random unrelated sounds. Story: ").append(s).append(". ");
  if(timeline!=null&&!timeline.isEmpty())p.append(timeline);
  return p.toString();
 }
}
