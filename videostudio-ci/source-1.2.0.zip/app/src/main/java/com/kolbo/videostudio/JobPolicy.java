package com.kolbo.videostudio;
import org.json.JSONObject;import java.net.URI;import java.io.File;
public class JobPolicy {
 public static boolean availableProvider(String provider){return "ltx".equals(provider);}
 public static boolean recoverable(Throwable error){
  for(int n=0;error!=null&&n<12;n++,error=error.getCause()){
   if(error instanceof java.net.UnknownHostException||error instanceof java.net.SocketException||error instanceof java.io.EOFException||error instanceof java.io.InterruptedIOException)return true;
   String text=String.valueOf(error.getMessage());if(text.matches("(?is).*(HTTP\\s*(401|402|403|429)|quota|retired|invalid|malformed).*") )return false;
   if(error instanceof java.io.IOException&&text.matches("(?is).*(timeout|timed out|connection|socket|unexpected end of stream|unable to resolve host).*") )return true;
  }return false;
 }
 public static boolean appPage(String url){try{URI u=URI.create(url);return "file".equals(u.getScheme())&&u.getHost()==null&&"/android_asset/index.html".equals(u.getPath())&&u.getQuery()==null;}catch(Exception e){return false;}}
 public static String restoreAction(JSONObject job){String p=job.optString("phase");if(("waiting".equals(p)||"rendering".equals(p)||"audio".equals(p))&&CloudClient.validEventId(job.optString("eventId")))return "resume";if("planning".equals(p)||"directing".equals(p)||"uploading".equals(p)||"waiting".equals(p)||"rendering".equals(p)||"caching".equals(p)||"audio".equals(p))return "interrupted";return "none";}
 public static boolean canSave(JSONObject job){if(job==null||!"done".equals(job.optString("phase")))return false;String local=job.optString("localFile");if(local!=null&&!local.isEmpty()&&new File(local).isFile())return true;return CloudClient.trustedVideo(job.optString("url"),job.optString("provider"));}
 public static class Gate {
  public boolean beginPrepared(String id,Runnable persistence){if(!begin(id))return false;try{persistence.run();return true;}catch(RuntimeException e){finish(id);return false;}}
  private String active;
  public synchronized boolean begin(String id){if(active!=null||id==null||id.isEmpty())return false;active=id;return true;}
  public synchronized void finish(String id){if(id!=null&&id.equals(active))active=null;}
  public synchronized boolean busy(){return active!=null;}
 }
}
