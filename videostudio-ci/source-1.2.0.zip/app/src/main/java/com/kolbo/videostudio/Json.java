package com.kolbo.videostudio;
import org.json.*;import java.util.Iterator;
/** Small bridge for Android's checked JSON API; invalid JSON is rejected. */
public final class Json {
 private Json(){}
 public static final class Obj extends JSONObject{
  @Override public Obj put(String key,Object value){try{super.put(key,value);return this;}catch(JSONException e){throw new IllegalArgumentException("Invalid JSON field",e);}}
  @Override public Obj put(String key,boolean value){return put(key,Boolean.valueOf(value));}
  @Override public Obj put(String key,int value){return put(key,Integer.valueOf(value));}
  @Override public Obj put(String key,long value){return put(key,Long.valueOf(value));}
  @Override public Obj put(String key,double value){return put(key,Double.valueOf(value));}
 }
 public static Obj object(String text){try{return object(new JSONObject(text));}catch(JSONException e){throw new IllegalArgumentException("Malformed JSON",e);}}
 public static Obj object(JSONObject source){if(source==null)return null;if(source instanceof Obj)return (Obj)source;Obj result=new Obj();Iterator<String> keys=source.keys();while(keys.hasNext()){String key=keys.next();result.put(key,source.opt(key));}return result;}
 public static JSONArray array(String text){try{return new JSONArray(text);}catch(JSONException e){throw new IllegalArgumentException("Malformed JSON array",e);}}
}
