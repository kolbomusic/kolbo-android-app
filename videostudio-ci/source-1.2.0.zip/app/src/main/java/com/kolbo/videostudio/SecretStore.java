package com.kolbo.videostudio;
import android.content.Context;import android.content.SharedPreferences;import android.security.keystore.KeyGenParameterSpec;import android.security.keystore.KeyProperties;import android.util.Base64;
import java.nio.charset.StandardCharsets;import java.security.KeyStore;import javax.crypto.Cipher;import javax.crypto.KeyGenerator;import javax.crypto.SecretKey;import javax.crypto.spec.GCMParameterSpec;
public class SecretStore{
 private final SharedPreferences prefs;private static final String ALIAS="KolboVideoStudio.Connections.v1";
 public SecretStore(Context context){prefs=context.getSharedPreferences("encrypted_connections",Context.MODE_PRIVATE);}
 private SecretKey key()throws Exception{
  KeyStore store=KeyStore.getInstance("AndroidKeyStore");store.load(null);
  if(store.containsAlias(ALIAS))return (SecretKey)store.getKey(ALIAS,null);
  KeyGenerator generator=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
  generator.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setRandomizedEncryptionRequired(true).build());return generator.generateKey();
 }
 public synchronized void save(String provider,String value)throws Exception{
  if(!"ltx".equals(provider)&&!"agnes".equals(provider))throw new IllegalArgumentException("Unknown service");
  if(value==null||value.trim().length()<12||value.length()>512||value.contains("\n")||value.contains("\r"))throw new IllegalArgumentException("Invalid connection value");
  Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,key());
  String encoded=Base64.encodeToString(cipher.getIV(),Base64.NO_WRAP)+":"+Base64.encodeToString(cipher.doFinal(value.trim().getBytes(StandardCharsets.UTF_8)),Base64.NO_WRAP);
  if(!prefs.edit().putString(provider,encoded).commit())throw new Exception("Connection could not be saved");
 }
 public synchronized String load(String provider){
  try{String value=prefs.getString(provider,"");if(value.isEmpty())return "";String[] parts=value.split(":",2);if(parts.length!=2)return "";
   Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Base64.decode(parts[0],Base64.NO_WRAP)));
   return new String(cipher.doFinal(Base64.decode(parts[1],Base64.NO_WRAP)),StandardCharsets.UTF_8);
  }catch(Exception e){return "";}
 }
 public synchronized void disconnect(String provider){prefs.edit().remove(provider).apply();}
}
