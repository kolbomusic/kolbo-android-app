package com.kolbo.videostudio;
import android.app.*;import android.os.*;import android.content.*;import android.net.Uri;import android.graphics.*;import android.text.InputType;import android.view.*;import android.widget.*;import android.media.MediaPlayer;
import java.io.*;import java.util.UUID;import java.util.concurrent.*;import java.util.concurrent.atomic.AtomicBoolean;import org.json.*;

/** Native Android UI: no browser engine, external scripts, or on-device AI model. */
public class MainActivity extends Activity implements JobEngine.Sink{
 private static final int PICK_IMAGE=101,SAVE_VIDEO=102;
 private static final ExecutorService FILE_WORKER=Executors.newSingleThreadExecutor();private static final AtomicBoolean SAVE_BUSY=new AtomicBoolean(),IMAGE_BUSY=new AtomicBoolean(),PREVIEW_BUSY=new AtomicBoolean();
 private static volatile String activeSaveId,activeSaveStatus;private String pendingSave,currentJobId;private JobEngine engine;private NativeUi ui;
 @Override public void onCreate(Bundle state){super.onCreate(state);engine=JobEngine.get(this);engine.attach(this);
  getWindow().setStatusBarColor(0xff0f0e18);getWindow().setNavigationBarColor(0xff0f0e18);getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
  ui=new NativeUi(this,new NativeUi.Actions(){
   public void choose(){chooseImage();}
   public void generate(){submit();}public void resume(){if(currentJobId!=null&&!engine.resume(currentJobId))ui.status("הבדיקה לא התחילה","אפשר לנסות שוב בעוד רגע. לא נשלחה משימת יצירה נוספת.",false);}
   public void save(){if(currentJobId!=null)requestSave(currentJobId);}public void connect(){showConnection();}public void disconnect(){engine.secrets().disconnect("ltx");connections();}
   public void website(String provider){openWebsite(provider);}public void history(JSONObject job){showJob(job);ui.show("create");}
  });
  FrameLayout frame=new FrameLayout(this);frame.setBackgroundColor(0xff0f0e18);frame.addView(ui.root,new FrameLayout.LayoutParams(-1,-1));frame.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener(){public WindowInsets onApplyWindowInsets(View v,WindowInsets insets){
   if(Build.VERSION.SDK_INT>=30){Insets i=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.ime());v.setPadding(i.left,i.top,i.right,i.bottom);}
   else v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());return insets;
  }});setContentView(frame);frame.requestApplyInsets();
  if(state!=null){pendingSave=state.getString("pendingSave");currentJobId=state.getString("currentJob");ui.story.setText(state.getString("story",""));ui.setPreset(state.getString("preset","gentle"));ui.duration.setSelection(state.getInt("duration",0));ui.mode.setSelection(state.getInt("mode",0));ui.aspect.setSelection(state.getInt("aspect",0));ui.music.setChecked(state.getBoolean("music",true));ui.director.setChecked(state.getBoolean("director",true));ui.show(state.getString("screen","create"));
   if(pendingSave!=null){activeSaveId=pendingSave;activeSaveStatus="בחר מקום לשמירת הסרטון.";SAVE_BUSY.set(true);}
  }
  engine.bootstrap();if(currentJobId!=null){JSONObject selected=engine.store().find(currentJobId);if(selected!=null)showJob(selected);}if(SAVE_BUSY.get()&&activeSaveId!=null)saveMessage("saveProgress",activeSaveId,activeSaveStatus==null?"שמירת הסרטון מתבצעת…":activeSaveStatus);
 }
 private boolean busy(){JSONArray rows=engine.store().jobs();for(int i=0;i<rows.length();i++){JSONObject j=rows.optJSONObject(i);if(j!=null&&active(j.optString("phase")))return true;}return false;}
 private static boolean active(String phase){return "planning".equals(phase)||"directing".equals(phase)||"uploading".equals(phase)||"waiting".equals(phase)||"rendering".equals(phase)||"caching".equals(phase)||"audio".equals(phase);}
 private void connections(){ui.connection.setText(engine.secrets().load("ltx").isEmpty()?"מסלול ציבורי":"חשבון מחובר");}
 private void submit(){
  if(IMAGE_BUSY.get()){ui.status("מכינים תמונה","המתן לסיום הכנת התמונה שנבחרה לפני יצירת הסרטון.",false);return;}if(busy())return;boolean textOnly=ui.mode.getSelectedItemPosition()==1;JSONObject image=textOnly?null:engine.store().image();if(!textOnly&&image==null){ui.status("חסרה תמונה","בחר תמונה או עבור למצב יצירה מתיאור בלבד.",false);return;}
  String story=ui.story.getText().toString().trim();if(textOnly&&story.length()<12){ui.status("חסר תיאור","במצב יצירה מתיאור יש לכתוב סצנה של לפחות 12 תווים.",false);return;}if(story.length()>2500){ui.status("התיאור ארוך מדי","אפשר עד 2,500 תווים.",false);return;}
  int seconds=ui.duration.getSelectedItemPosition()==0?3:ui.duration.getSelectedItemPosition()==2?8:6;boolean directed=!textOnly&&ui.director.isChecked()&&SmartDirector.isComplex(story);if(directed)seconds=SmartDirector.effectiveDuration(story,seconds);
  int ratio=ui.aspect.getSelectedItemPosition();int w=ratio==1?512:ratio==3?768:ratio==2?768:image==null?768:image.optInt("width",768);
  int h=ratio==1?768:ratio==3?768:ratio==2?512:image==null?512:image.optInt("height",512);
  String id=UUID.randomUUID().toString();currentJobId=id;Json.Obj draft=new Json.Obj().put("id",id).put("provider","ltx").put("mode",textOnly?"text":"image").put("director",directed).put("preset",ui.preset).put("soundtrack",ui.music.isChecked()).put("canvasW",w).put("canvasH",h).put("duration",seconds).put("story",story);
  if(!engine.create(draft)){currentJobId=null;ui.status("המשימה לא נשלחה","בדוק שאין משימה פעילה ושיש תמונה זמינה.",false);ui.busy(busy());}
 }
 private void showJob(JSONObject job){
  currentJobId=job.optString("id");String phase=job.optString("phase");ui.result.setVisibility(View.GONE);ui.video.stopPlayback();ui.video.setTag(null);ui.resume.setVisibility("interrupted".equals(phase)&&CloudClient.validEventId(job.optString("eventId"))?View.VISIBLE:View.GONE);
  if("done".equals(phase)){
   if(JobPolicy.canSave(job)){ui.result.setVisibility(View.VISIBLE);final String id=currentJobId;File local=new File(job.optString("localFile"));if(local.isFile())playLocal(id,local);else preparePreview(id);
    ui.save.setEnabled(!SAVE_BUSY.get());ui.saveStatus.setText(id.equals(activeSaveId)?activeSaveStatus:job.optBoolean("saved")?"הסרטון נשמר לטלפון.":"");String detail;
    if(job.optBoolean("audioFailed"))detail="הווידאו מוכן לצפייה, אבל שירות הסאונד לא השלים לאחר ניסיונות חוזרים ולכן הגרסה הזו ללא סאונד. אפשר ליצור שוב מאוחר יותר.";
    else if(job.optBoolean("audio"))detail="הסרטון הורד לטלפון לתצוגה מקדימה ונוסף לו סאונד AI מסונכרן לפעולות.";
    else detail="הסרטון הורד לטלפון לתצוגה מקדימה מקומית.";
    if(job.optBoolean("translationFallback"))detail+=" תרגום העברית לא היה זמין באותו רגע ולכן נעשה שימוש גם בטקסט המקורי.";
    ui.status("הסרטון מוכן",detail,false);
   }else ui.status("תוצאה לא תקינה","לא נמצא קובץ מקומי תקין או כתובת סרטון מאושרת.",false);
  }else if("error".equals(phase)||"interrupted".equals(phase))ui.status("interrupted".equals(phase)?"החיבור נקטע":"ההפקה נעצרה",Prompts.error(job.optString("error"),job.optString("errorKind")),false);
  else ui.status("planning".equals(phase)?"מבינים את ההנחיה בעברית":"directing".equals(phase)?"במאי חכם מכין את הסצנה":"audio".equals(phase)?"מוסיפים סאונד מסונכרן":"caching".equals(phase)?"מכינים תצוגה מקדימה":"uploading".equals(phase)?"מעלים את התמונה":"יוצרים את הסרטון בענן",job.optString("message","זמן ההמתנה תלוי בתור ובמכסה של השירות החינמי."),true);
  ui.busy(busy());
 }
 private void playLocal(final String id,File file){ui.video.setTag(file.getAbsolutePath());ui.video.setOnPreparedListener(new MediaPlayer.OnPreparedListener(){public void onPrepared(MediaPlayer player){if(id.equals(currentJobId)&&ui!=null&&!isFinishing()){player.setLooping(false);ui.video.start();}}});ui.video.setOnErrorListener(new MediaPlayer.OnErrorListener(){public boolean onError(MediaPlayer player,int what,int extra){if(id.equals(currentJobId)&&!isFinishing())Toast.makeText(MainActivity.this,"התצוגה המקדימה לא הצליחה להפעיל את הקובץ המקומי.",Toast.LENGTH_LONG).show();return true;}});ui.video.setVideoURI(Uri.fromFile(file));}
 private void preparePreview(final String id){if(!PREVIEW_BUSY.compareAndSet(false,true))return;final Context app=getApplicationContext();ui.saveStatus.setText("מכינים תצוגה מקדימה מקומית…");FILE_WORKER.execute(new Runnable(){public void run(){try{Json.Obj job=Json.object(engine.store().find(id));if(job==null||!"done".equals(job.optString("phase")))return;File dir=new File(app.getFilesDir(),"renders");dir.mkdirs();File target=new File(dir,id+".mp4");engine.client().download(job.optString("url"),job.optString("provider"),target);job.put("localFile",target.getAbsolutePath());engine.store().put(job);engine.event(new Json.Obj().put("type","job").put("job",job));}catch(Exception e){runOnUiThread(new Runnable(){public void run(){if(ui!=null&&!isFinishing())ui.saveStatus.setText("לא ניתן להכין תצוגה מקדימה מקומית כרגע.");}});}finally{PREVIEW_BUSY.set(false);}}});}
 @Override public void event(JSONObject data){final JSONObject value=Json.object(data.toString());runOnUiThread(new Runnable(){public void run(){if(ui==null||isFinishing())return;String type=value.optString("type");
  if("snapshot".equals(type)){ui.history(engine.store().jobs());connections();JSONObject image=value.optJSONObject("image");if(image!=null)ui.image(image);JSONArray jobs=engine.store().jobs();for(int i=0;i<jobs.length();i++){JSONObject j=jobs.optJSONObject(i);if(j!=null&&(active(j.optString("phase"))||"interrupted".equals(j.optString("phase")))){showJob(j);break;}}ui.busy(busy());}
  else if("image".equals(type)){JSONObject image=value.optJSONObject("image");if(image!=null)ui.image(image);ui.busy(busy()||IMAGE_BUSY.get());}
  else if("imageError".equals(type)){ui.status("התמונה לא נטענה",value.optString("message"),false);ui.busy(busy()||IMAGE_BUSY.get());}
  else if("job".equals(type)){JSONObject job=value.optJSONObject("job");ui.history(engine.store().jobs());if(job!=null&&(currentJobId==null||currentJobId.equals(job.optString("id"))||active(job.optString("phase"))))showJob(job);else ui.busy(busy());}
  else if("connections".equals(type))connections();
  else if(type.startsWith("save")||"saved".equals(type)){
   String id=value.optString("id");if("saveProgress".equals(type)){ui.save.setEnabled(false);if(id.equals(currentJobId))ui.saveStatus.setText(value.optString("message"));}
   else{ui.save.setEnabled(true);if(id.equals(currentJobId))ui.saveStatus.setText("saved".equals(type)?"הסרטון נשמר לטלפון.":"saveCancelled".equals(type)?"השמירה בוטלה. הסרטון עדיין זמין כאן.":"הסרטון לא נשמר. "+Prompts.error(value.optString("message"),""));ui.history(engine.store().jobs());}
  }
 }});}
 private void message(String type,String text){engine.event(new Json.Obj().put("type",type).put("message",text));}
 private void saveMessage(String type,String id,String text){if("saveProgress".equals(type))activeSaveStatus=text;engine.event(new Json.Obj().put("type",type).put("id",id).put("message",text));}
 private static void endSave(){SAVE_BUSY.set(false);activeSaveId=null;activeSaveStatus=null;}
 @Override protected void onSaveInstanceState(Bundle out){super.onSaveInstanceState(out);out.putString("pendingSave",pendingSave);out.putString("currentJob",currentJobId);out.putString("story",ui.story.getText().toString());out.putString("preset",ui.preset);out.putInt("duration",ui.duration.getSelectedItemPosition());out.putInt("mode",ui.mode.getSelectedItemPosition());out.putInt("aspect",ui.aspect.getSelectedItemPosition());out.putBoolean("music",ui.music.isChecked());out.putBoolean("director",ui.director.isChecked());out.putString("screen",ui.screen);}
 @Override protected void onDestroy(){engine.detach(this);if(ui!=null){ui.destroy();ui=null;}super.onDestroy();}
 @Override public void onBackPressed(){if(ui!=null&&!"create".equals(ui.screen))ui.show("create");else super.onBackPressed();}
 private void chooseImage(){try{startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*"),PICK_IMAGE);}catch(ActivityNotFoundException e){message("imageError","לא נמצא בורר תמונות בטלפון.");}}
 private void prepareImage(final Uri uri){if(!IMAGE_BUSY.compareAndSet(false,true))return;ui.busy(true);ui.status("מכינים את התמונה","התמונה נבדקת, ללא שינוי של המקור בטלפון.",true);final Context app=getApplicationContext();FILE_WORKER.execute(new Runnable(){public void run(){JSONObject image=null;String error=null;try{image=ImageUtils.importImage(app,uri);engine.selectImage(image);}catch(Exception e){error="בחר PNG, JPEG או WebP תקין, קטן מ־12 MB.";}finally{IMAGE_BUSY.set(false);}if(image!=null)engine.event(new Json.Obj().put("type","image").put("image",JobStore.publicImage(image)));else message("imageError",error);}});}
 private void showConnection(){final EditText input=new EditText(this);input.setSingleLine(true);input.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);input.setHint("hf_…");input.setTextDirection(View.TEXT_DIRECTION_LTR);LinearLayout box=new LinearLayout(this);int p=(int)(24*getResources().getDisplayMetrics().density);box.setPadding(p,0,p,0);box.addView(input);
  new AlertDialog.Builder(this).setTitle("חיבור חשבון Hugging Face").setMessage("הדבק token אישי של החשבון החינמי שלך. הוא נשמר מוצפן בטלפון ונשלח רק לשירות שבחרת. החיבור אינו רוכש מנוי או מכסה.").setView(box).setNegativeButton("ביטול",null).setPositiveButton("שמור חיבור",new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int which){final String value=input.getText().toString().trim();input.setText("");FILE_WORKER.execute(new Runnable(){public void run(){try{if(!value.startsWith("hf_"))throw new IllegalArgumentException();engine.secrets().save("ltx",value);engine.event(new Json.Obj().put("type","connections"));}catch(Exception e){runOnUiThread(new Runnable(){public void run(){if(!isFinishing())Toast.makeText(MainActivity.this,"החיבור לא נשמר. בדוק שזה token תקין של החשבון שלך.",Toast.LENGTH_LONG).show();}});}}});}}).show();
 }
 private void openWebsite(String provider){String url="ltx".equals(provider)?"https://huggingface.co/settings/tokens":"https://agnes-ai.com/en/docs/agnes-video-v20";try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(ActivityNotFoundException e){Toast.makeText(this,"לא נמצא דפדפן לפתיחת החשבון.",Toast.LENGTH_LONG).show();}}
 private void requestSave(final String id){JSONObject job=engine.store().find(id);if(!JobPolicy.canSave(job)){saveMessage("saveError",id,"לא נמצא סרטון מוכן לשמירה.");return;}if(!SAVE_BUSY.compareAndSet(false,true)){saveMessage("saveProgress",activeSaveId,"שמירת סרטון כבר מתבצעת.");return;}pendingSave=id;activeSaveId=id;saveMessage("saveProgress",id,"בחר מקום לשמירת הסרטון.");
  try{startActivityForResult(new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("video/mp4").putExtra(Intent.EXTRA_TITLE,"Kolbo-Video-"+id+".mp4"),SAVE_VIDEO);}catch(ActivityNotFoundException e){pendingSave=null;endSave();saveMessage("saveError",id,"לא נמצא בורר קבצים בטלפון.");}
 }
 @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request==PICK_IMAGE){if(result==RESULT_OK&&data!=null&&data.getData()!=null)prepareImage(data.getData());return;}if(request!=SAVE_VIDEO)return;final String id=pendingSave;pendingSave=null;
  if(result!=RESULT_OK||data==null||data.getData()==null||id==null){endSave();saveMessage("saveCancelled",id,"");return;}final Uri destination=data.getData();final Context app=getApplicationContext();if(!"content".equals(destination.getScheme())){endSave();saveMessage("saveError",id,"בחר מיקום באמצעות בורר הקבצים.");return;}saveMessage("saveProgress",id,"מורידים ושומרים את הסרטון…");
  FILE_WORKER.execute(new Runnable(){public void run(){File cache=null;boolean temporary=false;try{Json.Obj job=Json.object(engine.store().find(id));if(!JobPolicy.canSave(job))throw new IOException("No completed video");cache=new File(job.optString("localFile"));if(!cache.isFile()){cache=File.createTempFile("video-export-",".mp4",app.getCacheDir());temporary=true;engine.client().download(job.optString("url"),job.optString("provider"),cache);}
   try(InputStream in=new FileInputStream(cache);OutputStream out=app.getContentResolver().openOutputStream(destination,"wt")){if(out==null)throw new IOException("No destination");long written=ImageUtils.copy(in,out,CloudClient.MAX_VIDEO);out.flush();if(written!=cache.length())throw new IOException("Incomplete save");}
   job.put("saved",true);engine.store().put(job);engine.event(new Json.Obj().put("type","saved").put("id",id));
  }catch(Exception e){saveMessage("saveError",id,CloudClient.safeError(e.getMessage(),null));}finally{if(temporary&&cache!=null)cache.delete();endSave();}}});
 }
}
