package com.kolbo.videostudio;
import java.util.Locale;
/** Deterministic director for multi-action image-to-video requests. */
public final class SmartDirector{
 private SmartDirector(){}
 private static final String[] SEQUENCE={"ואז","אחר כך","לאחר מכן","לבסוף","בסוף","קודם","then","after that","next","finally","first","second"};
 private static final String[] MOVE={"להיכנס","להכנס","ייכנס","יכנס","נכנס","ללכת","ילך","הולך","לעבור","יעבור","לתוך","יגיע","ייכנסו","enter","walk","go into","move into","cross","arrive"};
 private static final String[] ACTION={"יתיישב","תתיישב","יישב","ישב","יקום","תקום","יעמוד","תעמוד","יקפוץ","תקפוץ","ירוץ","תרוץ","יפתח","תפתח","יסגור","תסגור","ירים","תרים","יוריד","תוריד","יאכל","תאכל","ישתה","תשתה","יחבק","תחבק","יסתובב","תסתובב","יצא","תצא","יניח","תניח","ישכב","תשכב","יתכופף","תתכופף","יתקע","תתקע","יעשה","תעשה","תיכנס","תכנס","sit","stand","jump","run","open","close","pick up","put down","eat","drink","hug","turn","lie down","bend","enter","walk"};
 private static String lower(String s){return s==null?"":s.toLowerCase(Locale.ROOT);}
 private static int hits(String s,String[] words){int n=0;for(String w:words)if(s.contains(w))n++;return n;}
 public static boolean isComplex(String story){
  String s=lower(story);if(s.trim().isEmpty())return false;int score=0;
  int actions=hits(s,ACTION);if(actions>=2)score+=2;else if(actions==1)score++;
  if(hits(s,MOVE)>0)score+=2;if(hits(s,SEQUENCE)>0)score++;if(s.length()>95)score++;
  if(s.indexOf(',')>=0||s.indexOf(';')>=0||s.indexOf('→')>=0)score++;
  return score>=3;
 }
 public static int effectiveDuration(String story,int requested){
  if(!isComplex(story))return requested;int actions=hits(lower(story),ACTION);return Math.max(requested,actions>=3?8:6);
 }
 public static String stagePrompt(String story){
  String user=story==null?"":story.trim();
  return "Preserve the exact same main subject from the reference image: identity, face, hair, clothing, body proportions, colors and distinctive details. " +
   "Create a realistic STARTING FRAME that makes the user's requested sequence physically possible. If the request moves the subject to a new environment, relocate the same subject to the entrance or threshold of that destination and clearly show the important destination objects. " +
   "The user request has already been translated to English when needed. The requested destination MUST already be visibly recognizable in this staged frame and must replace an incompatible original background. " +
   "Do not complete the later actions yet; stage the moment immediately before the sequence begins. Keep a natural full-body composition when actions involve walking, sitting or interacting with objects. Do not add unrelated people or objects. Photorealistic and coherent. " +
   "User instructions: "+user;
 }
 public static String videoPrompt(String preset,String story,int seconds){
  String base=Prompts.build(preset,story,false,false);
  return base+" SMART DIRECTOR: Continue from the staged starting frame and execute EVERY requested action in the exact order given by the user during this "+seconds+"-second shot. " +
   "Show real locomotion, object contact and clear pose changes. If the request changes location, visibly move into that location; do not keep the original environment. " +
   "Do not merely sway, rotate, drift left/right, or loop one small motion in place. Keep the framing wide enough to show the subject and the key objects needed for the actions. " +
   "Use the first part of the shot for the first action or location transition, the middle for the next interaction, and the final part for the remaining/final action and a visible reaction. " +
   "If a requested event is not inherently visible, show an appropriate visible physical reaction rather than silently omitting it. Do not skip requested actions. Do not generate captions, subtitles, letters or invented text on screen.";
 }
 public static String fallbackVideoPrompt(String preset,String story,int seconds){
  String base=Prompts.build(preset,story,false,false);
  return base+" SMART DIRECTOR FALLBACK: The uploaded reference image is an identity and appearance reference, not a requirement to preserve its original background. " +
   "Execute EVERY requested action in the exact order during this "+seconds+"-second shot. If the user requests entering or moving to another room, place, or environment, make that destination and its required objects clearly visible early in the shot even if they were absent from the reference image. " +
   "Use strong, visible locomotion and pose changes; do not merely sway, rotate, drift left/right, or loop a small motion in place. The first part must establish the requested location transition, the middle must perform the next interaction, and the end must visibly complete the final requested action or reaction. " +
   "Preserve the main subject's identity, face, clothing, colors and proportions while allowing the environment to transform as required. Do not skip requested actions. Do not generate captions, subtitles, letters or invented text on screen.";
 }

}
