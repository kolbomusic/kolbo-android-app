package com.kolbo.videostudio;
import android.media.MediaExtractor;import android.media.MediaFormat;import java.io.*;
public final class MediaFiles{
 private MediaFiles(){}
 public static boolean hasAudio(File file){MediaExtractor x=new MediaExtractor();try{x.setDataSource(file.getAbsolutePath());for(int i=0;i<x.getTrackCount();i++){MediaFormat f=x.getTrackFormat(i);String m=f.getString(MediaFormat.KEY_MIME);if(m!=null&&m.startsWith("audio/"))return true;}return false;}catch(Exception e){return false;}finally{x.release();}}
 public static boolean hasVideo(File file){MediaExtractor x=new MediaExtractor();try{x.setDataSource(file.getAbsolutePath());for(int i=0;i<x.getTrackCount();i++){MediaFormat f=x.getTrackFormat(i);String m=f.getString(MediaFormat.KEY_MIME);if(m!=null&&m.startsWith("video/"))return true;}return false;}catch(Exception e){return false;}finally{x.release();}}
}
