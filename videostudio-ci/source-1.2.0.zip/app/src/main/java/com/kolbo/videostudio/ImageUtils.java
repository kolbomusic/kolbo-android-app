package com.kolbo.videostudio;
import android.content.Context;import android.graphics.*;import android.media.ExifInterface;import android.net.Uri;import android.util.Base64;
import java.io.*;import java.util.UUID;import org.json.JSONObject;
public class ImageUtils{
 public static JSONObject importImage(Context c,Uri uri)throws Exception{
  File f=new File(c.getFilesDir(),"image-"+UUID.randomUUID().toString()+".source");
  try{ImageFiles.copy(c.getContentResolver().openInputStream(uri),f,CloudClient.MAX_IMAGE);JSONObject prepared=prepare(c,f,"התמונה שלך");ImageFiles.converted(f,new File(prepared.optString("file")));return prepared;}catch(Exception e){f.delete();throw e;}
 }
 private static JSONObject prepare(Context c,File f,String label)throws Exception{
  File intermediate=null;try{
  BitmapFactory.Options info=new BitmapFactory.Options();info.inJustDecodeBounds=true;BitmapFactory.decodeFile(f.getAbsolutePath(),info);
  if(info.outWidth<1||info.outHeight<1||info.outWidth>30000||info.outHeight>30000)throw new IOException("בחר תמונת PNG, JPEG או WebP תקינה.");
  int orientation=ExifInterface.ORIENTATION_NORMAL;try{orientation=new ExifInterface(f.getAbsolutePath()).getAttributeInt(ExifInterface.TAG_ORIENTATION,ExifInterface.ORIENTATION_NORMAL);}catch(Exception ignored){}
  // Android inserts an undefined (0) orientation for images with no EXIF rotation.
  if(orientation==ExifInterface.ORIENTATION_UNDEFINED)orientation=ExifInterface.ORIENTATION_NORMAL;
  boolean convert=Math.max(info.outWidth,info.outHeight)>1800||orientation!=ExifInterface.ORIENTATION_NORMAL||!("image/png".equals(info.outMimeType)||"image/jpeg".equals(info.outMimeType)||"image/webp".equals(info.outMimeType));
  int width=info.outWidth,height=info.outHeight;String mime=info.outMimeType;
  if(convert){
   BitmapFactory.Options options=new BitmapFactory.Options();options.inSampleSize=1;while(Math.max(width,height)/options.inSampleSize>1800)options.inSampleSize*=2;
   Bitmap bitmap=BitmapFactory.decodeFile(f.getAbsolutePath(),options);if(bitmap==null)throw new IOException("התמונה לא נתמכת.");
   Matrix m=new Matrix();switch(orientation){case ExifInterface.ORIENTATION_ROTATE_90:m.postRotate(90);break;case ExifInterface.ORIENTATION_ROTATE_180:m.postRotate(180);break;case ExifInterface.ORIENTATION_ROTATE_270:m.postRotate(270);break;case ExifInterface.ORIENTATION_FLIP_HORIZONTAL:m.postScale(-1,1);break;case ExifInterface.ORIENTATION_FLIP_VERTICAL:m.postScale(1,-1);break;case ExifInterface.ORIENTATION_TRANSPOSE:m.postRotate(90);m.postScale(-1,1);break;case ExifInterface.ORIENTATION_TRANSVERSE:m.postRotate(270);m.postScale(-1,1);break;}
   Bitmap rotated=Bitmap.createBitmap(bitmap,0,0,bitmap.getWidth(),bitmap.getHeight(),m,true);File resized=new File(c.getFilesDir(),"image-"+UUID.randomUUID().toString()+".jpg");intermediate=resized;
   try(OutputStream out=new FileOutputStream(resized)){if(!rotated.compress(Bitmap.CompressFormat.JPEG,92,out))throw new IOException("לא ניתן להכין את התמונה.");}
   width=rotated.getWidth();height=rotated.getHeight();if(rotated!=bitmap)rotated.recycle();bitmap.recycle();f=resized;mime="image/jpeg";
  }
  BitmapFactory.Options thumbOptions=new BitmapFactory.Options();thumbOptions.inSampleSize=1;while(Math.max(width,height)/thumbOptions.inSampleSize>600)thumbOptions.inSampleSize*=2;
  Bitmap thumb=BitmapFactory.decodeFile(f.getAbsolutePath(),thumbOptions);if(thumb==null)throw new IOException("לא ניתן להציג את התמונה.");
  ByteArrayOutputStream preview=new ByteArrayOutputStream();thumb.compress(Bitmap.CompressFormat.JPEG,86,preview);thumb.recycle();
  return new Json.Obj().put("file",f.getAbsolutePath()).put("path",f.getName()).put("label",label).put("mime",mime).put("width",width).put("height",height).put("preview","data:image/jpeg;base64,"+Base64.encodeToString(preview.toByteArray(),Base64.NO_WRAP));
  }catch(Exception e){if(intermediate!=null)intermediate.delete();throw e;}
 }
 public static long copy(InputStream in,OutputStream out,long max)throws IOException{byte[] block=new byte[65536];long total=0;int n;while((n=in.read(block))!=-1){total+=n;if(total>max)throw new IOException("הקובץ גדול מדי. בחר תמונה קטנה מ־12 MB.");out.write(block,0,n);}return total;}
}
