package com.kolbo.videostudio;
import android.content.Context;import android.content.SharedPreferences;import org.json.*;import java.io.File;
public class JobStore{
 private final SharedPreferences prefs;
 public JobStore(Context c){prefs=c.getSharedPreferences("video_jobs_v1",Context.MODE_PRIVATE);}
 public synchronized JSONArray jobs(){try{return Json.array(prefs.getString("jobs","[]"));}catch(Exception e){return new JSONArray();}}
 public synchronized JSONObject find(String id){JSONArray jobs=jobs();for(int i=0;i<jobs.length();i++){JSONObject j=jobs.optJSONObject(i);if(j!=null&&id.equals(j.optString("id")))return j;}return null;}
 public synchronized void put(JSONObject job){JSONArray old=jobs(),next=new JSONArray();next.put(job);for(int i=0;i<old.length()&&next.length()<30;i++){JSONObject j=old.optJSONObject(i);if(j!=null&&!job.optString("id").equals(j.optString("id")))next.put(j);}if(!prefs.edit().putString("jobs",next.toString()).commit())throw new IllegalStateException("Task state could not be saved");}
 public synchronized JSONObject image(){try{JSONObject j=Json.object(prefs.getString("image","{}"));return new File(j.optString("file")).isFile()?j:null;}catch(Exception e){return null;}}
 public synchronized void image(JSONObject data){if(!prefs.edit().putString("image",data.toString()).commit())throw new IllegalStateException("Image state could not be saved");}
 /** One-time upgrade: drop only the old built-in demonstration, never user photos or unrelated jobs. */
 public synchronized void removeLegacyDemo(Context c){
  if(prefs.getBoolean("demo_removed_v2",false))return;
  JSONObject selected=image();boolean demo=selected!=null&&"bottle-original.png".equals(new File(selected.optString("file")).getName());
  JSONArray original=jobs(),filtered=new JSONArray();
  for(int i=0;i<original.length();i++){
   JSONObject job=original.optJSONObject(i);if(job==null)continue;
   String story=job.optString("story");
   // The legacy sample action inserted this exact prefix.
   if(story.startsWith("יד אנושית נכנסת מימין, מרימה את הבקבוק"))continue;
   filtered.put(job);
  }
  SharedPreferences.Editor e=prefs.edit().putBoolean("demo_removed_v2",true).putString("jobs",filtered.toString());
  if(demo)e.remove("image");
  if(e.commit()){
   File sample=new File(c.getFilesDir(),"bottle-original.png");if(sample.isFile())sample.delete();
  }
 }
 public static JSONObject publicImage(JSONObject value){if(value==null)return null;Json.Obj result=Json.object(value);result.remove("file");return result;}
}
