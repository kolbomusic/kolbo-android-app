import com.android.apksig.*;import java.io.File;
public class VerifyApk{
 public static void main(String[] args)throws Exception{
  ApkVerifier.Result result=new ApkVerifier.Builder(new File(args[0])).setMinCheckedPlatformVersion(26).setMaxCheckedPlatformVersion(35).build().verify();
  if(!result.isVerified()||!result.isVerifiedUsingV2Scheme())throw new IllegalStateException("Invalid release signature: "+result.getErrors());
  System.out.println("Independent signature verification: v2="+result.isVerifiedUsingV2Scheme()+", v3="+result.isVerifiedUsingV3Scheme()+", signers="+result.getSignerCertificates().size());
 }
}
