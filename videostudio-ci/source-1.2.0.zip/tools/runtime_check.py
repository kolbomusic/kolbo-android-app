"""Keep a private AOSP emulator alive for genuine install/runtime checks.

Write build/runtime/control.json with {"id":"unique", "op":"run"} to
install and run, or op:"stop" to stop. No real account or GPU is used.
"""
import json, os, pathlib, subprocess, time, sys, threading, hashlib
ROOT=pathlib.Path(__file__).resolve().parents[1];SDK=ROOT/'toolchain/sdk';OUT=ROOT/os.environ.get('KOLBO_TEST_OUTPUT','build/runtime')
OUT.mkdir(parents=True,exist_ok=True)
env=os.environ.copy();env.update(ANDROID_SDK_ROOT=str(SDK),ANDROID_AVD_HOME=str(ROOT/'toolchain/avd'),LD_LIBRARY_PATH=str(ROOT/'toolchain/native-libs/usr/lib/x86_64-linux-gnu'))
adb=str(SDK/'platform-tools/adb')
def command(args,timeout=30,check=True):return subprocess.run([adb,'-s','emulator-5554',*args],env=env,capture_output=True,text=True,timeout=timeout,check=check)
def instrument():
 args=[adb,'-s','emulator-5554','shell','am','instrument','-w','com.kolbo.videostudio.tests/.SmokeTest']
 p=subprocess.Popen(args,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1)
 lines=[]
 def read():
  with (OUT/'instrumentation-live.txt').open('w') as dest:
   for line in p.stdout:
    lines.append(line);dest.write(line);dest.flush();print(line,end='',flush=True)
 reader=threading.Thread(target=read,daemon=True);reader.start();began=time.monotonic();last=0
 while p.poll() is None:
  elapsed=time.monotonic()-began
  if elapsed>900:
   p.terminate();reader.join(10)
   print('Instrumentation timed out; partial progress preserved',flush=True)
   break
  if elapsed-last>40:
   last=elapsed
   result=command(['logcat','-d','-v','brief','-s','KolboQA:I','AndroidRuntime:E'],45,False)
   (OUT/'qa-live-logcat.txt').write_text(result.stdout)
   print('Android QA elapsed',round(elapsed),'seconds; '+result.stdout[-900:],flush=True)
   if elapsed>120:
    state=command(['shell','dumpsys','activity','top'],45,False);(OUT/'activity-live.txt').write_text(state.stdout)
  time.sleep(.3)
 reader.join(10)
 return subprocess.CompletedProcess(args,p.poll() if p.poll() is not None else -1,''.join(lines),'')
log=(OUT/'emulator.log').open('w');emu=subprocess.Popen([str(SDK/'emulator/emulator'),'-avd',os.environ.get('KOLBO_TEST_AVD','KolboVideoTest'),'-no-metrics','-no-window','-no-audio','-no-snapshot','-accel','off','-gpu','swiftshader','-no-boot-anim','-port','5554'],env=env,stdout=log,stderr=subprocess.STDOUT)
report={'device':os.environ.get('KOLBO_TEST_DEVICE','AOSP Android 15 / API 35 x86_64'),'booted':False,'installed':False}
try:
 start=time.monotonic();last=0
 while time.monotonic()-start<1200:
  if emu.poll() is not None:raise RuntimeError('Emulator exited: '+(OUT/'emulator.log').read_text()[-3000:])
  try:
   r=command(['shell','getprop','sys.boot_completed'],12,False)
   volumes=command(['shell','sm','list-volumes','all'],12,False).stdout
   (OUT/'boot-status.txt').write_text(r.stdout+'\n'+volumes)
   if r.stdout.strip()=='1':command(['shell','input','keyevent','82'],12,False)
   if r.stdout.strip()=='1' and any('emulated' in line and 'mounted' in line.split() for line in volumes.splitlines()):report['booted']=True;break
  except subprocess.TimeoutExpired:pass
  if time.monotonic()-last>25:print('Waiting for Android and mounted storage, elapsed',round(time.monotonic()-start),'seconds',flush=True);last=time.monotonic()
  time.sleep(2)
 if not report['booted']:raise RuntimeError('Test device did not become ready within 20 minutes')
 command(['shell','mkdir','-p','/sdcard/Download']);command(['shell','input','keyevent','82'],check=False)
 for setting in ['window_animation_scale','transition_animation_scale','animator_duration_scale']:command(['shell','settings','put','global',setting,'0'])
 print('Android and external storage ready',flush=True);(OUT/'booted').write_text('ready')
 seen=None;start=time.monotonic()
 while time.monotonic()-start<4*3600:
  try:control=json.loads((OUT/'control.json').read_text())
  except (OSError,ValueError):control={}
  if control.get('op')=='stop':break
  if control.get('id') and control.get('id')!=seen and control.get('op')=='run':
   seen=control['id'];report['run']=seen
   for apk in [ROOT/'build/final/Kolbo-Video-Studio-1.1.4.apk',ROOT/'build/test/Kolbo-Video-Studio-tests.apk']:
    r=command(['install','-r',str(apk)],180)
    if 'Success' not in r.stdout:raise RuntimeError(r.stdout+r.stderr)
    print('Installed',apk.name,flush=True)
   report['installed']=True
   command(['logcat','-c'],check=False)
   report['apk_sha256']=hashlib.sha256((ROOT/'build/final/Kolbo-Video-Studio-1.1.4.apk').read_bytes()).hexdigest();r=instrument()
   (OUT/'instrumentation.txt').write_text(r.stdout+r.stderr);print(r.stdout+r.stderr,flush=True)
   report['instrumentation_exit']=r.returncode;report['instrumentation_passed']='ALL_RUNTIME_CHECKS_PASSED' in r.stdout and 'FAILURE' not in r.stdout
   for remote,local in [('app-screen.png','app-screen.png'),('checks.json','checks.json')]:command(['pull','/sdcard/Android/data/com.kolbo.videostudio/files/qa/'+remote,str(OUT/local)],check=False)
   r=command(['logcat','-d','-v','brief'],60,False);(OUT/'logcat.txt').write_text(r.stdout)
   (OUT/'report.json').write_text(json.dumps(report,indent=2));print('RUNTIME_RESULT',json.dumps(report),flush=True)
  if emu.poll() is not None:raise RuntimeError('Emulator stopped')
  time.sleep(1)
except Exception as e:report['error']=str(e);print('RUNTIME_ERROR',str(e),flush=True)
finally:
 (OUT/'report.json').write_text(json.dumps(report,indent=2))
 try:command(['emu','kill'],check=False)
 except Exception:pass
 emu.terminate();log.close()
