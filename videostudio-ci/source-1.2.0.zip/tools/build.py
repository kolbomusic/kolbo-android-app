"""Build and sign the standalone APK without Gradle or a machine-wide SDK."""
import hashlib, json, os, pathlib, secrets, shutil, struct, subprocess, urllib.request, zipfile, argparse
ROOT=pathlib.Path(__file__).resolve().parents[1]
TC=ROOT/'toolchain';BUILD=ROOT/'build';SIGN=ROOT/'signing'
def run(args):subprocess.run([str(x) for x in args],cwd=ROOT,check=True)
def dependencies():
 TC.mkdir(exist_ok=True)
 lock=json.loads((ROOT/'tools/dependencies.lock.json').read_text())
 for name,item in lock.items():
  path=TC/name
  if not path.is_file():
   with urllib.request.urlopen(item['url'],timeout=120) as source,path.open('wb') as dest:shutil.copyfileobj(source,dest)
  if hashlib.sha256(path.read_bytes()).hexdigest()!=item['sha256']:raise RuntimeError('Dependency checksum mismatch: '+name)
 aapt=TC/'aapt2'
 if not aapt.exists():
  with zipfile.ZipFile(TC/'aapt2.jar') as z:z.extract('aapt2',TC)
 aapt.chmod(0o755)
def signing():
 SIGN.mkdir(mode=0o700,exist_ok=True);SIGN.chmod(0o700)
 password=SIGN/'password.txt';keystore=SIGN/'kolbo-release.p12'
 if not password.exists():password.write_text(secrets.token_urlsafe(32)+'\n');password.chmod(0o600)
 if not keystore.exists():
  run(['keytool','-genkeypair','-alias','kolbo','-keyalg','RSA','-keysize','3072','-validity','10000','-dname','CN=Kolbo Video Studio, O=Private Android App','-keystore',keystore,'-storetype','PKCS12','-storepass:file',password,'-keypass:file',password])
  keystore.chmod(0o600)
 return keystore,password
def align(source,target,dex):
 with zipfile.ZipFile(source) as original,zipfile.ZipFile(target,'w') as aligned:
  for old in original.infolist():
   entry=zipfile.ZipInfo(old.filename,(2026,10,3,0,0,0));entry.compress_type=zipfile.ZIP_STORED if old.filename=='resources.arsc' else old.compress_type
   if entry.compress_type==zipfile.ZIP_STORED:
    padding=(-(aligned.fp.tell()+30+len(entry.filename.encode('utf-8'))))%4
    if padding:entry.extra=struct.pack('<HH',0xd935,padding)+bytes(padding)
   aligned.writestr(entry,original.read(old.filename))
  for file in sorted(dex.glob('*.dex')):
   entry=zipfile.ZipInfo(file.name,(2026,10,3,0,0,0));entry.compress_type=zipfile.ZIP_DEFLATED;aligned.writestr(entry,file.read_bytes())
def build(test=False):
 dependencies();keystore,password=signing()
 name='test' if test else 'release';out=BUILD/name;shutil.rmtree(out,ignore_errors=True);out.mkdir(parents=True)
 java=out/'classes';java.mkdir();dex=out/'dex';dex.mkdir();gen=out/'gen';gen.mkdir()
 base=ROOT/'tests/android' if test else ROOT/'app/src/main'
 linked=out/'resources.apk'
 args=[TC/'aapt2','link','-o',linked,'--manifest',base/'AndroidManifest.xml','-I',TC/'android.jar','--min-sdk-version','26','--target-sdk-version','35','--java',gen,'-A',base/'assets']
 res=base/'res'
 if res.exists():
  run([TC/'aapt2','compile','--dir',res,'-o',out/'resources.zip']);args.append(out/'resources.zip')
 run(args)
 sources=list((base/'java').rglob('*.java'))+list(gen.rglob('*.java'))
 cp=str(TC/'android.jar')+(':'+str(BUILD/'release/classes') if test else '')
 run(['java','-jar',TC/'ecj.jar','-8','-nowarn','-cp',cp,'-d',java,*sources])
 classes=out/'classes.jar'
 with zipfile.ZipFile(classes,'w',zipfile.ZIP_DEFLATED) as z:
  for file in java.rglob('*.class'):z.write(file,file.relative_to(java))
 args=['java','-cp',TC/'r8.jar','com.android.tools.r8.D8','--lib',TC/'android.jar','--min-api','26','--output',dex]
 if test:args+=['--classpath',BUILD/'release/classes.jar']
 run([*args,classes]);unsigned=out/'unsigned.apk';align(linked,unsigned,dex)
 signer=BUILD/'signer';signer.mkdir(exist_ok=True)
 run(['java','-jar',TC/'ecj.jar','-8','-nowarn','-cp',TC/'apksig.jar','-d',signer,ROOT/'tools/SignApk.java'])
 final=(BUILD/'test/Kolbo-Video-Studio-tests.apk') if test else (BUILD/'final/Kolbo-Video-Studio-1.2.0.apk');final.parent.mkdir(exist_ok=True)
 run(['java','-cp',str(signer)+':'+str(TC/'apksig.jar'),'SignApk',unsigned,final,keystore,password])
 print(json.dumps({'apk':str(final),'bytes':final.stat().st_size,'sha256':hashlib.sha256(final.read_bytes()).hexdigest()}))
 if test:(BUILD/'test/READY').write_text('ready')
 return final
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--test',action='store_true');args=parser.parse_args();build(args.test)
