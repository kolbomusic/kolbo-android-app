import com.android.apksig.*;import java.io.*;import java.nio.file.*;import java.security.*;import java.security.cert.X509Certificate;import java.util.*;
public class SignApk{
 public static void main(String[] args)throws Exception{
  char[] password=new String(Files.readAllBytes(Paths.get(args[3])),"UTF-8").trim().toCharArray();
  KeyStore store=KeyStore.getInstance("PKCS12");try(InputStream in=new FileInputStream(args[2])){store.load(in,password);}
  PrivateKey key=(PrivateKey)store.getKey("kolbo",password);X509Certificate cert=(X509Certificate)store.getCertificate("kolbo");
  ApkSigner.SignerConfig config=new ApkSigner.SignerConfig.Builder("kolbo",key,Collections.singletonList(cert)).build();
  new ApkSigner.Builder(Collections.singletonList(config)).setInputApk(new File(args[0])).setOutputApk(new File(args[1])).setMinSdkVersion(26).setV1SigningEnabled(true).setV2SigningEnabled(true).setV3SigningEnabled(true).setV4SigningEnabled(false).build().sign();
  Arrays.fill(password,'\0');ApkVerifier.Result result=new ApkVerifier.Builder(new File(args[1])).setMinCheckedPlatformVersion(26).build().verify();
  if(!result.isVerified())throw new IOException("APK signature rejected: "+result.getErrors());
  System.out.println("APK signature verified: v1="+result.isVerifiedUsingV1Scheme()+" v2="+result.isVerifiedUsingV2Scheme()+" v3="+result.isVerifiedUsingV3Scheme());
 }
}
