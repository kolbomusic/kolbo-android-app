"""Small independent structural gates; not a replacement for Android build/runtime."""
from pathlib import Path
import re, unittest, zipfile
P=Path(__file__).resolve().parents[1]
JAVA=P/'app/src/main/java/com/kolbo/videostudio'
class Gate(unittest.TestCase):
 def test_version(self):
  m=(P/'app/src/main/AndroidManifest.xml').read_text()
  self.assertIn('versionName="1.2.0"',m)
  self.assertIn('versionCode="7"',m)
  self.assertIn('allowBackup="false"',m)
  self.assertIn('usesCleartextTraffic="false"',m)
 def test_decommission_old_sample(self):
  assets=list((P/'app/src/main/assets').rglob('*'))
  self.assertFalse([x for x in assets if x.is_file()])
  ui=(JAVA/'NativeUi.java').read_text()
  self.assertNotIn('R.id.sample',ui)
  self.assertNotIn('הבקבוק שלך',ui)
 def test_text_mode_flow(self):
  ui=(JAVA/'NativeUi.java').read_text()
  main=(JAVA/'MainActivity.java').read_text()
  engine=(JAVA/'JobEngine.java').read_text()
  client=(JAVA/'CloudClient.java').read_text()
  for fragment in ['הנפשת תמונה לסרטון','יצירת סרטון מתיאור בלבד','R.id.mode','R.id.aspect']:
   self.assertIn(fragment,ui)
  self.assertIn('textOnly=ui.mode.getSelectedItemPosition()==1',main)
  self.assertIn('IMAGE_BUSY.get()',main)
  self.assertIn('image==null?null:new File(',engine)
  self.assertIn('activeImage=image==null?null:image.optString("file")',engine)
  self.assertIn('JSONObject image=textOnly?null:engine.store().image()',main)
  self.assertIn('JSONObject.NULL',client)
  self.assertIn('image==null?null:uploadFile(LTX',client)
  self.assertIn('lightricks-ltx-video-distilled.hf.space',client)
  self.assertIn('image_to_video',client)
  self.assertIn('text_to_video',client)
  self.assertIn('zerogpu-aoti-wan2-2-fp8da-aoti-faster.hf.space',client)
  self.assertIn('wan_generate_video',client)
  self.assertIn('createWanOnce',client)
  self.assertIn('hkchengrex-mmaudio.hf.space',client)
  self.assertIn('translate.googleapis.com',client)
  self.assertIn('addSound',client)
  self.assertIn('translateToEnglish',client)

 def test_smart_director_flow(self):
  ui=(JAVA/'NativeUi.java').read_text()
  main=(JAVA/'MainActivity.java').read_text()
  engine=(JAVA/'JobEngine.java').read_text()
  client=(JAVA/'CloudClient.java').read_text()
  director=(JAVA/'SmartDirector.java').read_text()
  self.assertIn('R.id.smart_director',ui)
  self.assertIn('SmartDirector.isComplex(story)',main)
  self.assertIn('SmartDirector.stagePrompt',engine)
  self.assertIn('stageImage',engine)
  self.assertIn('directorFallback',engine)
  self.assertIn('fallbackPrompt',engine)
  self.assertIn('after 3 attempts',client)
  self.assertIn('kulkas2pintu-qwen-edit-image.hf.space',client)
  self.assertIn('preserve',director.lower())
  self.assertIn('Do not merely sway',director)
  self.assertIn('playLocal',main)
  self.assertIn('ui.video.start()',main)
  self.assertIn('localFile',main)
 def test_no_purchases_or_sdk_overreach(self):
  m=(P/'app/src/main/AndroidManifest.xml').read_text()
  perms=re.findall(r'uses-permission android:name="([^"]+)',m)
  self.assertEqual(set(perms),{'android.permission.INTERNET','android.permission.ACCESS_NETWORK_STATE'})
  self.assertTrue((P/'tools/dependencies.lock.json').exists())
  for name in ['README_HE.md','CHANGELOG_HE.md']:
   self.assertTrue((P/name).exists())
 def test_exclude_secrets_and_test_video_from_release(self):
  build=(P/'tools/build.py').read_text()
  self.assertIn("base=ROOT/'tests/android' if test else ROOT/'app/src/main'",build)
  self.assertFalse(list(P.glob('signing/*')))
if __name__=='__main__': unittest.main(verbosity=2)
