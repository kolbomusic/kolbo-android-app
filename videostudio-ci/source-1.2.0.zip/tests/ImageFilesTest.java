import com.kolbo.videostudio.ImageFiles;import java.io.*;import java.nio.file.*;
public class ImageFilesTest{
 static int n;static void ok(boolean value,String name){n++;if(!value)throw new AssertionError(name);}
 public static void main(String[] args)throws Exception{
  File dir=Files.createTempDirectory("kolbo-image-test-").toFile();
  try{
   for(int i=0;i<3;i++){File target=new File(dir,"image-oversize"+i+".source");boolean failed=false;try{ImageFiles.copy(new ByteArrayInputStream(new byte[1025]),target,1024);}catch(IOException e){failed=true;}ok(failed&&!target.exists(),"oversized image never leaves a partial file");}
   File input=new File(dir,"image-original.source"),prepared=new File(dir,"image-prepared.jpg");Files.write(input.toPath(),new byte[]{1});Files.write(prepared.toPath(),new byte[]{2});ImageFiles.converted(input,prepared);ok(!input.exists()&&prepared.exists(),"conversion removes its intermediate source");
   File active=new File(dir,"image-active.source"),old=new File(dir,"image-old.source"),unrelated=new File(dir,"unrelated.txt");Files.write(active.toPath(),new byte[]{3});Files.write(old.toPath(),new byte[]{4});Files.write(unrelated.toPath(),new byte[]{5});
   ImageFiles.retain(dir,prepared.getAbsolutePath(),active.getAbsolutePath());ok(prepared.exists()&&active.exists()&&!old.exists()&&unrelated.exists(),"selection cleanup protects active image and unrelated files");
   ImageFiles.retain(dir,prepared.getAbsolutePath(),null);ok(!active.exists()&&prepared.exists(),"released active image is retired");
   ImageFiles.converted(prepared,prepared);ok(prepared.exists(),"unchanged image is retained");
   System.out.println("ImageFiles checks passed: "+n);
  }finally{for(File f:dir.listFiles())f.delete();dir.delete();}
 }
}
