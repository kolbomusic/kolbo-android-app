package com.kolbo.videostudio.tests;
import android.content.*;import android.net.Uri;import android.os.ParcelFileDescriptor;import android.database.*;import android.provider.OpenableColumns;import android.graphics.*;import java.io.*;
/** Installed only on the isolated emulator; never included in the delivered app. */
public class FixtureProvider extends ContentProvider{
 @Override public boolean onCreate(){try{
  Bitmap b=Bitmap.createBitmap(256,384,Bitmap.Config.ARGB_8888);b.eraseColor(Color.rgb(80,100,120));
  try(OutputStream out=new FileOutputStream(file("input.png"))){b.compress(Bitmap.CompressFormat.PNG,100,out);}b.recycle();return true;
 }catch(Exception e){throw new IllegalStateException(e);}}
 private File file(String name){if(!"input.png".equals(name)&&!"export.mp4".equals(name)&&!"broken.mp4".equals(name)&&!"oversize.png".equals(name)&&!"converted.png".equals(name))throw new IllegalArgumentException("Unknown QA file");return new File(getContext().getFilesDir(),name);}
 @Override public ParcelFileDescriptor openFile(Uri uri,String mode)throws FileNotFoundException{String name=uri.getLastPathSegment();File target=file(name);try{
  if("oversize.png".equals(name)&&!target.exists())try(OutputStream out=new FileOutputStream(target)){byte[] block=new byte[65536];for(int n=0;n<208;n++)out.write(block);}
  if("converted.png".equals(name)&&!target.exists()){Bitmap b=Bitmap.createBitmap(2000,1000,Bitmap.Config.ARGB_8888);b.eraseColor(Color.RED);try(OutputStream out=new FileOutputStream(target)){b.compress(Bitmap.CompressFormat.PNG,100,out);}b.recycle();}
 }catch(IOException e){throw new FileNotFoundException(e.getMessage());}return ParcelFileDescriptor.open(target,ParcelFileDescriptor.parseMode(mode));}
 @Override public String getType(Uri uri){return uri.getLastPathSegment().endsWith("png")?"image/png":"video/mp4";}
 @Override public Cursor query(Uri uri,String[] projection,String selection,String[] args,String order){MatrixCursor c=new MatrixCursor(new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE});File f=file(uri.getLastPathSegment());c.addRow(new Object[]{f.getName(),f.length()});return c;}
 @Override public Uri insert(Uri uri,ContentValues values){throw new UnsupportedOperationException();}
 @Override public int update(Uri uri,ContentValues values,String s,String[] args){throw new UnsupportedOperationException();}
 @Override public int delete(Uri uri,String s,String[] args){throw new UnsupportedOperationException();}
}
