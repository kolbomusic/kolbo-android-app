import com.kolbo.videostudio.SmartDirector;
public class SmartDirectorTest{
 static int n;static void ok(boolean b,String name){n++;if(!b)throw new AssertionError(name);}
 public static void main(String[] args){
  String complex="הדמות תיכנס לחדר, תתיישב על הכיסא ואז תקום ותצא";
  ok(SmartDirector.isComplex(complex),"multi-action location change detected");
  ok(!SmartDirector.isComplex("הדמות מחייכת למצלמה"),"simple portrait motion remains direct");
  ok(SmartDirector.effectiveDuration(complex,3)==8,"three or more actions expand to eight seconds");
  String stage=SmartDirector.stagePrompt(complex);ok(stage.contains("STARTING FRAME")&&stage.contains(complex),"stage prompt preserves user request and stages beginning");
  String video=SmartDirector.videoPrompt("action",complex,8);ok(video.contains("exact order")&&video.contains("Do not merely sway")&&video.contains(complex),"video prompt enforces ordered real actions");
  ok(SmartDirector.effectiveDuration("חתול קופץ",3)==3,"simple motion keeps requested duration");
  String fallback=SmartDirector.fallbackVideoPrompt("action",complex,8);ok(fallback.contains("identity and appearance reference")&&fallback.contains("destination")&&fallback.contains("do not merely sway"),"fallback prompt allows environment replacement and ordered action");
  System.out.println("SmartDirector checks passed: "+n);
 }
}
