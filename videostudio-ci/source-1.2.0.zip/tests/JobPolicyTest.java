import com.kolbo.videostudio.JobPolicy;import org.json.JSONObject;
public class JobPolicyTest{
 static int n;static void ok(boolean b,String name){n++;if(!b)throw new AssertionError(name);}
 public static void main(String[] args){
  ok(JobPolicy.availableProvider("ltx"),"public LTX creation available");ok(!JobPolicy.availableProvider("agnes"),"retired Agnes creation unavailable");
  ok(JobPolicy.recoverable(new java.net.UnknownHostException("Unable to resolve host example: No address associated with hostname")),"DNS error preserves known job recovery");
  ok(JobPolicy.recoverable(new java.io.EOFException("unexpected end of stream")),"EOF preserves known job recovery");
  ok(JobPolicy.recoverable(new IllegalStateException(new java.net.SocketTimeoutException("slow"))),"nested transport cause preserves recovery");
  ok(!JobPolicy.recoverable(new java.io.IOException("HTTP 429: quota exceeded")),"quota remains terminal");
  JobPolicy.Gate failed=new JobPolicy.Gate();ok(!failed.beginPrepared("restore",new Runnable(){public void run(){throw new IllegalStateException("disk full");}}),"failed persistence rejects resume");ok(failed.begin("next"),"failed persistence releases gate");
  JobPolicy.Gate g=new JobPolicy.Gate();ok(g.begin("first"),"first submission starts");ok(!g.begin("second"),"simultaneous submission rejected");g.finish("other");ok(!g.begin("third"),"unrelated completion cannot release the gate");g.finish("first");ok(g.begin("fourth"),"matching completion releases gate");
  ok(JobPolicy.appPage("file:///android_asset/index.html"),"trusted packaged document");
  for(String s:new String[]{"file:///android_asset/index.html.evil","file:///sdcard/index.html","https://huggingface.co/","file://evil/android_asset/index.html"})ok(!JobPolicy.appPage(s),"foreign document cannot keep bridge");
  ok(JobPolicy.restoreAction(new JSONObject().put("phase","waiting").put("eventId","abc")).equals("resume"),"known task resumes");
  ok(JobPolicy.restoreAction(new JSONObject().put("phase","uploading")).equals("interrupted"),"unknown submission cannot be resubmitted automatically");
  ok(JobPolicy.restoreAction(new JSONObject().put("phase","directing")).equals("interrupted"),"director stage is never silently resubmitted after restart");
  ok(JobPolicy.restoreAction(new JSONObject().put("phase","error").put("eventId","abc")).equals("none"),"quota or failed task does not automatically restart");
  ok(JobPolicy.canSave(new JSONObject().put("phase","done").put("provider","ltx").put("url","https://lightricks-ltx-2-3.hf.space/v.mp4")),"completed permitted output may save");
  ok(!JobPolicy.canSave(new JSONObject().put("phase","waiting").put("provider","ltx").put("url","https://lightricks-ltx-2-3.hf.space/v.mp4")),"unfinished output cannot save");
  ok(!JobPolicy.canSave(new JSONObject().put("phase","done").put("provider","ltx").put("url","https://evil.example/v.mp4")),"foreign output cannot save");
  System.out.println("JobPolicy checks passed: "+n);
 }
}
