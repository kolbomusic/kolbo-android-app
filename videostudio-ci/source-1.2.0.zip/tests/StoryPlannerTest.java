import com.kolbo.videostudio.StoryPlanner;
public class StoryPlannerTest{
 private static void ok(boolean v,String m){if(!v)throw new AssertionError(m);}
 public static void main(String[] args){
  ok(StoryPlanner.hasHebrew("הדמות נכנסת לשירותים"),"hebrew detection");
  ok(!StoryPlanner.hasHebrew("the person enters"),"english detection");
  String t=StoryPlanner.timeline("The person enters the bathroom, then sits on the toilet, then passes gas.",8);
  ok(t.contains("0.0-")&&t.contains("sits on the toilet")&&t.contains("passes gas"),"timeline");
  String a=StoryPlanner.audioPrompt("The person enters the bathroom, sits on the toilet and farts.",t);
  ok(a.toLowerCase().contains("fart sound")&&a.toLowerCase().contains("bathroom"),"audio prompt");
  System.out.println("StoryPlanner checks passed: 4");
 }
}
