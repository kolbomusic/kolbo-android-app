import com.kolbo.videostudio.Prompts;
public class PromptsTest{
 static int n;static void ok(boolean value,String name){n++;if(!value)throw new AssertionError(name);}
 public static void main(String[] args){
  String p=Prompts.build("action","החתול קופץ ומסתובב",true,false);
  ok(p.contains("distinct changes in pose"),"real movement required");ok(p.contains("החתול קופץ ומסתובב"),"Hebrew instructions preserved");
  ok(p.contains("coherent visual motion")&&!p.contains("soundtrack"),"prompt does not promise unsupported audio");ok(!p.contains("Persian")&&!p.contains("bottle"),"no retired prompt content");
  ok(Prompts.build("product","",false,false).contains("all readable labels"),"product branding preserved");ok(Prompts.build("portrait","שלום",false,false).contains("facial expressions"),"face animation intent");ok(Prompts.build("story","גינה",false,true).contains("without depending on an uploaded reference image"),"text-only prompt independent of image");
  ok(Prompts.error("Unable to resolve host","network").contains("אותה משימה"),"typed network recovery explained");ok(Prompts.error("quota exceeded","provider").contains("מכסה"),"quota explained");ok(Prompts.error("HTTP 402","provider").contains("דורש תשלום"),"paid service stopped");ok(Prompts.error("HTTP 401","provider").contains("חיבור"),"auth explained");ok(Prompts.error("Generation failed","provider").contains("3 שניות"),"generic provider failure suggests fast retry");
  System.out.println("Prompts checks passed: "+n);
 }
}
