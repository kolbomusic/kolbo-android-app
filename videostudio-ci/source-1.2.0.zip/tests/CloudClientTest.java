import com.kolbo.videostudio.CloudClient;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import org.json.*;

public class CloudClientTest {
 static int checks=0;
 static void ok(boolean condition,String name){checks++;if(!condition)throw new AssertionError(name);}
 static void rejects(Runnable call,String name){boolean failed=false;try{call.run();}catch(RuntimeException e){failed=true;}ok(failed,name);}
 public static void main(String[] args)throws Exception{
  JSONObject payload=CloudClient.ltxPayload("/tmp/gradio/input.png","image/png","Preserve the label",6,1086,1448);
  JSONArray data=payload.getJSONArray("data");
  ok(data.length()==13,"LTX Video Fast documented argument count");
  ok(data.getString(0).equals("Preserve the label"),"prompt preserved");
  ok(data.getJSONObject(2).getJSONObject("meta").getString("_type").equals("gradio.FileData"),"upload metadata");
  ok(data.getInt(4)==768&&data.getInt(5)==512,"portrait dimensions have correct height/width order");
  ok(data.getString(6).equals("image-to-video")&&data.getInt(7)==6,"image endpoint payload mode and duration");
  ok(data.getInt(8)==9&&data.getInt(9)==42&&!data.getBoolean(10)&&data.getDouble(11)==3.0&&!data.getBoolean(12),"tested deterministic public settings");
  rejects(()->CloudClient.ltxPayload("p","prompt",100,100,100),"invalid duration rejected");
  JSONObject textOnly=CloudClient.ltxPayload(null,"a cinematic cat running",3,768,512);JSONArray td=textOnly.getJSONArray("data");
  ok(td.isNull(2)&&td.getString(6).equals("text-to-video"),"text-to-video submits no reference image");
  ok(td.getInt(4)==512&&td.getInt(5)==768,"landscape text canvas normalized");
  ok(CloudClient.ltxPayload(null,"portrait",6,512,768).getJSONArray("data").getInt(4)==768,"portrait mode uses portrait canvas");
  ok(CloudClient.ltxPayload(null,"square",8,768,768).getJSONArray("data").getInt(5)==768,"square mode uses square canvas");
  String good="event: heartbeat\ndata: null\n\nevent: complete\ndata: [{\"video\":{\"path\":\"/tmp/good.mp4\",\"url\":\"https://lightricks-ltx-video-distilled.hf.space/gradio_api/file=/tmp/good.mp4\",\"orig_name\":\"good.mp4\",\"meta\":{\"_type\":\"gradio.FileData\"}},\"subtitles\":null},42]\n\n";
  String video=CloudClient.readSse(new ByteArrayInputStream(good.getBytes(StandardCharsets.UTF_8)),null);
  ok(video.equals("https://lightricks-ltx-video-distilled.hf.space/gradio_api/file=/tmp/good.mp4"),"SSE video completion");
  for(String event:new String[]{"event: error\ndata: null\n\n","event: complete\ndata: [null,42]\n\n","event: generating\ndata: null\n\n"}){boolean failed=false;try{CloudClient.readSse(new ByteArrayInputStream(event.getBytes(StandardCharsets.UTF_8)),null);}catch(IOException e){failed=true;}ok(failed,"failed/malformed/interrupted SSE cannot become success");}
  ok(CloudClient.trustedVideo(video,"ltx"),"current official output accepted");
  ok(CloudClient.trustedVideo("https://lightricks-ltx-2-3.hf.space/gradio_api/file=/tmp/legacy.mp4","ltx"),"legacy official output remains saveable");
  String wanGood="https://zerogpu-aoti-wan2-2-fp8da-aoti-faster.hf.space/gradio_api/file=/tmp/wan.mp4";
  ok(CloudClient.trustedVideo(wanGood,"ltx")&&CloudClient.isWanVideo(wanGood),"verified Wan fallback output accepted");
  ok(!CloudClient.trustedVideo("https://lightricks-ltx-video-distilled.hf.space.evil.example/a.mp4","ltx"),"lookalike rejected");
  ok(!CloudClient.trustedVideo("https://user:pass@lightricks-ltx-video-distilled.hf.space/a.mp4","ltx"),"userinfo rejected");
  ok(!CloudClient.validEventId("../../config")&&CloudClient.validEventId("40abcdef_42"),"event ID validation");
  ok(CloudClient.validEndpoint("image_to_video")&&CloudClient.validEndpoint("text_to_video")&&CloudClient.validEndpoint("wan_generate_video")&&!CloudClient.validEndpoint("../../x"),"event endpoint validation");
  ok(CloudClient.mp4Header(new byte[]{0,0,0,24,102,116,121,112,105,115,111,109}),"MP4 header accepted");
  ok(!CloudClient.mp4Header("<html>error</html>".getBytes(StandardCharsets.UTF_8)),"HTML is not a video");
  String redacted=CloudClient.safeError("bad token hf_fake_secret and secret-value","secret-value");ok(!redacted.contains("secret-value")&&!redacted.contains("hf_fake_secret"),"secret values absent from errors");
  ok(CloudClient.safeError("null",null).equals("Generation failed"),"null provider errors become meaningful");
  final int[] reads={0};InputStream oversized=new InputStream(){public int read(){reads[0]++;return reads[0]<=1000000?'x':-1;}};boolean rejected=false;try{CloudClient.readSse(oversized,null);}catch(IOException e){rejected=true;}ok(rejected&&reads[0]<100000,"oversized SSE line stops before unbounded allocation");

  final int[] posts={0},uploaded={0},events={0};
  CloudClient textClient=new CloudClient(new CloudClient.Transport(){public CloudClient.Reply request(String method,String url,String type,byte[] body,String token)throws IOException{
    if(url.endsWith("/upload")){uploaded[0]++;return new CloudClient.Reply(200,"application/json",new ByteArrayInputStream("[\"/tmp/img.png\"]".getBytes(StandardCharsets.UTF_8)));}
    if(url.endsWith("/call/text_to_video")){posts[0]++;try{JSONArray d=new JSONObject(new String(body,StandardCharsets.UTF_8)).getJSONArray("data");if(!d.isNull(2)||!"text-to-video".equals(d.getString(6)))throw new IOException("Text mode payload is wrong");}catch(JSONException e){throw new IOException(e);}return new CloudClient.Reply(200,"application/json",new ByteArrayInputStream("{\"event_id\":\"text_only_7\"}".getBytes(StandardCharsets.UTF_8)));}
    if(url.endsWith("/call/text_to_video/text_only_7")){String sse="event: complete\ndata: [{\"video\":{\"url\":\"https://lightricks-ltx-video-distilled.hf.space/gradio_api/file=/tmp/text.mp4\"}},42]\n\n";return new CloudClient.Reply(200,"text/event-stream",new ByteArrayInputStream(sse.getBytes(StandardCharsets.UTF_8)));}
    if(url.endsWith("/tmp/text.mp4"))return new CloudClient.Reply(200,"video/mp4",new ByteArrayInputStream(new byte[]{0,0,0,24,'f','t','y','p','i','s','o','m'}));
    throw new IOException("Unexpected URL: "+url);
  }});
  String textVideo=textClient.create("ltx",null,null,"A cat moving and jumping",3,768,512,"",new CloudClient.Listener(){public void created(String id,String endpoint){if("text_only_7".equals(id)&&"text_to_video".equals(endpoint))events[0]++;}public void progress(String message){}});
  ok(posts[0]==1&&uploaded[0]==0,"text creation posts exactly once without image upload");ok(events[0]==1&&textVideo.endsWith("/tmp/text.mp4"),"text generation validates SSE and MP4 header");

  final int[] imagePosts={0},imageUploads={0},imageEvents={0};File temp=File.createTempFile("kolbo-cloud-test-",".png");Files.write(temp.toPath(),new byte[]{1,2,3,4});
  try{
   CloudClient imageClient=new CloudClient(new CloudClient.Transport(){public CloudClient.Reply request(String method,String url,String type,byte[] body,String token)throws IOException{
    if(url.endsWith("/upload")){imageUploads[0]++;return new CloudClient.Reply(200,"application/json",new ByteArrayInputStream("[\"/tmp/gradio/image.png\"]".getBytes(StandardCharsets.UTF_8)));}
    if(url.endsWith("/call/image_to_video")){imagePosts[0]++;try{JSONArray d=new JSONObject(new String(body,StandardCharsets.UTF_8)).getJSONArray("data");if(d.isNull(2)||!"image-to-video".equals(d.getString(6)))throw new IOException("Image mode payload is wrong");}catch(JSONException e){throw new IOException(e);}return new CloudClient.Reply(200,"application/json",new ByteArrayInputStream("{\"event_id\":\"image_8\"}".getBytes(StandardCharsets.UTF_8)));}
    if(url.endsWith("/call/image_to_video/image_8")){String sse="event: complete\ndata: [{\"video\":{\"url\":\"https://lightricks-ltx-video-distilled.hf.space/gradio_api/file=/tmp/image.mp4\"}},42]\n\n";return new CloudClient.Reply(200,"text/event-stream",new ByteArrayInputStream(sse.getBytes(StandardCharsets.UTF_8)));}
    if(url.endsWith("/tmp/image.mp4"))return new CloudClient.Reply(200,"video/mp4",new ByteArrayInputStream(new byte[]{0,0,0,24,'f','t','y','p','i','s','o','m'}));throw new IOException("Unexpected URL: "+url);
   }});
   String imageVideo=imageClient.create("ltx",temp,"image/png","A bus drives forward",3,768,512,"",new CloudClient.Listener(){public void created(String id,String endpoint){if("image_8".equals(id)&&"image_to_video".equals(endpoint))imageEvents[0]++;}public void progress(String message){}});
   ok(imageUploads[0]==1&&imagePosts[0]==1&&imageEvents[0]==1&&imageVideo.endsWith("/tmp/image.mp4"),"image generation uploads once and uses image endpoint");
  }finally{temp.delete();}

  JSONObject dp=CloudClient.directorPayload("/tmp/gradio/input.png","image/png","Move the same subject to a new room");JSONArray dd=dp.getJSONArray("data");
  ok(dd.length()==13&&dd.getBoolean(8)&&dd.getInt(9)==75&&dd.getInt(10)==768,"director payload uses tested identity-preserving settings");
  ok(CloudClient.trustedImage("https://kulkas2pintu-qwen-edit-image.hf.space/gradio_api/file=/tmp/a.png"),"director image host accepted");
  ok(!CloudClient.trustedImage("https://kulkas2pintu-qwen-edit-image.hf.space.evil.example/gradio_api/file=/tmp/a.png"),"director lookalike rejected");
  ok(CloudClient.imageHeader(new byte[]{(byte)137,'P','N','G',13,10,26,10}),"PNG header accepted");
  final int[] directorPosts={0},directorUploads={0},directorPolls={0};File source=File.createTempFile("kolbo-director-source-",".png"),staged=File.createTempFile("kolbo-director-stage-",".png");Files.write(source.toPath(),new byte[]{1,2,3,4});staged.delete();
  try{
   CloudClient directorClient=new CloudClient(new CloudClient.Transport(){public CloudClient.Reply request(String method,String url,String type,byte[] body,String token)throws IOException{
    if(url.equals(CloudClient.QWEN+"/gradio_api/upload")){directorUploads[0]++;ok(token==null,"LTX token is not sent to director provider");return new CloudClient.Reply(200,"application/json",new ByteArrayInputStream("[\"/tmp/gradio/director-input.png\"]".getBytes(StandardCharsets.UTF_8)));}
    if(url.equals(CloudClient.QWEN+"/gradio_api/call/edit")){directorPosts[0]++;try{JSONArray d=new JSONObject(new String(body,StandardCharsets.UTF_8)).getJSONArray("data");if(d.length()!=13||!d.getBoolean(8)||d.getInt(9)!=75)throw new IOException("Director payload is wrong");}catch(JSONException e){throw new IOException(e);}return new CloudClient.Reply(200,"application/json",new ByteArrayInputStream("{\"event_id\":\"director_1\"}".getBytes(StandardCharsets.UTF_8)));}
    if(url.equals(CloudClient.QWEN+"/gradio_api/call/edit/director_1")){directorPolls[0]++;String sse="event: complete\ndata: [{\"url\":\"https://kulkas2pintu-qwen-edit-image.hf.space/gradio_api/file=/tmp/staged.png\"},42]\n\n";return new CloudClient.Reply(200,"text/event-stream",new ByteArrayInputStream(sse.getBytes(StandardCharsets.UTF_8)));}
    if(url.endsWith("/tmp/staged.png")){byte[] img=new byte[1400];img[0]=(byte)137;img[1]='P';img[2]='N';img[3]='G';img[4]=13;img[5]=10;img[6]=26;img[7]=10;return new CloudClient.Reply(200,"image/png",new ByteArrayInputStream(img));}
    throw new IOException("Unexpected director URL: "+url);
   }});
   String mime=directorClient.stageImage(source,"image/png","Preserve the subject and move it into the destination environment",staged,new CloudClient.Listener(){public void created(String id,String endpoint){}public void progress(String message){}});
   ok("image/png".equals(mime)&&staged.isFile()&&staged.length()==1400,"director stage downloads verified image");
   ok(directorUploads[0]==1&&directorPosts[0]==1&&directorPolls[0]==1,"director stage performs one upload, submission and poll");
  }finally{source.delete();staged.delete();}

  final int[] retryUploads={0},retryPosts={0},retryPolls={0};File retrySource=File.createTempFile("kolbo-director-retry-",".png"),retryTarget=File.createTempFile("kolbo-director-retry-stage-",".png");Files.write(retrySource.toPath(),new byte[]{1,2,3,4});retryTarget.delete();
  try{
   CloudClient retryClient=new CloudClient(new CloudClient.Transport(){public CloudClient.Reply request(String method,String url,String type,byte[] body,String token)throws IOException{
    if(url.equals(CloudClient.QWEN+"/gradio_api/upload")){retryUploads[0]++;return new CloudClient.Reply(200,"application/json",new ByteArrayInputStream(("[\"/tmp/gradio/retry"+retryUploads[0]+".png\"]").getBytes(StandardCharsets.UTF_8)));}
    if(url.equals(CloudClient.QWEN+"/gradio_api/call/edit")){retryPosts[0]++;return new CloudClient.Reply(200,"application/json",new ByteArrayInputStream(("{\"event_id\":\"retry_"+retryPosts[0]+"\"}").getBytes(StandardCharsets.UTF_8)));}
    if(url.contains("/gradio_api/call/edit/retry_")){retryPolls[0]++;if(retryPolls[0]<3){String fail="event: error\ndata: null\n\n";return new CloudClient.Reply(200,"text/event-stream",new ByteArrayInputStream(fail.getBytes(StandardCharsets.UTF_8)));}String done="event: complete\ndata: [{\"url\":\"https://kulkas2pintu-qwen-edit-image.hf.space/gradio_api/file=/tmp/retry-stage.png\"},42]\n\n";return new CloudClient.Reply(200,"text/event-stream",new ByteArrayInputStream(done.getBytes(StandardCharsets.UTF_8)));}
    if(url.endsWith("/tmp/retry-stage.png")){byte[] img=new byte[1500];img[0]=(byte)137;img[1]='P';img[2]='N';img[3]='G';img[4]=13;img[5]=10;img[6]=26;img[7]=10;return new CloudClient.Reply(200,"image/png",new ByteArrayInputStream(img));}
    throw new IOException("Unexpected retry URL: "+url);
   }});
   String mime=retryClient.stageImage(retrySource,"image/png","Preserve identity and move into the requested destination",retryTarget,null);
   ok("image/png".equals(mime)&&retryUploads[0]==3&&retryPosts[0]==3&&retryPolls[0]==3,"director retries transient provider errors three times");
  }finally{retrySource.delete();retryTarget.delete();}

  JSONObject wp=CloudClient.wanPayload("/tmp/gradio/input.png","image/png","A bus drives forward into the garage");JSONArray wd=wp.getJSONArray("data");
  ok(wd.length()==9&&wd.getJSONObject(0).getJSONObject("meta").getString("_type").equals("gradio.FileData"),"Wan payload contains uploaded image metadata");
  ok(wd.getInt(2)==6&&wd.getDouble(4)==3.5&&wd.getInt(7)==42&&!wd.getBoolean(8),"Wan payload uses live-verified fallback settings");

  final int[] ltxFallbackPosts={0},wanFallbackPosts={0},wanEvents={0};File fallbackSource=File.createTempFile("kolbo-wan-fallback-",".png");Files.write(fallbackSource.toPath(),new byte[]{1,2,3,4});
  try{
   CloudClient fallbackClient=new CloudClient(new CloudClient.Transport(){public CloudClient.Reply request(String method,String url,String type,byte[] body,String token)throws IOException{
    if(url.equals(CloudClient.LTX+"/gradio_api/upload"))return new CloudClient.Reply(200,"application/json",new ByteArrayInputStream("[\"/tmp/gradio/ltx-input.png\"]".getBytes(StandardCharsets.UTF_8)));
    if(url.equals(CloudClient.LTX+"/gradio_api/call/image_to_video")){ltxFallbackPosts[0]++;return new CloudClient.Reply(200,"application/json",new ByteArrayInputStream(("{\"event_id\":\"ltx_fail_"+ltxFallbackPosts[0]+"\"}").getBytes(StandardCharsets.UTF_8)));}
    if(url.contains(CloudClient.LTX+"/gradio_api/call/image_to_video/ltx_fail_")){String fail="event: error\ndata: null\n\n";return new CloudClient.Reply(200,"text/event-stream",new ByteArrayInputStream(fail.getBytes(StandardCharsets.UTF_8)));}
    if(url.equals(CloudClient.WAN+"/gradio_api/upload")){ok(token==null,"user token is not sent to Wan fallback");return new CloudClient.Reply(200,"application/json",new ByteArrayInputStream("[\"/tmp/gradio/wan-input.png\"]".getBytes(StandardCharsets.UTF_8)));}
    if(url.equals(CloudClient.WAN+"/gradio_api/call/generate_video")){wanFallbackPosts[0]++;ok(token==null,"Wan generation submission receives no user token");try{JSONArray d=new JSONObject(new String(body,StandardCharsets.UTF_8)).getJSONArray("data");if(d.length()!=9||d.getInt(2)!=6)throw new IOException("Wan payload is wrong");}catch(JSONException e){throw new IOException(e);}return new CloudClient.Reply(200,"application/json",new ByteArrayInputStream("{\"event_id\":\"wan_ok_1\"}".getBytes(StandardCharsets.UTF_8)));}
    if(url.equals(CloudClient.WAN+"/gradio_api/call/generate_video/wan_ok_1")){String done="event: complete\ndata: [{\"url\":\"https://zerogpu-aoti-wan2-2-fp8da-aoti-faster.hf.space/gradio_api/file=/tmp/wan-ok.mp4\"}]\n\n";return new CloudClient.Reply(200,"text/event-stream",new ByteArrayInputStream(done.getBytes(StandardCharsets.UTF_8)));}
    if(url.endsWith("/tmp/wan-ok.mp4")){ok(token==null,"Wan video verification receives no user token");return new CloudClient.Reply(200,"video/mp4",new ByteArrayInputStream(new byte[]{0,0,0,24,'f','t','y','p','i','s','o','m'}));}
    throw new IOException("Unexpected fallback URL: "+url);
   }});
   String fallbackVideo=fallbackClient.create("ltx",fallbackSource,"image/png","The same bus drives forward into a garage and stops",6,768,512,"hf_private_test",new CloudClient.Listener(){public void created(String id,String endpoint){if("wan_generate_video".equals(endpoint))wanEvents[0]++;}public void progress(String message){}});
   ok(ltxFallbackPosts[0]==2&&wanFallbackPosts[0]==1&&wanEvents[0]==1,"two LTX failures automatically switch once to Wan");
   ok(CloudClient.isWanVideo(fallbackVideo),"Wan fallback returns verified fallback video URL");
  }finally{fallbackSource.delete();}


  JSONObject ap=CloudClient.audioPayload("/tmp/gradio/video.mp4","footsteps and a door closing",8);JSONArray ad=ap.getJSONArray("data");
  ok(ad.length()==7&&ad.getJSONObject(0).getJSONObject("meta").getString("_type").equals("gradio.FileData"),"MMAudio payload contains video metadata");
  ok(ad.getInt(4)==20&&ad.getDouble(5)==4.5&&ad.getInt(6)==8,"MMAudio payload uses verified settings");
  ok(CloudClient.validEndpoint("mmaudio_video_to_audio"),"MMAudio event endpoint accepted");
  ok(CloudClient.trustedVideo("https://hkchengrex-mmaudio.hf.space/gradio_api/file=/tmp/audio.mp4","mmaudio"),"MMAudio output host accepted");

  CloudClient translateClient=new CloudClient(new CloudClient.Transport(){public CloudClient.Reply request(String method,String url,String type,byte[] body,String token)throws IOException{
    if(url.startsWith(CloudClient.TRANSLATE+"/translate_a/single?"))return new CloudClient.Reply(200,"application/json",new ByteArrayInputStream("[[[\"The character enters the bathroom and sits on the toilet\",\"הדמות נכנסת לשירותים ומתיישבת על האסלה\",null,null,10]],null,\"he\"]".getBytes(StandardCharsets.UTF_8)));
    throw new IOException("Unexpected translation URL: "+url);
  }});
  ok(translateClient.translateToEnglish("הדמות נכנסת לשירותים ומתיישבת על האסלה").contains("bathroom"),"Hebrew story translated before rendering");
  ok(translateClient.translateToEnglish("The person walks").equals("The person walks"),"English story bypasses translation network");

  File audioSource=File.createTempFile("kolbo-audio-source-",".mp4");Files.write(audioSource.toPath(),new byte[]{0,0,0,24,'f','t','y','p','i','s','o','m'});
  try{
   final int[] audioPosts={0},audioPolls={0};CloudClient audioClient=new CloudClient(new CloudClient.Transport(){public CloudClient.Reply request(String method,String url,String type,byte[] body,String token)throws IOException{
    if(url.equals(CloudClient.MMAUDIO+"/gradio_api/upload")){ok(token==null,"token not sent to MMAudio upload");return new CloudClient.Reply(200,"application/json",new ByteArrayInputStream("[\"/tmp/gradio/source.mp4\"]".getBytes(StandardCharsets.UTF_8)));}
    if(url.equals(CloudClient.MMAUDIO+"/gradio_api/call/video_to_audio")){audioPosts[0]++;try{JSONArray d=new JSONObject(new String(body,StandardCharsets.UTF_8)).getJSONArray("data");if(d.length()!=7||d.getInt(4)!=20)throw new IOException("Audio payload wrong");}catch(JSONException e){throw new IOException(e);}return new CloudClient.Reply(200,"application/json",new ByteArrayInputStream("{\"event_id\":\"audio_1\"}".getBytes(StandardCharsets.UTF_8)));}
    if(url.equals(CloudClient.MMAUDIO+"/gradio_api/call/video_to_audio/audio_1")){audioPolls[0]++;String done="event: complete\ndata: [{\"url\":\"https://hkchengrex-mmaudio.hf.space/gradio_api/file=/tmp/audio.mp4\"}]\n\n";return new CloudClient.Reply(200,"text/event-stream",new ByteArrayInputStream(done.getBytes(StandardCharsets.UTF_8)));}
    if(url.endsWith("/tmp/audio.mp4"))return new CloudClient.Reply(200,"video/mp4",new ByteArrayInputStream(new byte[]{0,0,0,24,'f','t','y','p','i','s','o','m'}));
    throw new IOException("Unexpected audio URL: "+url);
   }});
   String audioVideo=audioClient.addSound(audioSource,"natural synchronized footsteps",8,null);ok(audioPosts[0]==1&&audioPolls[0]==1&&audioVideo.contains("mmaudio"),"MMAudio creation submits, polls and validates output");
  }finally{audioSource.delete();}

  System.out.println("CloudClient checks passed: "+checks);
 }
}
