"""Fresh release gate: real tests, package metadata, signature and byte integrity."""
import pathlib, subprocess, zipfile, struct, hashlib, json
ROOT=pathlib.Path(__file__).resolve().parents[1]
def run(args):return subprocess.run([str(a) for a in args],cwd=ROOT,check=True,capture_output=True,text=True).stdout
def main():
 out=ROOT/'build/verification';out.mkdir(parents=True,exist_ok=True)
 # The obsolete WebView prototype was removed; only current native and Java tests count.
 sources=[ROOT/'app/src/main/java/com/kolbo/videostudio'/x for x in ['Json.java','CloudClient.java','JobPolicy.java','ImageFiles.java','Prompts.java','SmartDirector.java','StoryPlanner.java']]+list((ROOT/'tests').glob('*Test.java'))
 run(['java','-jar','toolchain/ecj.jar','-8','-nowarn','-cp','toolchain/json.jar','-d','build/test-classes',*sources])
 for name in ['CloudClientTest','JobPolicyTest','ImageFilesTest','PromptsTest','SmartDirectorTest','StoryPlannerTest']:print(run(['java','-cp','build/test-classes:toolchain/json.jar',name]).strip())
 apk=ROOT/'build/final/Kolbo-Video-Studio-1.2.1.apk'
 metadata=run(['toolchain/aapt2','dump','badging',apk]);(out/'manifest.txt').write_text(metadata)
 assert "name='com.kolbo.videostudio'" in metadata and "minSdkVersion:'26'" in metadata and "targetSdkVersion:'35'" in metadata
 permissions=[line for line in metadata.splitlines() if line.startswith('uses-permission:')]
 assert set(permissions)=={"uses-permission: name='android.permission.INTERNET'","uses-permission: name='android.permission.ACCESS_NETWORK_STATE'"}
 assert 'application-debuggable' not in metadata
 with zipfile.ZipFile(apk) as z:
  assert z.testzip() is None and 'classes.dex' in z.namelist()
  assert not any('bottle' in n.lower() for n in z.namelist())
  assert not any(n.startswith('assets/') for n in z.namelist())
  assert not any(n.endswith(('.p12','.jks','.keystore','.mp4')) for n in z.namelist())
  with apk.open('rb') as f:
   info=z.getinfo('resources.arsc');f.seek(info.header_offset);header=f.read(30);n,x=struct.unpack_from('<HH',header,26)
   assert info.compress_type==0 and (info.header_offset+30+n+x)%4==0
 run(['java','-jar','toolchain/ecj.jar','-8','-nowarn','-cp','toolchain/apksig.jar','-d','build/signer','tools/VerifyApk.java'])
 signature=run(['java','-cp','build/signer:toolchain/apksig.jar','VerifyApk',apk]);print(signature.strip())
 report={'apk':apk.name,'bytes':apk.stat().st_size,'sha256':hashlib.sha256(apk.read_bytes()).hexdigest(),'legacy_prototype_excluded':True,'java_checks':'See individual test outputs','zip_integrity':True,'resources_aligned':True,'private_keys_and_test_videos_excluded':True,'signature':signature.strip(),'permissions':permissions}
 (out/'package.json').write_text(json.dumps(report,indent=2));print('PACKAGE_CHECKS_PASSED',json.dumps(report))
if __name__=='__main__':main()
