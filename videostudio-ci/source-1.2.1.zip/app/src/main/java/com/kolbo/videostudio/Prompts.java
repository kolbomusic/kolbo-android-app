package com.kolbo.videostudio;
public final class Prompts{
 private Prompts(){}
 /** User instructions take precedence. A preset provides only structure and safety from identity drift. */
 public static String build(String preset,String story,boolean soundtrack){
  return build(preset,story,soundtrack,false);
 }
 public static String build(String preset,String story,boolean soundtrack,boolean textOnly){
  String text;
  if("product".equals(preset))text="Create a natural cinematic product video. Preserve the product's shape, geometry, colors, proportions, brand, packaging and all readable labels. Genuine movement, physically coherent shadows and contacts. Do not invent logos or replace the product.";
  else if("portrait".equals(preset))text="Create a realistic portrait scene with authentic facial expressions and subtle head and body motion. Maintain consistent identity, facial anatomy, hands and background. If dialogue is requested, depict visible synchronized mouth movements, but do not invent unrelated dialogue.";
  else if("action".equals(preset))text="Create physically plausible action with distinct changes in pose and environment over time, meaningful subject movement, coherent camera tracking and continuity. The result must be a moving shot, not a still photo or slideshow. No duplicated limbs.";
  else if("story".equals(preset))text="Cinematic single-shot scene with clear staging, intentional character or object actions, coherent beginning and ending, atmospheric depth, consistent lighting and realistic motion.";
  else text="Real moving cinematic footage with natural temporal continuity, physically believable subject and background movement, correct occlusion and no morphing or duplicate subjects.";
  if(textOnly)text+=" Construct the original scene described below, without depending on an uploaded reference image.";
  else text+=" Respect the supplied reference photograph. Preserve identity and avoid altering distinctive details.";
  if(story!=null&&!story.trim().isEmpty())text+=" Primary scene instructions from the user, already normalized to English when needed; follow these over generic style: "+story.trim();
  text+=" Focus on coherent visual motion and temporal consistency. Never invent captions, subtitles, letters, logos or unrelated on-screen text.";
  return text;
 }
 public static String error(String message,String kind){
  String s=message==null?"":message.toLowerCase(java.util.Locale.ROOT);
  if("network".equals(kind))return "החיבור לשירות נקטע. אפשר לבדוק שוב את אותה משימה בלי ליצור סרטון נוסף.";
  if(s.contains("smart director"))return "במאי חכם לא הצליח להכין את סצנת הפתיחה, ולכן הסרטון לא נשלח להנפשה חלקית. אפשר לנסות שוב או לכבות את 'במאי חכם' כדי להשתמש ישירות בתמונת המקור.";
  if(s.contains("quota")||s.contains("429")||s.contains("rate limit"))return "המכסה החינמית של השירות אינה זמינה כרגע. אפשר להמתין לאיפוס או לחבר חשבון חינמי משלך. לא בוצע תשלום.";
  if(s.contains("402")||s.contains("payment"))return "השירות דורש תשלום. ההפקה נעצרה בהתאם לבחירה שלך להשתמש בחינם בלבד.";
  if(s.contains("401")||s.contains("403")||s.contains("unauthorized"))return "השירות דורש חיבור תקין. בדוק את החשבון שלך במסך החיבורים.";
  if(s.contains("all_video_engines_failed")){String detail=message==null?"":message.replace("ALL_VIDEO_ENGINES_FAILED | ","");if(detail.length()>520)detail=detail.substring(0,520);return "כל מנועי הווידאו החינמיים נוסו אוטומטית ולא החזירו סרטון. אבחון: "+detail;}
  if(s.contains("generation failed")||s.equals("null"))return "מנוע הווידאו לא השלים את המשימה. האפליקציה תנסה אוטומטית מנועים נוספים לפני עצירה; אם כולם עמוסים אפשר לנסות סרטון של 3 שניות.";
  return "הפעולה לא הסתיימה בהצלחה. בדוק את החיבור ונסה שוב. לא התקבל סרטון תקין מהשירות.";
 }
}
