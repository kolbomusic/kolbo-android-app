package com.kolbomusic.singstudio.core.playback

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class YouTubeNavigationPolicyTest {
    @Test fun allowsOnlyHttpsYouTubeHosts() {
        assertTrue(YouTubeNavigationPolicy.isAllowed("https://m.youtube.com/watch?v=abcdefghijk"))
        assertTrue(YouTubeNavigationPolicy.isAllowed("https://youtu.be/abcdefghijk"))
        assertFalse(YouTubeNavigationPolicy.isAllowed("http://youtube.com/watch?v=abcdefghijk"))
        assertFalse(YouTubeNavigationPolicy.isAllowed("https://youtube.com.evil.example/watch?v=abcdefghijk"))
        assertFalse(YouTubeNavigationPolicy.isAllowed("https://example.com/"))
    }

    @Test fun kolboOriginIsOnlyAllowedWhenExplicitlyRequested() {
        assertFalse(YouTubeNavigationPolicy.isAllowed("https://kolbomusic.com/"))
        assertTrue(YouTubeNavigationPolicy.isAllowed("https://kolbomusic.com/", allowKolboOrigin = true))
    }
}
