package com.kolbomusic.singstudio.core.mix

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SessionMixMathTest {
    @Test fun maps48kTimelineTo44100VocalDeterministically() {
        val source = SessionMixMath.sourcePositionForTargetFrame(
            targetFrame = 48_000L,
            targetSampleRate = 48_000,
            sourceSampleRate = 44_100,
            sourceStartFrame = 22_050L
        )
        assertEquals(66_150.0, source, 0.0001)
    }

    @Test fun vocalPreRollOffsetConvertsToFrames() {
        assertEquals(22_050L, SessionMixMath.vocalStartFrame(500L, 44_100))
    }

    @Test fun limiterKeepsOutputInsideSafeRange() {
        assertTrue(SessionMixMath.softLimit(3f) <= 0.995f)
        assertTrue(SessionMixMath.softLimit(-3f) >= -0.995f)
        assertEquals(0.5f, SessionMixMath.softLimit(0.5f), 0.0001f)
    }
}
