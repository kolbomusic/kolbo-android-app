package com.kolbomusic.singstudio.core.editor

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ProjectMigrationPolicyTest {
    @Test fun currentSchemaLoadsWithoutMigration() {
        val d = ProjectMigrationPolicy.decide(ProjectMigrationPolicy.CURRENT_SCHEMA)
        assertTrue(d.accepted)
        assertFalse(d.migrated)
    }

    @Test fun olderSupportedSchemaMigratesInMemory() {
        val d = ProjectMigrationPolicy.decide(1)
        assertTrue(d.accepted)
        assertTrue(d.migrated)
    }

    @Test fun futureSchemaIsRejected() {
        assertFalse(ProjectMigrationPolicy.decide(ProjectMigrationPolicy.CURRENT_SCHEMA + 1).accepted)
    }
}
