package com.kolbomusic.singstudio.core.mix

import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.PI
import kotlin.math.sin

class AdaptiveVocalBalanceProcessorTest {
    @Test
    fun weakPhrasesAreLiftedAndStrongPhrasesAreReducedSmoothly() {
        val sampleRate = 48_000
        val frames = 1024
        val processor = AdaptiveVocalBalanceProcessor(sampleRate)
        val backing = FloatArray(frames * 2)
        val vocal = FloatArray(frames)

        fun fill(vocalAmplitude: Float, phase: Int) {
            repeat(frames) { i ->
                val absolute = phase * frames + i
                val b = (sin(2.0 * PI * 900.0 * absolute / sampleRate) * 0.16).toFloat()
                backing[i * 2] = b
                backing[i * 2 + 1] = b
                vocal[i] = (sin(2.0 * PI * 1_000.0 * absolute / sampleRate) * vocalAmplitude).toFloat()
            }
        }

        repeat(20) { n ->
            fill(0.07f, n)
            processor.balance(backing, 2, vocal, frames, 1f, 1f)
        }
        var weakRide = 0.0
        repeat(20) { n ->
            fill(0.035f, 20 + n)
            weakRide = processor.balance(backing, 2, vocal, frames, 1f, 1f).vocalRideDb
        }
        var strongRide = 0.0
        repeat(20) { n ->
            fill(0.18f, 40 + n)
            strongRide = processor.balance(backing, 2, vocal, frames, 1f, 1f).vocalRideDb
        }

        assertTrue("weak phrase should be lifted", weakRide > 2.0)
        assertTrue("strong phrase should be attenuated", strongRide < -2.0)
    }

    @Test
    fun backingDuckingRemainsSubtle() {
        val processor = AdaptiveVocalBalanceProcessor(48_000)
        val frames = 1024
        val backing = FloatArray(frames * 2) { 0.16f }
        val vocal = FloatArray(frames) { 0.025f }
        var result = processor.balance(backing, 2, vocal, frames, 1f, 1f)
        repeat(30) { result = processor.balance(backing, 2, vocal, frames, 1f, 1f) }
        assertTrue(result.playbackDuckDb >= -1.15)
        assertTrue(result.playbackDuckDb <= 0.0)
    }

    @Test
    fun bassHeavyBackingDoesNotForceMaximumVocalRide() {
        val sampleRate = 48_000
        val frames = 2048
        val processor = AdaptiveVocalBalanceProcessor(sampleRate)
        val backing = FloatArray(frames * 2)
        val vocal = FloatArray(frames)
        repeat(frames) { i ->
            val bass = (sin(2.0 * PI * 110.0 * i / sampleRate) * 0.65).toFloat()
            backing[i * 2] = bass
            backing[i * 2 + 1] = bass
            vocal[i] = (sin(2.0 * PI * 1_000.0 * i / sampleRate) * 0.06).toFloat()
        }
        var result = processor.balance(backing, 2, vocal, frames, 1f, 1f)
        repeat(40) { result = processor.balance(backing, 2, vocal, frames, 1f, 1f) }
        assertTrue("bass alone must not drive vocal ride to ceiling", result.vocalRideDb < 3.25)
    }
}
