package com.kolbomusic.singstudio.core.playback

import org.junit.Assert.assertEquals
import org.junit.Test

class PlaybackSyncMathTest {
    @Test fun offsetUsesMonotonicNanoseconds() {
        assertEquals(3087L, PlaybackSyncMath.offsetMs(1_000_000_000L, 4_087_000_000L))
    }

    @Test fun invalidOrEarlyPlaybackNeverProducesNegativeOffset() {
        assertEquals(0L, PlaybackSyncMath.offsetMs(0L, 3_000_000L))
        assertEquals(0L, PlaybackSyncMath.offsetMs(5_000_000L, 4_000_000L))
    }
}
