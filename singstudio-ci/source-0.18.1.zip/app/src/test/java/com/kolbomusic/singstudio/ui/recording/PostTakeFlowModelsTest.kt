package com.kolbomusic.singstudio.ui.recording

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PostTakeFlowModelsTest {
    @Test
    fun preparingStagesAreReportedAsPreparing() {
        assertTrue(PostTakeState(stage = PostTakeStage.PreparingVocal).preparing)
        assertTrue(PostTakeState(stage = PostTakeStage.PreparingMix).preparing)
        assertTrue(PostTakeState(stage = PostTakeStage.Mastering).preparing)
        assertTrue(PostTakeState(stage = PostTakeStage.RenderingVideo).preparing)
        assertTrue(PostTakeState(stage = PostTakeStage.VerifyingVideo).preparing)
        assertFalse(PostTakeState(stage = PostTakeStage.ReadyToSave).preparing)
    }

    @Test
    fun readyToSaveOnlyAfterFinalVideoVerification() {
        assertTrue(PostTakeState(stage = PostTakeStage.ReadyToSave).readyToSave)
        assertFalse(PostTakeState(stage = PostTakeStage.Idle).readyToSave)
        assertFalse(PostTakeState(stage = PostTakeStage.Error).readyToSave)
    }
}
