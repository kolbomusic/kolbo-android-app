package com.kolbomusic.singstudio.core.playback

import com.kolbomusic.singstudio.core.model.PlaybackSource
import com.kolbomusic.singstudio.core.model.PlaybackSourceType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ProductionSourcePolicyTest {
    private val localAudio = PlaybackSource(
        id = "local-audio",
        type = PlaybackSourceType.LocalAudio,
        title = "Backing",
        uriString = "content://local/backing.mp3"
    )
    private val localVideo = PlaybackSource(
        id = "local-video",
        type = PlaybackSourceType.LocalVideo,
        title = "Karaoke video",
        uriString = "content://local/karaoke.mp4"
    )
    private val youtube = PlaybackSource(
        id = "youtube",
        type = PlaybackSourceType.YouTube,
        title = "YouTube karaoke",
        youtubeVideoId = "abc123"
    )

    @Test
    fun localMediaAutomaticallyBecomesProductionSource() {
        assertEquals(localAudio, ProductionSourcePolicy.automaticFor(localAudio))
        assertEquals(localVideo, ProductionSourcePolicy.automaticFor(localVideo))
        assertTrue(ProductionSourcePolicy.canStartFullProduction(localAudio, null))
    }

    @Test
    fun youtubeCannotStartFullProductionWithoutLatchedLocalSource() {
        assertNull(ProductionSourcePolicy.automaticFor(youtube))
        assertFalse(ProductionSourcePolicy.canStartFullProduction(youtube, null))
        assertNull(ProductionSourcePolicy.resolve(youtube, null))
        assertTrue(ProductionSourcePolicy.canStartPerformance(youtube))
        assertTrue(ProductionSourcePolicy.isVoiceOnlyPerformance(youtube, null))
    }

    @Test
    fun youtubeUsesTheLatchedLocalSourceForProduction() {
        assertTrue(ProductionSourcePolicy.canStartFullProduction(youtube, localVideo))
        assertEquals(localVideo, ProductionSourcePolicy.resolve(youtube, localVideo))
        assertFalse(ProductionSourcePolicy.isVoiceOnlyPerformance(youtube, localVideo))
    }

    @Test
    fun youtubeIsNeverAcceptedAsItsOwnOfflineProductionSource() {
        assertFalse(ProductionSourcePolicy.isValidProductionSource(youtube))
        assertNull(ProductionSourcePolicy.resolve(youtube, youtube))
    }
}
