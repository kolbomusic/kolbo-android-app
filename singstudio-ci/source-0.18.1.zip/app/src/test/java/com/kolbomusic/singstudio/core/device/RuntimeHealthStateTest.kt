package com.kolbomusic.singstudio.core.device

import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class RuntimeHealthStateTest {
    @Test fun healthyStateHasNoWarning() {
        assertNull(RuntimeHealthState(batteryPercent = 80, freeStorageBytes = 5_000_000_000L).exportWarning)
    }

    @Test fun severeThermalStateWinsWarningPriority() {
        assertNotNull(RuntimeHealthState(
            batteryPercent = 10,
            powerSaveMode = true,
            thermalLevel = ThermalLevel.Severe,
            freeStorageBytes = 500_000_000L
        ).exportWarning)
    }
}
