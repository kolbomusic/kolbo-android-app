package com.kolbomusic.singstudio.core.mix

import com.kolbomusic.singstudio.core.playback.ProductionSourcePolicy
import org.junit.Assert.*
import org.junit.Test
import java.nio.file.Files

class VoiceOnlyBackingTest {
    @Test fun createsRealSilentTimelineWithoutYouTubeContent() {
        val dir = Files.createTempDirectory("voice-only-test").toFile()
        try {
            val raw = java.io.File(dir, "recorded.wav")
            Pcm16InterleavedWavWriter(raw, 44_100, 1).use { writer ->
                writer.writeInterleaved(FloatArray(4410) { 0.23f }, 0, 4410)
                writer.commit()
            }
            val (silence, source) = VoiceOnlyBacking.prepare(raw, 50L)
            assertTrue(ProductionSourcePolicy.isGeneratedVoiceOnlyBacking(source))
            Pcm16InterleavedWavReader(silence).use { reader ->
                assertEquals(44_100, reader.sampleRate)
                assertEquals(1, reader.channels)
                assertEquals(2205L, reader.frameCount)
                val decoded = FloatArray(2205)
                assertEquals(2205, reader.readFrames(0, decoded, 0, 2205))
                assertTrue(decoded.all { it == 0f })
            }
            java.io.RandomAccessFile(silence, "rw").use { old ->
                old.seek(44L)
                old.write(45)
                old.write(15)
            }
            assertEquals(silence, VoiceOnlyBacking.prepare(raw, 50L).first)
            Pcm16InterleavedWavReader(silence).use { reader ->
                val start = FloatArray(1)
                assertEquals(1, reader.readFrames(0L, start, 0, 1))
                assertEquals(0f, start[0])
            }
        } finally { dir.deleteRecursively() }
    }
}
