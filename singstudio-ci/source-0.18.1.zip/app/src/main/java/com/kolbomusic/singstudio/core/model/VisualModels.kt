package com.kolbomusic.singstudio.core.model

enum class OutputAspectRatio(
    val label: String,
    val width: Int,
    val height: Int
) {
    Portrait9x16("9:16", 9, 16),
    Landscape16x9("16:9", 16, 9),
    Square1x1("1:1", 1, 1);

    val ratio: Float
        get() = width.toFloat() / height.toFloat()
}

enum class CameraFacing {
    Front,
    Back
}

enum class VisualBackgroundType {
    None,
    BuiltIn,
    Image,
    Video
}

data class VisualBackground(
    val type: VisualBackgroundType = VisualBackgroundType.None,
    val id: String? = null,
    val title: String? = null,
    val uriString: String? = null
)

data class VisualScene(
    val mode: ProductionMode,
    val aspectRatio: OutputAspectRatio = OutputAspectRatio.Portrait9x16,
    val cameraFacing: CameraFacing = CameraFacing.Front,
    val background: VisualBackground = VisualBackground()
)

data class CameraSyncMarker(
    val filePath: String,
    val startedElapsedRealtimeNs: Long,
    val cameraFacing: CameraFacing,
    val requestedAspectRatio: OutputAspectRatio
)
