package com.kolbomusic.singstudio.core.playback

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.kolbomusic.singstudio.core.model.PlaybackSource
import com.kolbomusic.singstudio.core.model.PlaybackSourceType
import java.util.UUID

object LocalMediaResolver {
    fun resolve(context: Context, uri: Uri): PlaybackSource {
        val resolver = context.contentResolver
        val mimeType = resolver.getType(uri)
        val displayName = resolver.query(
            uri,
            arrayOf(OpenableColumns.DISPLAY_NAME),
            null,
            null,
            null
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                cursor.getString(cursor.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME))
            } else null
        } ?: "פלייבק מקומי"

        val type = if (mimeType?.startsWith("video/") == true) {
            PlaybackSourceType.LocalVideo
        } else {
            PlaybackSourceType.LocalAudio
        }

        return PlaybackSource(
            id = "local-${UUID.randomUUID()}",
            type = type,
            title = displayName,
            uriString = uri.toString(),
            mimeType = mimeType
        )
    }
}
