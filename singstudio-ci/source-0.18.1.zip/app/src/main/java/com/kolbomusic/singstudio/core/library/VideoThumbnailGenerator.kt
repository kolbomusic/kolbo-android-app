package com.kolbomusic.singstudio.core.library

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import java.io.File
import java.io.FileOutputStream

class VideoThumbnailGenerator(private val context: Context) {
    fun create(exportFile: File, stableId: String): String? {
        if (!exportFile.isFile || exportFile.length() <= 0L) return null
        val outputDir = File(context.filesDir, "library/thumbnails").also { it.mkdirs() }
        val finalFile = File(outputDir, "$stableId.jpg")
        val partial = File(outputDir, "$stableId.jpg.partial")
        val bitmap = MediaMetadataRetriever().useSafely { retriever ->
            retriever.setDataSource(exportFile.absolutePath)
            retriever.getFrameAtTime(500_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: retriever.frameAtTime
        } ?: return null
        return try {
            FileOutputStream(partial).use { stream ->
                check(bitmap.compress(Bitmap.CompressFormat.JPEG, 86, stream)) { "Thumbnail compression failed" }
                stream.fd.sync()
            }
            check(partial.length() > 0L) { "Thumbnail is empty" }
            if (finalFile.exists()) finalFile.delete()
            check(partial.renameTo(finalFile)) { "Thumbnail finalize failed" }
            finalFile.absolutePath
        } finally {
            bitmap.recycle()
            partial.delete()
        }
    }

    private inline fun <T> MediaMetadataRetriever.useSafely(block: (MediaMetadataRetriever) -> T): T? = try {
        block(this)
    } catch (_: Throwable) {
        null
    } finally {
        runCatching { release() }
    }
}
