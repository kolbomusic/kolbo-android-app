package com.kolbomusic.singstudio.core.device

import android.content.Context
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.os.Build
import com.kolbomusic.singstudio.core.model.DeviceCapabilities

class DeviceCapabilityProbe(private val context: Context) {

    fun probe(): DeviceCapabilities {
        val packageManager = context.packageManager
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager

        val sampleRate = audioManager
            .getProperty(AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE)
            ?.toIntOrNull()
            ?.takeIf { it > 0 }
            ?: 48_000

        val framesPerBuffer = audioManager
            .getProperty(AudioManager.PROPERTY_OUTPUT_FRAMES_PER_BUFFER)
            ?.toIntOrNull()
            ?.takeIf { it > 0 }
            ?: 256

        val supportsUnprocessed = audioManager
            .getProperty(AudioManager.PROPERTY_SUPPORT_AUDIO_SOURCE_UNPROCESSED)
            ?.equals("true", ignoreCase = true)
            ?: false

        val cameraCount = runCatching { cameraManager.cameraIdList.size }.getOrDefault(0)

        return DeviceCapabilities(
            manufacturer = Build.MANUFACTURER.orEmpty(),
            model = Build.MODEL.orEmpty(),
            androidVersion = Build.VERSION.RELEASE.orEmpty(),
            sdkInt = Build.VERSION.SDK_INT,
            hasMicrophone = packageManager.hasSystemFeature(PackageManager.FEATURE_MICROPHONE),
            hasCamera = packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY) && cameraCount > 0,
            cameraCount = cameraCount,
            supportsLowLatencyAudio = packageManager.hasSystemFeature(PackageManager.FEATURE_AUDIO_LOW_LATENCY),
            supportsProAudio = packageManager.hasSystemFeature(PackageManager.FEATURE_AUDIO_PRO),
            supportsUnprocessedAudio = supportsUnprocessed,
            nativeSampleRate = sampleRate,
            nativeFramesPerBuffer = framesPerBuffer
        )
    }
}
