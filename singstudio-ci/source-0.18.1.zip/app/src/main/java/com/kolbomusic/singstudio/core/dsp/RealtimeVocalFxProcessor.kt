package com.kolbomusic.singstudio.core.dsp

import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.pow
import kotlin.math.sin

/**
 * Allocation-free mono effects chain intended for preview/monitor callbacks.
 * Parameters are smoothed so moving a UI slider does not create zipper noise.
 */
class RealtimeVocalFxProcessor(private val sampleRate: Int) {
    private val delay = CircularDelay((sampleRate * 1.25).toInt().coerceAtLeast(1))
    private val preDelay = CircularDelay((sampleRate * 0.15).toInt().coerceAtLeast(1))
    private val combs = intArrayOf(1557, 1617, 1491, 1422).map { base ->
        CombFilter((base * sampleRate / 44_100.0).toInt().coerceAtLeast(16))
    }
    private val allPasses = intArrayOf(225, 556).map { base ->
        AllPassFilter((base * sampleRate / 44_100.0).toInt().coerceAtLeast(8), 0.5f)
    }

    private var wetReverb = 0.2f
    private var room = 0.68f
    private var wetDelay = 0.1f
    private var feedback = 0.28f
    private var delaySamples = (0.28f * sampleRate).toInt()
    private var gain = 1f
    private var lowPassState = 0f

    fun reset() {
        delay.clear()
        preDelay.clear()
        combs.forEach { it.clear() }
        allPasses.forEach { it.clear() }
        lowPassState = 0f
    }

    fun processInPlace(buffer: FloatArray, offset: Int, length: Int, settings: VocalFxSettings) {
        val s = settings.sanitized()
        if (!s.enabled) return
        val end = (offset + length).coerceAtMost(buffer.size)
        val targetGain = 10.0.pow(s.outputGainDb / 20.0).toFloat()
        val targetDelaySamples = (s.delayMs * sampleRate / 1000f).toInt().coerceIn(1, delay.capacity - 1)
        for (i in offset until end) {
            // Fast exponential parameter smoothing (~10-30ms depending on callback size).
            wetReverb += (s.reverbMix - wetReverb) * 0.0035f
            room += (s.reverbRoom - room) * 0.0035f
            wetDelay += (s.delayMix - wetDelay) * 0.0035f
            feedback += (s.delayFeedback - feedback) * 0.0035f
            delaySamples += ((targetDelaySamples - delaySamples) * 0.0025f).toInt().let { if (it == 0) (targetDelaySamples - delaySamples).coerceIn(-1, 1) else it }
            gain += (targetGain - gain) * 0.0035f

            val dry = buffer[i]
            val delayed = delay.read(delaySamples)
            // Darken repeats slightly so delay sits behind the vocal.
            lowPassState += 0.18f * (delayed - lowPassState)
            delay.write((dry + lowPassState * feedback).coerceIn(-1.2f, 1.2f))

            val pre = preDelay.process(dry, (sampleRate * 0.018f).toInt())
            var reverb = 0f
            val combFeedback = (0.66f + room * 0.27f).coerceIn(0.55f, 0.92f)
            for (comb in combs) reverb += comb.process(pre, combFeedback)
            reverb /= combs.size
            for (allPass in allPasses) reverb = allPass.process(reverb)

            val mixed = dry + delayed * wetDelay + reverb * wetReverb
            buffer[i] = softLimit(mixed * gain)
        }
    }

    private fun softLimit(x: Float): Float {
        // Smooth saturation near 0 dBFS; deterministic and inexpensive in audio callbacks.
        val ax = kotlin.math.abs(x)
        return if (ax <= 0.86f) x else {
            val sign = if (x < 0f) -1f else 1f
            val over = (ax - 0.86f) / 0.14f
            sign * (0.86f + 0.14f * (1f - exp(-over.toDouble())).toFloat())
        }.coerceIn(-0.999f, 0.999f)
    }

    private class CircularDelay(val capacity: Int) {
        private val data = FloatArray(capacity)
        private var writeIndex = 0

        fun read(delaySamples: Int): Float {
            var index = writeIndex - delaySamples.coerceIn(1, capacity - 1)
            if (index < 0) index += capacity
            return data[index]
        }

        fun write(value: Float) {
            data[writeIndex] = value
            writeIndex++
            if (writeIndex >= capacity) writeIndex = 0
        }

        fun process(value: Float, delaySamples: Int): Float {
            val out = read(delaySamples.coerceIn(1, capacity - 1))
            write(value)
            return out
        }

        fun clear() {
            data.fill(0f)
            writeIndex = 0
        }
    }

    private class CombFilter(size: Int) {
        private val data = FloatArray(size)
        private var index = 0
        private var dampingState = 0f

        fun process(input: Float, feedback: Float): Float {
            val out = data[index]
            dampingState = out * 0.72f + dampingState * 0.28f
            data[index] = (input + dampingState * feedback).coerceIn(-1.5f, 1.5f)
            index++
            if (index >= data.size) index = 0
            return out
        }

        fun clear() {
            data.fill(0f)
            index = 0
            dampingState = 0f
        }
    }

    private class AllPassFilter(size: Int, private val feedback: Float) {
        private val data = FloatArray(size)
        private var index = 0

        fun process(input: Float): Float {
            val delayed = data[index]
            val output = -input + delayed
            data[index] = input + delayed * feedback
            index++
            if (index >= data.size) index = 0
            return output
        }

        fun clear() {
            data.fill(0f)
            index = 0
        }
    }
}
