package com.kolbomusic.singstudio.core.delivery

import com.kolbomusic.singstudio.core.export.ExportResolution
import com.kolbomusic.singstudio.core.export.ExportSettings
import com.kolbomusic.singstudio.core.export.ExportVideoCodec
import com.kolbomusic.singstudio.core.model.OutputAspectRatio

enum class PlatformExportPreset(
    val labelHe: String,
    val subtitleHe: String,
    val recommendedAspect: OutputAspectRatio,
    val resolution: ExportResolution,
    val frameRate: Int
) {
    Reels("Instagram / Reels", "9:16 · 1080p · H.264", OutputAspectRatio.Portrait9x16, ExportResolution.FullHD1080, 30),
    TikTok("TikTok", "9:16 · 1080p · H.264", OutputAspectRatio.Portrait9x16, ExportResolution.FullHD1080, 30),
    Shorts("YouTube Shorts", "9:16 · 1080p · H.264", OutputAspectRatio.Portrait9x16, ExportResolution.FullHD1080, 30),
    YouTube("YouTube", "16:9 · 1080p · H.264", OutputAspectRatio.Landscape16x9, ExportResolution.FullHD1080, 30),
    Facebook("Facebook", "1080p · H.264 · לפי יחס הפרויקט", OutputAspectRatio.Portrait9x16, ExportResolution.FullHD1080, 30),
    Compact("חסכוני", "720p · H.264", OutputAspectRatio.Portrait9x16, ExportResolution.HD720, 30)
    ;

    fun applyTo(current: ExportSettings): ExportSettings = current.copy(
        resolution = resolution,
        codec = ExportVideoCodec.H264,
        frameRate = frameRate,
        allowCodecFallback = true
    )
}
