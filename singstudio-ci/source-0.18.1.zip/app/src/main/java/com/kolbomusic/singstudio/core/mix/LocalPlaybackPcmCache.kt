package com.kolbomusic.singstudio.core.mix

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import com.kolbomusic.singstudio.core.audio.WavFileTools
import com.kolbomusic.singstudio.core.model.PlaybackSource
import com.kolbomusic.singstudio.core.model.PlaybackSourceType
import java.io.File
import java.nio.ByteOrder

/**
 * Decodes a local backing track once into a deterministic PCM16 WAV cache.
 * YouTube is intentionally rejected: it is never extracted or downloaded.
 */
class LocalPlaybackPcmCache(private val context: Context) {
    fun prepare(
        source: PlaybackSource,
        shouldCancel: () -> Boolean = { false },
        onProgress: (Float) -> Unit = {}
    ): File {
        require(source.type != PlaybackSourceType.YouTube) { "YouTube אינו נתמך בחילוץ אודיו" }
        val uri = source.uriString?.let(Uri::parse) ?: error("חסר URI לפלייבק המקומי")
        val cacheDir = File(context.filesDir, "session_mix_cache").also { it.mkdirs() }
        val safeId = source.id.replace(Regex("[^A-Za-z0-9._-]"), "_")
        val output = File(cacheDir, "$safeId-backing.wav")
        if (output.exists() && output.length() > 44L && runCatching { Pcm16InterleavedWavReader(output).use { it.frameCount > 0 } }.getOrDefault(false)) {
            onProgress(1f)
            return output
        }

        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        var writer: Pcm16InterleavedWavWriter? = null
        try {
            extractor.setDataSource(context, uri, null)
            val trackIndex = (0 until extractor.trackCount).firstOrNull { index ->
                extractor.getTrackFormat(index).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true
            } ?: error("לא נמצאה רצועת אודיו בפלייבק")
            extractor.selectTrack(trackIndex)
            val inputFormat = extractor.getTrackFormat(trackIndex)
            val mime = inputFormat.getString(MediaFormat.KEY_MIME) ?: error("פורמט אודיו לא מזוהה")
            val durationUs = inputFormat.longOrNull(MediaFormat.KEY_DURATION) ?: 0L
            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(inputFormat, null, null, 0)
            codec.start()

            val info = MediaCodec.BufferInfo()
            var inputEnded = false
            var outputEnded = false
            var outputSampleRate = inputFormat.intOrNull(MediaFormat.KEY_SAMPLE_RATE) ?: 48_000
            var outputChannels = (inputFormat.intOrNull(MediaFormat.KEY_CHANNEL_COUNT) ?: 2).coerceAtLeast(1)
            var pcmEncoding = AudioFormat.ENCODING_PCM_16BIT
            var writerChannels = if (outputChannels >= 2) 2 else 1
            var floatBlock = FloatArray(16 * 1024)

            fun ensureWriter() {
                if (writer == null) {
                    writerChannels = if (outputChannels >= 2) 2 else 1
                    writer = Pcm16InterleavedWavWriter(output, outputSampleRate, writerChannels)
                }
            }

            while (!outputEnded && !shouldCancel()) {
                if (!inputEnded) {
                    val inputIndex = codec.dequeueInputBuffer(10_000L)
                    if (inputIndex >= 0) {
                        val inputBuffer = codec.getInputBuffer(inputIndex) ?: error("Decoder input buffer unavailable")
                        inputBuffer.clear()
                        val size = extractor.readSampleData(inputBuffer, 0)
                        if (size < 0) {
                            codec.queueInputBuffer(inputIndex, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputEnded = true
                        } else {
                            codec.queueInputBuffer(inputIndex, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }

                when (val outputIndex = codec.dequeueOutputBuffer(info, 10_000L)) {
                    MediaCodec.INFO_TRY_AGAIN_LATER -> Unit
                    MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        check(writer == null) { "Decoder changed format after PCM output started" }
                        val format = codec.outputFormat
                        outputSampleRate = format.intOrNull(MediaFormat.KEY_SAMPLE_RATE) ?: outputSampleRate
                        outputChannels = (format.intOrNull(MediaFormat.KEY_CHANNEL_COUNT) ?: outputChannels).coerceAtLeast(1)
                        pcmEncoding = format.intOrNull(MediaFormat.KEY_PCM_ENCODING) ?: AudioFormat.ENCODING_PCM_16BIT
                    }
                    else -> if (outputIndex >= 0) {
                        val outputBuffer = codec.getOutputBuffer(outputIndex)
                        if (outputBuffer != null && info.size > 0) {
                            ensureWriter()
                            val slice = outputBuffer.duplicate().apply {
                                position(info.offset)
                                limit(info.offset + info.size)
                                order(ByteOrder.LITTLE_ENDIAN)
                            }.slice().order(ByteOrder.LITTLE_ENDIAN)

                            val inputFrames = when (pcmEncoding) {
                                AudioFormat.ENCODING_PCM_FLOAT -> slice.remaining() / 4 / outputChannels
                                else -> slice.remaining() / 2 / outputChannels
                            }
                            val requiredSamples = inputFrames * writerChannels
                            if (floatBlock.size < requiredSamples) floatBlock = FloatArray(requiredSamples)

                            when (pcmEncoding) {
                                AudioFormat.ENCODING_PCM_FLOAT -> {
                                    val floats = slice.asFloatBuffer()
                                    repeat(inputFrames) { frame ->
                                        if (writerChannels == 1) {
                                            var sum = 0f
                                            repeat(outputChannels) { sum += floats.get() }
                                            floatBlock[frame] = (sum / outputChannels).coerceIn(-1f, 1f)
                                        } else {
                                            var left = 0f
                                            var right = 0f
                                            repeat(outputChannels) { ch ->
                                                val sample = floats.get()
                                                if (ch % 2 == 0) left += sample else right += sample
                                            }
                                            val leftCount = (outputChannels + 1) / 2
                                            val rightCount = outputChannels / 2
                                            floatBlock[frame * 2] = (left / leftCount.coerceAtLeast(1)).coerceIn(-1f, 1f)
                                            floatBlock[frame * 2 + 1] = (right / rightCount.coerceAtLeast(1)).coerceIn(-1f, 1f)
                                        }
                                    }
                                }
                                else -> {
                                    val shorts = slice.asShortBuffer()
                                    repeat(inputFrames) { frame ->
                                        if (writerChannels == 1) {
                                            var sum = 0f
                                            repeat(outputChannels) { sum += shorts.get() / 32768f }
                                            floatBlock[frame] = (sum / outputChannels).coerceIn(-1f, 1f)
                                        } else {
                                            var left = 0f
                                            var right = 0f
                                            repeat(outputChannels) { ch ->
                                                val sample = shorts.get() / 32768f
                                                if (ch % 2 == 0) left += sample else right += sample
                                            }
                                            val leftCount = (outputChannels + 1) / 2
                                            val rightCount = outputChannels / 2
                                            floatBlock[frame * 2] = (left / leftCount.coerceAtLeast(1)).coerceIn(-1f, 1f)
                                            floatBlock[frame * 2 + 1] = (right / rightCount.coerceAtLeast(1)).coerceIn(-1f, 1f)
                                        }
                                    }
                                }
                            }
                            writer?.writeInterleaved(floatBlock, 0, requiredSamples)
                        }
                        if (durationUs > 0L && info.presentationTimeUs >= 0L) {
                            onProgress((info.presentationTimeUs.toDouble() / durationUs).toFloat().coerceIn(0f, 0.98f))
                        }
                        outputEnded = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                        codec.releaseOutputBuffer(outputIndex, false)
                    }
                }
            }

            if (shouldCancel()) error("הכנת הפלייבק בוטלה")
            val committed = writer?.commit() ?: error("לא התקבל PCM מהפלייבק")
            writer = null
            Pcm16InterleavedWavReader(committed).use { reader ->
                check(reader.frameCount > 0L) { "Backing cache ריק" }
            }
            onProgress(1f)
            return committed
        } catch (error: Throwable) {
            runCatching { writer?.close() }
            output.delete()
            throw error
        } finally {
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            runCatching { extractor.release() }
        }
    }

    private fun MediaFormat.intOrNull(key: String): Int? =
        if (containsKey(key)) runCatching { getInteger(key) }.getOrNull() else null

    private fun MediaFormat.longOrNull(key: String): Long? =
        if (containsKey(key)) runCatching { getLong(key) }.getOrNull() else null
}
