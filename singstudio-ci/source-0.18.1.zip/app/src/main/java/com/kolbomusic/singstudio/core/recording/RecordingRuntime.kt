package com.kolbomusic.singstudio.core.recording

import android.content.Context
import com.kolbomusic.singstudio.core.audio.Pcm16AudioRecorder

object RecordingRuntime {
    @Volatile
    private var instance: Pcm16AudioRecorder? = null

    fun recorder(context: Context): Pcm16AudioRecorder {
        return instance ?: synchronized(this) {
            instance ?: Pcm16AudioRecorder(context.applicationContext).also { instance = it }
        }
    }
}
