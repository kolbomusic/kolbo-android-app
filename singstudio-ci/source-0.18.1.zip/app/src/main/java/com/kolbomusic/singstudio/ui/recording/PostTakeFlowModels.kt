package com.kolbomusic.singstudio.ui.recording

enum class PostTakeStage {
    Idle,
    PreparingVocal,
    PreparingMix,
    Mastering,
    RenderingVideo,
    VerifyingVideo,
    ReadyToSave,
    Error
}

data class PostTakeState(
    val stage: PostTakeStage = PostTakeStage.Idle,
    val progress: Float = 0f,
    val message: String? = null,
    val errorMessage: String? = null
) {
    val preparing: Boolean
        get() = stage == PostTakeStage.PreparingVocal ||
            stage == PostTakeStage.PreparingMix ||
            stage == PostTakeStage.Mastering ||
            stage == PostTakeStage.RenderingVideo ||
            stage == PostTakeStage.VerifyingVideo

    val readyToSave: Boolean
        get() = stage == PostTakeStage.ReadyToSave
}
