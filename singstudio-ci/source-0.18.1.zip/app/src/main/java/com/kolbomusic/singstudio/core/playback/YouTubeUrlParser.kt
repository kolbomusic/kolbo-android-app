package com.kolbomusic.singstudio.core.playback

import android.net.Uri

object YouTubeUrlParser {
    private val validId = Regex("^[A-Za-z0-9_-]{11}$")

    fun extractVideoId(rawUrl: String?): String? {
        if (rawUrl.isNullOrBlank()) return null
        val uri = runCatching { Uri.parse(rawUrl) }.getOrNull() ?: return null
        val host = uri.host?.lowercase().orEmpty().removePrefix("www.").removePrefix("m.")

        val candidate = when {
            host == "youtu.be" -> uri.pathSegments.firstOrNull()
            host.endsWith("youtube.com") && uri.path == "/watch" -> uri.getQueryParameter("v")
            host.endsWith("youtube.com") && uri.pathSegments.firstOrNull() == "shorts" -> uri.pathSegments.getOrNull(1)
            host.endsWith("youtube.com") && uri.pathSegments.firstOrNull() == "embed" -> uri.pathSegments.getOrNull(1)
            else -> null
        }
        return candidate?.takeIf { validId.matches(it) }
    }
}
