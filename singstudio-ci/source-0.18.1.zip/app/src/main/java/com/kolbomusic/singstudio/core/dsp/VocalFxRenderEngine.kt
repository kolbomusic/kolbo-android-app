package com.kolbomusic.singstudio.core.dsp

import com.kolbomusic.singstudio.core.audio.WavFileTools
import org.json.JSONObject
import java.io.File
import kotlin.math.ceil


data class VocalFxRenderResult(
    val outputFilePath: String,
    val outputSha256: String
)

class VocalFxRenderEngine {
    fun render(
        processedVocal: File,
        settings: VocalFxSettings,
        onProgress: (Float) -> Unit = {}
    ): VocalFxRenderResult {
        require(WavFileTools.validatePcm16Mono(processedVocal)) { "קובץ הקול המעובד אינו WAV תקין" }
        val sourceShaBefore = WavFileTools.sha256(processedVocal)
        val safe = settings.sanitized()
        val outputDir = File(processedVocal.parentFile, "fx").also { it.mkdirs() }
        val output = File(outputDir, processedVocal.nameWithoutExtension + "-fx.wav")

        var sampleRate = 0
        var sourceFrames = 0L
        var tailSeconds = 0f
        Pcm16WavRandomAccessReader(processedVocal).use { reader ->
            sampleRate = reader.sampleRate
            sourceFrames = reader.frameCount
            tailSeconds = (
                0.65f + safe.reverbRoom * 2.6f + safe.delayFeedback * 1.8f + safe.delayMs / 1000f
            ).coerceIn(0.8f, 5.0f)
            val tailFrames = ceil(sampleRate * tailSeconds).toLong()
            val totalFrames = sourceFrames + tailFrames
            val processor = RealtimeVocalFxProcessor(sampleRate)
            val block = FloatArray(1024)
            var frame = 0L

            Pcm16WavAtomicStreamWriter(output, sampleRate).use { writer ->
                while (frame < sourceFrames) {
                    val wanted = minOf(block.size.toLong(), sourceFrames - frame).toInt()
                    val read = reader.readFrames(frame, block, 0, wanted)
                    check(read > 0) { "קריאת processed vocal נקטעה" }
                    processor.processInPlace(block, 0, read, safe)
                    writer.write(block, 0, read)
                    frame += read
                    if ((frame / block.size) % 16L == 0L) {
                        onProgress(frame.toFloat() / totalFrames)
                    }
                }

                var tailWritten = 0L
                while (tailWritten < tailFrames) {
                    val count = minOf(block.size.toLong(), tailFrames - tailWritten).toInt()
                    block.fill(0f, 0, count)
                    processor.processInPlace(block, 0, count, safe)
                    writer.write(block, 0, count)
                    tailWritten += count
                    if ((tailWritten / block.size) % 16L == 0L || tailWritten == tailFrames) {
                        onProgress((sourceFrames + tailWritten).toFloat() / totalFrames)
                    }
                }
                writer.commit()
            }
        }

        check(WavFileTools.validatePcm16Mono(output)) { "קובץ FX סופי נכשל באימות WAV" }
        val outputSha = WavFileTools.sha256(output)
        val sourceShaAfter = WavFileTools.sha256(processedVocal)
        check(sourceShaBefore == sourceShaAfter) { "Processed vocal integrity check failed" }

        val metadata = JSONObject()
            .put("schema", 1)
            .put("engine", "KolboLiveVocalFx")
            .put("engineVersion", "0.6.0")
            .put("sourceFile", processedVocal.name)
            .put("sourceSha256", sourceShaBefore)
            .put("outputFile", output.name)
            .put("outputSha256", outputSha)
            .put("sampleRate", sampleRate)
            .put("sourceFrames", sourceFrames)
            .put("tailSeconds", tailSeconds)
            .put("reverbMix", safe.reverbMix)
            .put("reverbRoom", safe.reverbRoom)
            .put("delayMix", safe.delayMix)
            .put("delayFeedback", safe.delayFeedback)
            .put("delayMs", safe.delayMs)
            .put("delayDivision", safe.delayDivision.name)
            .put("outputGainDb", safe.outputGainDb)
        File(output.parentFile, output.nameWithoutExtension + ".json")
            .writeText(metadata.toString(2), Charsets.UTF_8)
        onProgress(1f)
        return VocalFxRenderResult(output.absolutePath, outputSha)
    }
}
