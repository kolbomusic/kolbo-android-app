@file:androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)

package com.kolbomusic.singstudio.core.export

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.Typeface
import androidx.media3.effect.CanvasOverlay
import com.kolbomusic.singstudio.core.editor.TextAnimationPreset
import com.kolbomusic.singstudio.core.editor.TextFontPreset
import com.kolbomusic.singstudio.core.editor.TitleOverlay
import kotlin.math.min

class KolboTitleCanvasOverlay(
    title: TitleOverlay,
    private val density: Float,
    private val startMs: Long,
    private val endMs: Long
) : CanvasOverlay(true) {
    private val safeTitle = title.sanitized()
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; style = Paint.Style.STROKE }

    override fun onDraw(canvas: Canvas, presentationTimeUs: Long) {
        canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
        val timeMs = presentationTimeUs / 1000L
        if (safeTitle.text.isBlank() || timeMs !in startMs until endMs) return

        val animation = animationAt(timeMs)
        val sizePx = safeTitle.fontSizeSp * density * animation.scale
        val typeface = when (safeTitle.fontPreset) {
            TextFontPreset.Clean -> Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
            TextFontPreset.Bold -> Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            TextFontPreset.Elegant -> Typeface.create("serif", Typeface.NORMAL)
            TextFontPreset.Handwritten -> Typeface.create("cursive", Typeface.NORMAL)
        }
        val colorInt = safeTitle.colorArgb.toInt()
        val centerX = canvas.width * safeTitle.xNormalized + animation.offsetX * canvas.width
        val centerY = canvas.height * safeTitle.yNormalized
        val lines = safeTitle.text.split('\n').take(3)
        val lineHeight = sizePx * 1.15f
        val blockHeight = lineHeight * lines.size
        val firstBaseline = centerY - blockHeight / 2f + sizePx

        fillPaint.typeface = typeface
        fillPaint.textSize = sizePx
        fillPaint.color = colorInt
        fillPaint.alpha = (255 * animation.alpha).toInt().coerceIn(0, 255)
        if (safeTitle.shadow) fillPaint.setShadowLayer(sizePx * 0.08f, sizePx * 0.035f, sizePx * 0.045f, Color.argb(190, 0, 0, 0))
        else fillPaint.clearShadowLayer()

        strokePaint.typeface = typeface
        strokePaint.textSize = sizePx
        strokePaint.strokeWidth = (sizePx * 0.075f).coerceAtLeast(2f)
        strokePaint.color = Color.BLACK
        strokePaint.alpha = (235 * animation.alpha).toInt().coerceIn(0, 235)

        lines.forEachIndexed { index, line ->
            val baseline = firstBaseline + index * lineHeight
            if (safeTitle.outline) canvas.drawText(line, centerX, baseline, strokePaint)
            canvas.drawText(line, centerX, baseline, fillPaint)
        }
    }

    private fun animationAt(timeMs: Long): FrameAnimation {
        val local = (timeMs - startMs).coerceAtLeast(0L)
        val remaining = (endMs - timeMs).coerceAtLeast(0L)
        val fadeIn = (local / 320f).coerceIn(0f, 1f)
        val fadeOut = (remaining / 320f).coerceIn(0f, 1f)
        val alpha = min(fadeIn, fadeOut)
        return when (safeTitle.animation) {
            TextAnimationPreset.None -> FrameAnimation(1f, 1f, 0f)
            TextAnimationPreset.Fade -> FrameAnimation(alpha, 1f, 0f)
            TextAnimationPreset.Pop -> FrameAnimation(alpha, 0.82f + 0.18f * fadeIn, 0f)
            TextAnimationPreset.Slide -> FrameAnimation(alpha, 1f, -0.12f * (1f - fadeIn))
        }
    }

    private data class FrameAnimation(val alpha: Float, val scale: Float, val offsetX: Float)
}
