package com.kolbomusic.singstudio.core.playback

object PlaybackSyncMath {
    fun offsetMs(recordingStartedElapsedNs: Long, playbackStartedElapsedNs: Long): Long {
        if (recordingStartedElapsedNs <= 0L || playbackStartedElapsedNs <= 0L) return 0L
        return ((playbackStartedElapsedNs - recordingStartedElapsedNs) / 1_000_000L)
            .coerceAtLeast(0L)
    }
}
