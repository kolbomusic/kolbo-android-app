package com.kolbomusic.singstudio.ui.recording

import android.app.Application
import android.net.Uri
import android.os.SystemClock
import androidx.annotation.OptIn
import androidx.lifecycle.AndroidViewModel
import androidx.media3.common.util.UnstableApi
import androidx.lifecycle.viewModelScope
import com.kolbomusic.singstudio.core.audio.WavFileTools
import com.kolbomusic.singstudio.core.camera.CameraCaptureEngine
import com.kolbomusic.singstudio.core.device.DeviceCapabilityProbe
import com.kolbomusic.singstudio.core.device.RuntimeHealthProbe
import com.kolbomusic.singstudio.core.device.RuntimeHealthState
import com.kolbomusic.singstudio.core.dsp.DspStage
import com.kolbomusic.singstudio.core.dsp.DspUiState
import com.kolbomusic.singstudio.core.dsp.VocalDspEngine
import com.kolbomusic.singstudio.core.dsp.StreamingVocalDspEngine
import com.kolbomusic.singstudio.core.dsp.SafeVocalDspEngine
import com.kolbomusic.singstudio.core.dsp.DspRenderResult
import com.kolbomusic.singstudio.core.dsp.BeatDivision
import com.kolbomusic.singstudio.core.dsp.LiveVocalPreviewPlayer
import com.kolbomusic.singstudio.core.dsp.PreviewSource
import com.kolbomusic.singstudio.core.dsp.SmartFxAdvisor
import com.kolbomusic.singstudio.core.dsp.TapTempoTracker
import com.kolbomusic.singstudio.core.dsp.TempoSource
import com.kolbomusic.singstudio.core.dsp.TempoSync
import com.kolbomusic.singstudio.core.dsp.VocalEditorState
import com.kolbomusic.singstudio.core.dsp.VocalFxMetadataStore
import com.kolbomusic.singstudio.core.dsp.VocalFxRenderEngine
import com.kolbomusic.singstudio.core.dsp.VocalFxSettings
import com.kolbomusic.singstudio.core.dsp.VocalPresetId
import com.kolbomusic.singstudio.core.model.CameraSyncMarker
import com.kolbomusic.singstudio.core.model.DeviceCapabilities
import com.kolbomusic.singstudio.core.model.PlaybackSource
import com.kolbomusic.singstudio.core.model.PlaybackState
import com.kolbomusic.singstudio.core.model.PlaybackSourceType
import com.kolbomusic.singstudio.core.model.PlaybackSyncMarker
import com.kolbomusic.singstudio.core.model.RecordingPhase
import com.kolbomusic.singstudio.core.model.RecordingState
import com.kolbomusic.singstudio.core.model.VisualScene
import com.kolbomusic.singstudio.core.mix.LocalPlaybackPcmCache
import com.kolbomusic.singstudio.core.mix.VoiceOnlyBacking
import com.kolbomusic.singstudio.core.mix.AutomaticMasteringEngine
import com.kolbomusic.singstudio.core.mix.AutomaticMixGainStager
import com.kolbomusic.singstudio.core.mix.SessionMixPreviewPlayer
import com.kolbomusic.singstudio.core.mix.SessionMixRenderEngine
import com.kolbomusic.singstudio.core.mix.SessionMixSettings
import com.kolbomusic.singstudio.core.mix.SessionMixState
import com.kolbomusic.singstudio.core.editor.RestoredVideoProject
import com.kolbomusic.singstudio.core.editor.TextAnimationPreset
import com.kolbomusic.singstudio.core.editor.TextFontPreset
import com.kolbomusic.singstudio.core.editor.VideoProjectMetadataStore
import com.kolbomusic.singstudio.core.editor.VideoProjectState
import com.kolbomusic.singstudio.core.export.CompositionFactory
import com.kolbomusic.singstudio.core.export.CompositionPreviewEngine
import com.kolbomusic.singstudio.core.export.CompositionPreviewState
import com.kolbomusic.singstudio.core.export.ExportPlanBuilder
import com.kolbomusic.singstudio.core.export.ExportResolution
import com.kolbomusic.singstudio.core.export.ExportSettings
import com.kolbomusic.singstudio.core.export.ExportState
import com.kolbomusic.singstudio.core.export.ExportVideoCodec
import com.kolbomusic.singstudio.core.export.ExportPhase
import com.kolbomusic.singstudio.core.delivery.DeliveryPhase
import com.kolbomusic.singstudio.core.delivery.DeliveryState
import com.kolbomusic.singstudio.core.delivery.MediaStorePublisher
import com.kolbomusic.singstudio.core.delivery.PlatformExportPreset
import com.kolbomusic.singstudio.core.library.LibraryRepository
import com.kolbomusic.singstudio.core.export.Media3ExportEngine
import com.kolbomusic.singstudio.core.playback.LocalPlaybackTempoAnalyzer
import com.kolbomusic.singstudio.core.playback.LocalMediaResolver
import com.kolbomusic.singstudio.core.playback.PlaybackControl
import com.kolbomusic.singstudio.core.playback.ProductionSourcePolicy
import com.kolbomusic.singstudio.core.nativeaudio.LowLatencyAudioCapability
import com.kolbomusic.singstudio.core.nativeaudio.OboeAudioProbe
import com.kolbomusic.singstudio.core.recording.RecordingController
import com.kolbomusic.singstudio.core.recording.RecordingRuntime
import kotlinx.coroutines.Job
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.util.concurrent.atomic.AtomicLong

@OptIn(UnstableApi::class)
class RecordingViewModel(application: Application) : AndroidViewModel(application) {
    private val controller = RecordingController(application)
    private val recorder = RecordingRuntime.recorder(application)

    val recordingState: StateFlow<RecordingState> = recorder.state
    val capabilities: DeviceCapabilities = DeviceCapabilityProbe(application).probe()
    private val runtimeHealthProbe = RuntimeHealthProbe(application)
    private val _runtimeHealth = MutableStateFlow(RuntimeHealthState())
    val runtimeHealth: StateFlow<RuntimeHealthState> = _runtimeHealth.asStateFlow()

    private val _playbackState = MutableStateFlow(PlaybackState())
    val playbackState: StateFlow<PlaybackState> = _playbackState.asStateFlow()

    private val _countdown = MutableStateFlow<Int?>(null)
    val countdown: StateFlow<Int?> = _countdown.asStateFlow()

    private val _sessionMessage = MutableStateFlow<String?>(null)
    val sessionMessage: StateFlow<String?> = _sessionMessage.asStateFlow()

    private val _postTakeState = MutableStateFlow(PostTakeState())
    val postTakeState: StateFlow<PostTakeState> = _postTakeState.asStateFlow()
    private var postTakePrepareJob: Job? = null
    private var pendingExportStart = false

    private val dspEngine = VocalDspEngine()
    private val streamingDspEngine = StreamingVocalDspEngine()
    private val safeDspEngine = SafeVocalDspEngine()
    private val fxRenderEngine = VocalFxRenderEngine()
    private val _dspState = MutableStateFlow(DspUiState())
    val dspState: StateFlow<DspUiState> = _dspState.asStateFlow()
    private var dspJob: Job? = null

    private val _editorState = MutableStateFlow(VocalEditorState())
    val editorState: StateFlow<VocalEditorState> = _editorState.asStateFlow()

    private val localPlaybackPcmCache = LocalPlaybackPcmCache(application)
    private val sessionMixRenderEngine = SessionMixRenderEngine()
    private val automaticMasteringEngine = AutomaticMasteringEngine()
    private val automaticMixGainStager = AutomaticMixGainStager()
    private val _sessionMixState = MutableStateFlow(SessionMixState())
    val sessionMixState: StateFlow<SessionMixState> = _sessionMixState.asStateFlow()
    private var sessionMixPlayer: SessionMixPreviewPlayer? = null
    private var sessionMixCollectJob: Job? = null
    private var sessionMixPrepareJob: Job? = null
    private var sessionMixRenderJob: Job? = null

    private val _videoProjectState = MutableStateFlow(VideoProjectState())
    val videoProjectState: StateFlow<VideoProjectState> = _videoProjectState.asStateFlow()

    private val exportEngine = Media3ExportEngine(application)
    val exportState: StateFlow<ExportState> = exportEngine.state
    private val libraryRepository = LibraryRepository(application)
    private val mediaStorePublisher = MediaStorePublisher(application)
    private val _deliveryState = MutableStateFlow(DeliveryState())
    val deliveryState: StateFlow<DeliveryState> = _deliveryState.asStateFlow()
    private var lastIndexedExportPath: String? = null
    private var lastIndexedTakePath: String? = null
    private val compositionPreviewEngine = CompositionPreviewEngine(application)
    val compositionPreviewState: StateFlow<CompositionPreviewState> = compositionPreviewEngine.state
    val compositionPreviewPlayer get() = compositionPreviewEngine.player

    private val _lowLatencyCapability = MutableStateFlow(
        LowLatencyAudioCapability(available = false, rawReport = "PENDING")
    )
    val lowLatencyCapability: StateFlow<LowLatencyAudioCapability> = _lowLatencyCapability.asStateFlow()

    private val tapTempo = TapTempoTracker()
    private var previewPlayer: LiveVocalPreviewPlayer? = null
    private var previewCollectJob: Job? = null
    private var tempoJob: Job? = null
    private val tempoGeneration = AtomicLong(0L)
    private var fxPersistJob: Job? = null

    private var playbackControl: PlaybackControl? = null
    private var playbackSource: PlaybackSource? = null
    private val _productionBackingSource = MutableStateFlow<PlaybackSource?>(null)
    val productionBackingSource: StateFlow<PlaybackSource?> = _productionBackingSource.asStateFlow()
    private var playbackCollectJob: Job? = null
    private var takeCoordinatorJob: Job? = null
    private var cameraEngine: CameraCaptureEngine? = null
    private var visualScene: VisualScene? = null
    private var activeSessionIdentity: String? = null
    // Latched at take finalization. Post-production must not depend on mutable recorder
    // state because reset/restore/UI transitions may change that state asynchronously.
    @Volatile private var lastSavedRawPath: String? = null
    @Volatile private var lastProcessedRawPath: String? = null
    @Volatile private var lastPlaybackStartOffsetMs: Long? = null

    init {
        viewModelScope.launch(Dispatchers.IO) {
            val capability = OboeAudioProbe.probe()
            _lowLatencyCapability.value = capability
            _runtimeHealth.value = runtimeHealthProbe.snapshot()
        }
        viewModelScope.launch {
            recordingState.collect { state ->
                val path = state.savedFilePath
                if (state.phase == RecordingPhase.Saved && path != null) {
                    lastSavedRawPath = path
                    state.playbackStartOffsetMs?.let { lastPlaybackStartOffsetMs = it }
                    if (path != lastIndexedTakePath) {
                        lastIndexedTakePath = path
                        indexSavedTake(path)
                    }
                }
            }
        }
        viewModelScope.launch {
            exportState.collect { state ->
                if (recordingState.value.phase == RecordingPhase.Saved) {
                    when (state.phase) {
                        ExportPhase.Preparing, ExportPhase.Exporting -> _postTakeState.value = PostTakeState(
                            stage = PostTakeStage.RenderingVideo,
                            progress = 0.90f + (state.progressPercent.coerceIn(0, 99) / 100f) * 0.07f,
                            message = state.message ?: "יוצר אוטומטית את הסרטון הסופי"
                        )
                        ExportPhase.Verifying -> _postTakeState.value = PostTakeState(
                            stage = PostTakeStage.VerifyingVideo,
                            progress = 0.98f,
                            message = "בודק שהסרטון והסאונד תקינים"
                        )
                        ExportPhase.Completed -> _postTakeState.value = PostTakeState(
                            stage = PostTakeStage.ReadyToSave,
                            progress = 1f,
                            message = "הביצוע מוכן לשמירה"
                        )
                        ExportPhase.Failed -> _postTakeState.value = PostTakeState(
                            stage = PostTakeStage.Error,
                            progress = 1f,
                            errorMessage = state.errorMessage ?: "יצירת הסרטון נכשלה"
                        )
                        else -> Unit
                    }
                }
                val path = state.outputPath
                if (state.phase == ExportPhase.Completed && path != null && path != lastIndexedExportPath) {
                    lastIndexedExportPath = path
                    indexCompletedExport(state)
                }
            }
        }
    }

    fun beginFreshSession(source: PlaybackSource, scene: VisualScene) {
        val identity = "fresh:${source.id}:${scene.mode.name}:${scene.aspectRatio.name}:${scene.cameraFacing.name}:${scene.background.id.orEmpty()}"
        if (activeSessionIdentity == identity && recorder.state.value.phase != RecordingPhase.Error) return
        if (recordingState.value.phase == RecordingPhase.Recording || recordingState.value.phase == RecordingPhase.Starting) return

        activeSessionIdentity = identity
        takeCoordinatorJob?.cancel()
        dspJob?.cancel()
        sessionMixRenderJob?.cancel()
        tempoGeneration.incrementAndGet()
        tempoJob?.cancel()
        releasePreview()
        releaseSessionMix()
        compositionPreviewEngine.invalidate()
        exportEngine.cancel()
        recorder.resetSavedState()
        playbackSource = source
        _productionBackingSource.value = ProductionSourcePolicy.automaticFor(source)
        visualScene = scene
        recorder.configureVisualScene(scene)
        _dspState.value = DspUiState()
        _editorState.value = VocalEditorState()
        _sessionMixState.value = SessionMixState()
        _videoProjectState.value = VideoProjectState(aspectRatio = scene.aspectRatio)
        _deliveryState.value = DeliveryState()
        _countdown.value = null
        _sessionMessage.value = null
        postTakePrepareJob?.cancel()
        postTakePrepareJob = null
        pendingExportStart = false
        _postTakeState.value = PostTakeState()
        lastIndexedExportPath = null
        lastIndexedTakePath = null
        lastSavedRawPath = null
        lastProcessedRawPath = null
        lastPlaybackStartOffsetMs = null
    }

    fun restoreProject(project: RestoredVideoProject) {
        val identity = "restore:${project.projectFilePath}"
        if (activeSessionIdentity == identity && recorder.state.value.savedFilePath == project.rawVocalPath) return
        if (recordingState.value.phase == RecordingPhase.Recording || recordingState.value.phase == RecordingPhase.Starting) {
            _sessionMessage.value = "אי אפשר לפתוח טיוטה בזמן הקלטה פעילה"
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            val raw = File(project.rawVocalPath)
            val processed = project.processedVocalPath?.let(::File)?.takeIf { it.isFile }
            val restoredMix = project.sessionMixPath?.let(::File)?.takeIf { it.isFile }
            val rawResult = recorder.restoreSavedTake(
                rawFilePath = raw.absolutePath,
                playbackStartOffsetMs = project.playbackStartOffsetMs,
                cameraStartOffsetMs = project.cameraStartOffsetMs,
                cameraFilePath = project.cameraFilePath
            )
            if (rawResult.isFailure) {
                withContext(Dispatchers.Main) {
                    _sessionMessage.value = rawResult.exceptionOrNull()?.message ?: "שחזור הטייק נכשל"
                }
                return@launch
            }

            val processedSha = processed?.let { runCatching { WavFileTools.sha256(it) }.getOrNull() }
            val mixSha = restoredMix?.let { runCatching { WavFileTools.sha256(it) }.getOrNull() }

            withContext(Dispatchers.Main) {
                releasePreview()
                releaseSessionMix()
                compositionPreviewEngine.invalidate()
                exportEngine.cancel()

                activeSessionIdentity = identity
                lastSavedRawPath = raw.absolutePath
                lastProcessedRawPath = processed?.let { raw.absolutePath }
                lastPlaybackStartOffsetMs = project.playbackStartOffsetMs
                visualScene = project.scene
                recorder.configureVisualScene(project.scene)
                playbackSource = project.playbackSource
                _productionBackingSource.value = project.productionBackingSource
                    ?: project.playbackSource?.let(ProductionSourcePolicy::automaticFor)
                _videoProjectState.value = project.state.copy(
                    savedProjectPath = project.projectFilePath,
                    errorMessage = null
                )
                _dspState.value = if (processed != null) {
                    DspUiState(
                        stage = DspStage.Completed,
                        progress = 1f,
                        selectedPreset = VocalPresetId.Auto,
                        resolvedPreset = VocalPresetId.Studio,
                        outputFilePath = processed.absolutePath,
                        outputSha256 = processedSha
                    )
                } else DspUiState()
                _editorState.value = VocalEditorState(
                    prepared = false,
                    settings = project.vocalFxSettings,
                    manuallyEdited = true
                )
                _sessionMixState.value = SessionMixState(
                    available = (_productionBackingSource.value ?: project.playbackSource)?.type?.let { it != PlaybackSourceType.YouTube } == true,
                    settings = project.sessionMixSettings,
                    renderedMixPath = restoredMix?.absolutePath,
                    renderedMixSha256 = mixSha
                )
                _deliveryState.value = DeliveryState()
                postTakePrepareJob?.cancel()
                postTakePrepareJob = null
                pendingExportStart = false
                _postTakeState.value = when {
                    project.playbackSource?.type == PlaybackSourceType.YouTube && _productionBackingSource.value == null -> PostTakeState(
                        stage = PostTakeStage.PreparingVocal,
                        progress = 0f,
                        message = "משלים עיבוד קול מההקלטה השמורה"
                    )
                    restoredMix != null -> PostTakeState(
                        stage = PostTakeStage.PreparingMix,
                        progress = 0.70f,
                        message = "משלים אוטומטית Mastering וסרטון סופי"
                    )
                    else -> PostTakeState()
                }
                lastIndexedTakePath = raw.absolutePath
                lastIndexedExportPath = null
                _sessionMessage.value = buildString {
                    append("הפרויקט שוחזר ✓")
                    if (project.migrated) append(" · הותאם לגרסה החדשה")
                    if (project.warnings.isNotEmpty()) append(" · ${project.warnings.first()}")
                }

                if (processed != null) {
                    prepareVocalEditor(raw, processed, VocalPresetId.Studio)
                }
                // The same single automatic pipeline resumes interrupted projects;
                // no manual "Session Mix" step and no YouTube backing file prompt.
                if (project.playbackSource != null && project.playbackStartOffsetMs != null) {
                    preparePostTakeForExport(raw.absolutePath, autoStartExport = true)
                }
            }
        }
    }

    fun configureScene(scene: VisualScene) {
        visualScene = scene
        recorder.configureVisualScene(scene)
    }

    fun attachCamera(engine: CameraCaptureEngine) {
        cameraEngine = engine
    }

    fun detachCamera(engine: CameraCaptureEngine) {
        if (cameraEngine === engine) cameraEngine = null
    }

    fun attachPlayback(source: PlaybackSource, control: PlaybackControl, preserveEditorSettings: Boolean = false) {
        if (playbackControl === control && playbackSource?.id == source.id) return
        playbackCollectJob?.cancel()
        playbackControl = control
        playbackSource = source
        _playbackState.value = control.state.value
        playbackCollectJob = viewModelScope.launch {
            control.state.collect { _playbackState.value = it }
        }
        if (!preserveEditorSettings) analyseTempoIfSupported(source)
    }

    fun detachPlayback(control: PlaybackControl) {
        if (playbackControl !== control) return
        takeCoordinatorJob?.cancel()
        playbackCollectJob?.cancel()
        tempoGeneration.incrementAndGet()
        tempoJob?.cancel()
        playbackCollectJob = null
        playbackControl = null
        playbackSource = null
        _playbackState.value = PlaybackState()
        _countdown.value = null
    }

    fun startSyncedTake() {
        val control = playbackControl ?: run {
            _sessionMessage.value = "הפלייבק עדיין לא מוכן"
            return
        }
        val source = playbackSource ?: return
        if (!ProductionSourcePolicy.canStartPerformance(source)) {
            _sessionMessage.value = "מקור השיר אינו זמין"
            return
        }
        val scene = visualScene ?: run {
            _sessionMessage.value = "הגדרת ההפקה חסרה"
            return
        }
        if (!control.state.value.prepared) {
            _sessionMessage.value = "הפלייבק עדיין נטען. נסה שוב בעוד רגע."
            return
        }
        if (scene.mode.usesCamera && cameraEngine == null) {
            _sessionMessage.value = "המצלמה עדיין לא מוכנה"
            return
        }
        if (takeCoordinatorJob?.isActive == true) return

        // A new take must never inherit DSP/mix/master/export artifacts from the
        // previous take. The old behavior could make automatic post-production skip
        // fresh vocal processing while the manual controls forced a rebuild.
        resetDerivedPostProductionForNewTake()
        if (_productionBackingSource.value?.let(ProductionSourcePolicy::isGeneratedVoiceOnlyBacking) == true) {
            _productionBackingSource.value = ProductionSourcePolicy.automaticFor(source)
        }

        // Tempo decoding is useful before editing but must never compete with a live take.
        tempoGeneration.incrementAndGet()
        tempoJob?.cancel()
        _editorState.value = _editorState.value.copy(tempoAnalysing = false)
        recorder.resetSavedState()
        recorder.configureVisualScene(scene)
        _sessionMessage.value = null
        control.pause()
        control.seekTo(0L)
        controller.start()

        takeCoordinatorJob = viewModelScope.launch {
            val recordingReady = withTimeoutOrNull(8_000L) {
                recorder.state
                    .filter { it.phase == RecordingPhase.Recording || it.phase == RecordingPhase.Error }
                    .first()
            }
            if (recordingReady == null || recordingReady.phase == RecordingPhase.Error) {
                _sessionMessage.value = recordingReady?.errorMessage ?: "המיקרופון לא התחיל בזמן"
                _countdown.value = null
                return@launch
            }

            if (scene.mode.usesCamera) {
                val engine = cameraEngine ?: run {
                    failTake("המצלמה אינה מחוברת")
                    return@launch
                }
                val takeId = recordingReady.activeTakeId ?: run {
                    failTake("לא התקבל מזהה טייק")
                    return@launch
                }
                val startRequest = engine.startRecording(takeId, scene.aspectRatio)
                if (startRequest.isFailure) {
                    failTake(startRequest.exceptionOrNull()?.message ?: "לא ניתן להתחיל צילום")
                    return@launch
                }
                val cameraStart = engine.awaitStarted().getOrElse { error ->
                    failTake(error.message ?: "המצלמה לא התחילה לצלם")
                    return@launch
                }
                recorder.markCameraStarted(
                    CameraSyncMarker(
                        filePath = cameraStart.expectedFinalFilePath,
                        startedElapsedRealtimeNs = cameraStart.startedElapsedRealtimeNs,
                        cameraFacing = scene.cameraFacing,
                        requestedAspectRatio = scene.aspectRatio
                    )
                )
            }

            for (value in 3 downTo 1) {
                _countdown.value = value
                delay(1_000L)
            }
            _countdown.value = 0

            val previousStart = control.state.value.startedElapsedRealtimeNs
            control.playFromStart()

            val actualStart = withTimeoutOrNull(12_000L) {
                control.state.filter { state ->
                    state.playing && state.startedElapsedRealtimeNs != null &&
                        state.startedElapsedRealtimeNs != previousStart
                }.first()
            }

            if (actualStart?.startedElapsedRealtimeNs == null) {
                failTake(control.state.value.errorMessage ?: "הפלייבק לא התחיל לנגן")
                return@launch
            }

            recorder.markPlaybackStarted(
                PlaybackSyncMarker(
                    sourceId = source.id,
                    sourceType = source.type.name,
                    sourceTitle = source.title,
                    playbackPositionMs = actualStart.positionMs,
                    startedElapsedRealtimeNs = actualStart.startedElapsedRealtimeNs
                )
            )
            _countdown.value = null

            control.state.filter { it.ended || it.errorMessage != null }.first().let { ended ->
                if (ended.errorMessage != null) {
                    _sessionMessage.value = ended.errorMessage
                }
            }
            finishTake(scene)
        }
    }

    fun stopSyncedTake() {
        takeCoordinatorJob?.cancel()
        takeCoordinatorJob = null
        _countdown.value = null
        playbackControl?.pause()
        val scene = visualScene
        viewModelScope.launch {
            finishTake(scene)
        }
    }

    private suspend fun finishTake(scene: VisualScene?) {
        playbackControl?.pause()
        if (scene?.mode?.usesCamera == true) {
            cameraEngine?.stopAndAwaitFinalized()?.onFailure { error ->
                _sessionMessage.value = error.message ?: "שמירת צילום המצלמה נכשלה"
            }
        }
        controller.stop()
        val finalState = withTimeoutOrNull(15_000L) {
            recorder.state.filter { it.phase == RecordingPhase.Saved || it.phase == RecordingPhase.Error }.first()
        }
        if (finalState?.phase == RecordingPhase.Saved && finalState.savedFilePath != null) {
            lastSavedRawPath = finalState.savedFilePath
            finalState.playbackStartOffsetMs?.let { lastPlaybackStartOffsetMs = it }
            preparePostTakeForExport(finalState.savedFilePath, autoStartExport = true)
        } else if (finalState?.phase == RecordingPhase.Error) {
            _postTakeState.value = PostTakeState(
                stage = PostTakeStage.Error,
                errorMessage = finalState.errorMessage ?: "שמירת ההקלטה נכשלה"
            )
        }
    }

    private suspend fun failTake(message: String) {
        _sessionMessage.value = message
        _countdown.value = null
        playbackControl?.pause()
        cameraEngine?.abort()
        controller.stop()
    }


    private fun preparePostTakeForExport(rawPath: String, autoStartExport: Boolean) {
        pendingExportStart = pendingExportStart || autoStartExport
        if (postTakePrepareJob?.isActive == true) {
            if (autoStartExport) {
                _postTakeState.value = _postTakeState.value.copy(
                    message = "מכין את הסרטון — הייצוא יתחיל אוטומטית כשהכול מוכן"
                )
            }
            return
        }

        postTakePrepareJob = viewModelScope.launch {
            val source = playbackSource
            if (source == null) {
                pendingExportStart = false
                _postTakeState.value = PostTakeState(
                    stage = PostTakeStage.Error,
                    errorMessage = "מקור הפלייבק חסר"
                )
                return@launch
            }

            val rawFile = File(rawPath)
            if (!rawFile.isFile) {
                pendingExportStart = false
                _postTakeState.value = PostTakeState(
                    stage = PostTakeStage.Error,
                    errorMessage = "קובץ ההקלטה אינו זמין"
                )
                return@launch
            }

            // YouTube playback is never extracted. A valid saved vocal take must
            // still be exportable, so provide a silent local timeline automatically.
            // This is an explicitly vocal-only video, not a karaoke mix with YouTube audio.
            val finalBackingSource = if (
                ProductionSourcePolicy.isVoiceOnlyPerformance(source, _productionBackingSource.value)
            ) {
                try {
                    _postTakeState.value = PostTakeState(
                        stage = PostTakeStage.PreparingVocal,
                        progress = 0.03f,
                        message = "מכין את הקול והסרטון ללא אודיו של YouTube"
                    )
                    val (_, localSource) = withContext(Dispatchers.IO) { VoiceOnlyBacking.prepare(rawFile, currentPlaybackStartOffsetMs() ?: 0L) }
                    _productionBackingSource.value = localSource
                    localSource
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (error: Throwable) {
                    pendingExportStart = false
                    _postTakeState.value = PostTakeState(
                        stage = PostTakeStage.Error,
                        errorMessage = error.message ?: "הכנת הטייק נכשלה"
                    )
                    return@launch
                }
            } else {
                ProductionSourcePolicy.resolve(source, _productionBackingSource.value)
                    ?: run {
                        pendingExportStart = false
                        _postTakeState.value = PostTakeState(
                            stage = PostTakeStage.Error,
                            errorMessage = "הפלייבק המקומי אינו זמין"
                        )
                        return@launch
                    }
            }

            if (_dspState.value.outputFilePath == null || lastProcessedRawPath != rawFile.absolutePath) {
                _postTakeState.value = PostTakeState(
                    stage = PostTakeStage.PreparingVocal,
                    progress = 0.08f,
                    message = "משפר את הקול ומכין אותו אוטומטית"
                )
                try {
                    renderSavedVocalInline(rawFile)
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (error: Throwable) {
                    pendingExportStart = false
                    _postTakeState.value = PostTakeState(
                        stage = PostTakeStage.Error,
                        errorMessage = error.message?.takeIf { it.isNotBlank() } ?: "עיבוד הקול לא הושלם"
                    )
                    return@launch
                }
            }

            val processedPath = _dspState.value.outputFilePath
            if (processedPath == null || !File(processedPath).isFile) {
                pendingExportStart = false
                _postTakeState.value = PostTakeState(
                    stage = PostTakeStage.Error,
                    errorMessage = "קובץ הקול המעובד אינו זמין"
                )
                return@launch
            }

            // Final production settings are deterministic and must not depend on
            // preview-player readiness. This is the same automatic configuration used
            // by the advanced/manual path, but it is applied synchronously here.
            val resolvedPreset = _dspState.value.resolvedPreset ?: VocalPresetId.Studio
            val automaticFx = SmartFxAdvisor.recommend(resolvedPreset, _editorState.value.bpm)
            _editorState.value = _editorState.value.copy(
                settings = automaticFx,
                manuallyEdited = false,
                errorMessage = null
            )

            val backingFile: File
            val mixSettings: SessionMixSettings
            try {
                _postTakeState.value = PostTakeState(
                    stage = PostTakeStage.PreparingMix,
                    progress = 0.55f,
                    message = "מנתח ומאזן את הקול מול הפלייבק"
                )
                val prepared = prepareSessionMixInline(
                    processedFile = File(processedPath),
                    finalBackingSource = finalBackingSource
                )
                backingFile = prepared.first
                mixSettings = prepared.second
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Throwable) {
                pendingExportStart = false
                _postTakeState.value = PostTakeState(
                    stage = PostTakeStage.Error,
                    errorMessage = error.message?.takeIf { it.isNotBlank() } ?: "הכנת המיקס נכשלה"
                )
                return@launch
            }

            val renderedMixPath: String
            try {
                _postTakeState.value = PostTakeState(
                    stage = PostTakeStage.PreparingMix,
                    progress = 0.72f,
                    message = "מבצע Balance דינמי ומכין מיקס סופי"
                )
                val rendered = renderSessionMixInline(
                    backingFile = backingFile,
                    rawFile = rawFile,
                    processedFile = File(processedPath),
                    mixSettings = mixSettings,
                    fxSettings = automaticFx
                )
                renderedMixPath = rendered.outputFilePath
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Throwable) {
                pendingExportStart = false
                _postTakeState.value = PostTakeState(
                    stage = PostTakeStage.Error,
                    errorMessage = error.message?.takeIf { it.isNotBlank() } ?: "יצירת המיקס נכשלה"
                )
                return@launch
            }

            if (!File(renderedMixPath).isFile) {
                pendingExportStart = false
                _postTakeState.value = PostTakeState(
                    stage = PostTakeStage.Error,
                    errorMessage = "המיקס הסופי אינו זמין ל-Mastering"
                )
                return@launch
            }

            if (_sessionMixState.value.masteredMixPath == null) {
                _postTakeState.value = PostTakeState(
                    stage = PostTakeStage.Mastering,
                    progress = 0.82f,
                    message = "מבצע Mastering אוטומטי ומאזן את העוצמה"
                )
                _sessionMixState.value = _sessionMixState.value.copy(
                    mastering = true,
                    masteringProgress = 0f,
                    masteredMixPath = null,
                    masteredMixSha256 = null,
                    errorMessage = null
                )
                val mastered = runCatching {
                    withContext(Dispatchers.Default) {
                        automaticMasteringEngine.master(
                            input = File(renderedMixPath),
                            outputDirectory = File(File(rawPath).parentFile, "master")
                        ) { progress ->
                            _sessionMixState.value = _sessionMixState.value.copy(
                                masteringProgress = progress.coerceIn(0f, 1f)
                            )
                        }
                    }
                }.getOrElse { error ->
                    pendingExportStart = false
                    _sessionMixState.value = _sessionMixState.value.copy(
                        mastering = false,
                        errorMessage = error.message ?: "Mastering נכשל"
                    )
                    _postTakeState.value = PostTakeState(
                        stage = PostTakeStage.Error,
                        errorMessage = error.message ?: "Mastering נכשל"
                    )
                    return@launch
                }
                _sessionMixState.value = _sessionMixState.value.copy(
                    mastering = false,
                    masteringProgress = 1f,
                    durationMs = mastered.durationMs,
                    masteredMixPath = mastered.outputFilePath,
                    masteredMixSha256 = mastered.outputSha256,
                    errorMessage = null
                )
            }

            _postTakeState.value = PostTakeState(
                stage = PostTakeStage.RenderingVideo,
                progress = 0.90f,
                message = "יוצר את הסרטון הסופי ב-1080p"
            )
            pendingExportStart = false
            startVideoExportPrepared()
        }
    }

    fun retryPostTakePreparation() {
        val rawPath = currentSavedRawPath() ?: return
        _postTakeState.value = PostTakeState()
        preparePostTakeForExport(rawPath, autoStartExport = true)
    }

    fun attachProductionBacking(uri: Uri) {
        val source = runCatching { LocalMediaResolver.resolve(getApplication(), uri) }
            .getOrElse { error ->
                _sessionMessage.value = error.message ?: "לא ניתן לפתוח את מקור ההפקה"
                return
            }
        if (source.type == PlaybackSourceType.YouTube || source.uriString.isNullOrBlank()) {
            _sessionMessage.value = "יש לבחור קובץ אודיו או וידאו מקומי"
            return
        }

        _productionBackingSource.value = source
        releaseSessionMix()
        compositionPreviewEngine.invalidate()
        exportEngine.cancel()
        _sessionMixState.value = SessionMixState()
        _sessionMessage.value = null

        val rawPath = currentSavedRawPath()
        if (rawPath != null) {
            _postTakeState.value = PostTakeState(
                stage = PostTakeStage.PreparingMix,
                progress = 0.52f,
                message = "מסנכרן, ממקסס ומבצע Mastering אוטומטי"
            )
            preparePostTakeForExport(rawPath, autoStartExport = true)
        }
    }



    fun selectVocalPreset(preset: VocalPresetId) {
        if (_dspState.value.processing) return
        releasePreview()
        _editorState.value = _editorState.value.copy(prepared = false, playing = false, manuallyEdited = false)
        _dspState.value = _dspState.value.copy(
            selectedPreset = preset,
            stage = DspStage.Idle,
            progress = 0f,
            outputFilePath = null,
            outputSha256 = null,
            errorMessage = null
        )
    }

    fun processSavedVocal() = processSavedVocal(null)

    private fun processSavedVocal(rawPathOverride: String?) {
        if (_dspState.value.processing) return
        val rawPath = rawPathOverride ?: currentSavedRawPath() ?: run {
            _dspState.value = _dspState.value.copy(stage = DspStage.Error, errorMessage = "קובץ ההקלטה אינו זמין לעיבוד")
            return
        }
        val rawFile = File(rawPath)
        if (!rawFile.isFile || !WavFileTools.validatePcm16Mono(rawFile)) {
            _dspState.value = _dspState.value.copy(stage = DspStage.Error, errorMessage = "קובץ ההקלטה אינו WAV תקין")
            return
        }
        dspJob?.cancel()
        dspJob = viewModelScope.launch {
            try {
                renderSavedVocalInline(rawFile)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Throwable) {
                // renderSavedVocalInline already published a user-facing error state.
            }
        }
    }

    /**
     * Runs vocal finalization inside the caller's coroutine. Post-production no longer
     * launches a detached DSP job and then races a StateFlow; cancellation remains
     * cancellation, while genuine DSP failures automatically fall back to the safest
     * constant-memory path before the user ever sees an error.
     */
    private suspend fun renderSavedVocalInline(rawFile: File): DspRenderResult {
        require(rawFile.isFile && WavFileTools.validatePcm16Mono(rawFile)) {
            "קובץ ההקלטה אינו WAV תקין"
        }
        lastSavedRawPath = rawFile.absolutePath
        lastProcessedRawPath = null
        val requested = _dspState.value.selectedPreset
        _dspState.value = _dspState.value.copy(
            stage = DspStage.Loading,
            progress = 0f,
            resolvedPreset = null,
            outputFilePath = null,
            outputSha256 = null,
            errorMessage = null
        )

        val result = try {
            withContext(Dispatchers.Default) {
                try {
                    // The constant-memory studio path is the production default. It is
                    // deterministic for full songs and avoids the large spectral buffers
                    // that can exhaust a mobile heap.
                    streamingDspEngine.render(rawFile, requested) { stage, progress ->
                        _dspState.value = _dspState.value.copy(stage = stage, progress = progress)
                    }
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (primaryFailure: Throwable) {
                    // A valid take must not be lost because a device rejects one DSP
                    // operation. Fall back to a conservative streaming chain that still
                    // high-passes, controls dynamics and protects peaks. Adaptive balance,
                    // Smart FX and final mastering continue afterwards as usual.
                    _dspState.value = _dspState.value.copy(
                        stage = DspStage.Loading,
                        progress = 0.02f,
                        errorMessage = null
                    )
                    safeDspEngine.render(rawFile, requested) { stage, progress ->
                        _dspState.value = _dspState.value.copy(stage = stage, progress = progress)
                    }
                }
            }
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (error: Throwable) {
            val message = error.message?.takeIf { it.isNotBlank() } ?: "עיבוד הקול לא הושלם"
            _dspState.value = _dspState.value.copy(
                stage = DspStage.Error,
                progress = 0f,
                errorMessage = message
            )
            throw IllegalStateException(message, error)
        }

        _dspState.value = _dspState.value.copy(
            stage = DspStage.Completed,
            progress = 1f,
            resolvedPreset = result.resolvedPreset,
            analysis = result.analysis,
            outputFilePath = result.outputFilePath,
            outputSha256 = result.outputSha256,
            errorMessage = null
        )
        val smartFx = SmartFxAdvisor.recommend(result.resolvedPreset, _editorState.value.bpm)
        _editorState.value = _editorState.value.copy(
            settings = smartFx,
            manuallyEdited = false,
            renderedFilePath = null,
            renderedSha256 = null,
            errorMessage = null
        )
        lastProcessedRawPath = rawFile.absolutePath
        prepareVocalEditor(rawFile, File(result.outputFilePath), result.resolvedPreset)
        return result
    }

    private fun analyseTempoIfSupported(source: PlaybackSource) {
        val generation = tempoGeneration.incrementAndGet()
        tempoJob?.cancel()
        if (source.type == PlaybackSourceType.YouTube) {
            _editorState.value = _editorState.value.copy(
                tempoAnalysing = false,
                tempoSource = if (_editorState.value.tempoSource == TempoSource.Tap) TempoSource.Tap else TempoSource.Unknown
            )
            return
        }
        _editorState.value = _editorState.value.copy(tempoAnalysing = true, errorMessage = null)
        tempoJob = viewModelScope.launch(Dispatchers.Default) {
            val estimate = runCatching {
                LocalPlaybackTempoAnalyzer(getApplication()).analyse(source) {
                    tempoGeneration.get() != generation
                }
            }.getOrNull()
            withContext(Dispatchers.Main) {
                if (estimate != null) {
                    applyTempo(estimate.bpm, TempoSource.Automatic, estimate.confidence)
                } else {
                    _editorState.value = _editorState.value.copy(tempoAnalysing = false)
                }
            }
        }
    }

    private fun prepareVocalEditor(rawFile: File, processedFile: File, preset: VocalPresetId) {
        releasePreview()
        viewModelScope.launch {
            val current = _editorState.value
            val smart = if (current.manuallyEdited) current.settings else SmartFxAdvisor.recommend(preset, current.bpm)
            val playerResult = runCatching {
                withContext(Dispatchers.IO) {
                    LiveVocalPreviewPlayer(rawFile, processedFile, smart)
                }
            }
            playerResult.onFailure { error ->
                _editorState.value = _editorState.value.copy(
                    prepared = false,
                    errorMessage = error.message ?: "לא ניתן להכין A/B Preview"
                )
            }.onSuccess { player ->
                previewPlayer = player
                _editorState.value = _editorState.value.copy(
                    prepared = true,
                    playing = false,
                    previewSource = PreviewSource.Processed,
                    settings = smart,
                    errorMessage = null
                )
                scheduleFxPersistence()
                previewCollectJob = viewModelScope.launch {
                    player.state.collect { live ->
                        val editor = _editorState.value
                        _editorState.value = editor.copy(
                            prepared = live.prepared,
                            playing = live.playing,
                            previewSource = live.previewSource,
                            positionMs = live.positionMs,
                            durationMs = live.durationMs,
                            settings = live.settings,
                            errorMessage = live.errorMessage ?: editor.errorMessage
                        )
                    }
                }
            }
        }
    }

    fun toggleVocalPreview() = previewPlayer?.toggle() ?: Unit

    fun selectPreviewSource(source: PreviewSource) {
        previewPlayer?.selectSource(source)
        _editorState.value = _editorState.value.copy(previewSource = source)
    }

    fun seekVocalPreview(positionMs: Long) {
        previewPlayer?.seekTo(positionMs)
    }

    fun setReverbMix(value: Float) = updateFx { copy(reverbMix = value) }
    fun setReverbRoom(value: Float) = updateFx { copy(reverbRoom = value) }
    fun setDelayMix(value: Float) = updateFx { copy(delayMix = value) }
    fun setDelayFeedback(value: Float) = updateFx { copy(delayFeedback = value) }
    fun setOutputGain(value: Float) = updateFx { copy(outputGainDb = value) }

    fun setDelayDivision(division: BeatDivision) {
        updateFx {
            copy(
                delayDivision = division,
                delayMs = _editorState.value.bpm?.let { TempoSync.delayMs(it, division) } ?: delayMs
            )
        }
    }

    fun setEditorAdvanced(open: Boolean) {
        _editorState.value = _editorState.value.copy(advancedOpen = open)
    }

    fun tapTempo() {
        val bpm = tapTempo.tap(SystemClock.elapsedRealtime()) ?: return
        applyTempo(bpm, TempoSource.Tap, 1.0)
    }

    fun renderFinalVocalFx() {
        if (_editorState.value.rendering) return
        val inputPath = _dspState.value.outputFilePath ?: run {
            _editorState.value = _editorState.value.copy(errorMessage = "אין קובץ קול מעובד ל־FX Render")
            return
        }
        val settings = _editorState.value.settings
        viewModelScope.launch {
            _editorState.value = _editorState.value.copy(
                rendering = true,
                renderProgress = 0f,
                renderedFilePath = null,
                renderedSha256 = null,
                errorMessage = null
            )
            runCatching {
                withContext(Dispatchers.Default) {
                    fxRenderEngine.render(File(inputPath), settings) { progress ->
                        _editorState.value = _editorState.value.copy(renderProgress = progress.coerceIn(0f, 1f))
                    }
                }
            }.onSuccess { result ->
                _editorState.value = _editorState.value.copy(
                    rendering = false,
                    renderProgress = 1f,
                    renderedFilePath = result.outputFilePath,
                    renderedSha256 = result.outputSha256,
                    errorMessage = null
                )
                scheduleFxPersistence()
            }.onFailure { error ->
                _editorState.value = _editorState.value.copy(
                    rendering = false,
                    errorMessage = error.message ?: "FX Render נכשל"
                )
            }
        }
    }

    fun restoreSmartEffects() {
        val preset = _dspState.value.resolvedPreset
            ?: _dspState.value.selectedPreset.takeUnless { it == VocalPresetId.Auto }
            ?: VocalPresetId.Studio
        val smart = SmartFxAdvisor.recommend(preset, _editorState.value.bpm)
        previewPlayer?.updateSettings(smart)
        sessionMixPlayer?.updateFxSettings(smart)
        invalidateSessionMixRender()
        _editorState.value = _editorState.value.copy(
            settings = smart,
            manuallyEdited = false,
            renderedFilePath = null,
            renderedSha256 = null
        )
        scheduleFxPersistence()
    }

    private fun updateFx(transform: VocalFxSettings.() -> VocalFxSettings) {
        val updated = _editorState.value.settings.transform().sanitized()
        previewPlayer?.updateSettings(updated)
        sessionMixPlayer?.updateFxSettings(updated)
        invalidateSessionMixRender()
        _editorState.value = _editorState.value.copy(
            settings = updated,
            manuallyEdited = true,
            renderedFilePath = null,
            renderedSha256 = null
        )
        scheduleFxPersistence()
    }

    private fun applyTempo(bpm: Double, source: TempoSource, confidence: Double) {
        val current = _editorState.value
        val settings = current.settings.copy(
            delayMs = TempoSync.delayMs(bpm, current.settings.delayDivision)
        ).sanitized()
        previewPlayer?.updateSettings(settings)
        sessionMixPlayer?.updateFxSettings(settings)
        invalidateSessionMixRender()
        _editorState.value = current.copy(
            bpm = bpm,
            bpmConfidence = confidence,
            tempoSource = source,
            tempoAnalysing = false,
            settings = settings,
            renderedFilePath = null,
            renderedSha256 = null
        )
        scheduleFxPersistence()
    }


    private suspend fun prepareSessionMixInline(
        processedFile: File,
        finalBackingSource: PlaybackSource
    ): Pair<File, SessionMixSettings> {
        val backing = withContext(Dispatchers.IO) {
            if (ProductionSourcePolicy.isGeneratedVoiceOnlyBacking(finalBackingSource)) {
                // Already an authorized, locally generated silent WAV. Avoid codec work.
                File(requireNotNull(Uri.parse(finalBackingSource.uriString).path))
            } else {
                localPlaybackPcmCache.prepare(
                    source = finalBackingSource,
                    shouldCancel = { postTakePrepareJob?.isActive == false }
                )
            }
        }
        check(backing.isFile && backing.length() > 44L) { "הפלייבק המקומי אינו זמין" }
        val settings = withContext(Dispatchers.Default) {
            val stage = automaticMixGainStager.recommend(
                backingFile = backing,
                processedVocalFile = processedFile,
                fxSettings = _editorState.value.settings
            ).settings
            if (ProductionSourcePolicy.isGeneratedVoiceOnlyBacking(finalBackingSource)) {
                // With no instrumental, do not bury the singer under a -4 dB mix bus.
                stage.copy(
                    vocalGainDb = (stage.vocalGainDb + 3.5f).coerceIn(-6f, 4f),
                    playbackGainDb = -24f,
                    masterHeadroomDb = -2f
                ).sanitized()
            } else stage
        }
        _sessionMixState.value = SessionMixState(
            available = true,
            preparing = false,
            settings = settings,
            backingCachePath = backing.absolutePath,
            errorMessage = null
        )
        return backing to settings
    }

    private suspend fun renderSessionMixInline(
        backingFile: File,
        rawFile: File,
        processedFile: File,
        mixSettings: SessionMixSettings,
        fxSettings: VocalFxSettings
    ): com.kolbomusic.singstudio.core.mix.SessionMixRenderResult {
        val offset = currentPlaybackStartOffsetMs()
            ?: error("חסר סמן סנכרון פלייבק")
        val outputDir = File(rawFile.parentFile, "mix")
        _sessionMixState.value = _sessionMixState.value.copy(
            rendering = true,
            renderProgress = 0f,
            renderedMixPath = null,
            renderedMixSha256 = null,
            mastering = false,
            masteringProgress = 0f,
            masteredMixPath = null,
            masteredMixSha256 = null,
            errorMessage = null
        )
        return try {
            val result = withContext(Dispatchers.Default) {
                sessionMixRenderEngine.render(
                    backingFile = backingFile,
                    rawVocalFile = rawFile,
                    processedVocalFile = processedFile,
                    playbackStartOffsetMs = offset,
                    mixSettings = mixSettings,
                    fxSettings = fxSettings,
                    outputDirectory = outputDir
                ) { progress ->
                    _sessionMixState.value = _sessionMixState.value.copy(
                        renderProgress = progress.coerceIn(0f, 1f)
                    )
                }
            }
            _sessionMixState.value = _sessionMixState.value.copy(
                rendering = false,
                renderProgress = 1f,
                durationMs = result.durationMs,
                renderedMixPath = result.outputFilePath,
                renderedMixSha256 = result.outputSha256,
                errorMessage = null
            )
            result
        } catch (cancelled: CancellationException) {
            _sessionMixState.value = _sessionMixState.value.copy(rendering = false)
            throw cancelled
        } catch (error: Throwable) {
            _sessionMixState.value = _sessionMixState.value.copy(
                rendering = false,
                errorMessage = error.message ?: "שמירת Session Mix נכשלה"
            )
            throw error
        }
    }

    private fun prepareSessionMix(rawFile: File, processedFile: File) {
        releaseSessionMix()
        val source = playbackSource?.let { ProductionSourcePolicy.resolve(it, _productionBackingSource.value) }
            ?: run {
                _sessionMixState.value = SessionMixState(
                    available = false,
                    errorMessage = "מקור ההפקה הסופי אינו זמין"
                )
                return
            }
        val playbackOffset = currentPlaybackStartOffsetMs() ?: run {
            _sessionMixState.value = SessionMixState(available = false, errorMessage = "חסר סמן סנכרון פלייבק")
            return
        }
        val previousMix = _sessionMixState.value
        _sessionMixState.value = previousMix.copy(available = true, preparing = true, errorMessage = null)
        sessionMixPrepareJob = viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                val backing = localPlaybackPcmCache.prepare(source) { sessionMixPrepareJob?.isActive == false }
                val automaticSettings = runCatching {
                    automaticMixGainStager.recommend(backing, processedFile, _editorState.value.settings).settings
                }.getOrElse {
                    SessionMixSettings(vocalGainDb = -5.5f, playbackGainDb = -3f, masterHeadroomDb = -4f)
                }
                val player = SessionMixPreviewPlayer(
                    backingFile = backing,
                    rawVocalFile = rawFile,
                    processedVocalFile = processedFile,
                    playbackStartOffsetMs = playbackOffset,
                    initialMixSettings = automaticSettings,
                    initialFxSettings = _editorState.value.settings
                )
                Triple(backing, player, automaticSettings)
            }.onSuccess { (backing, player, automaticSettings) ->
                if (sessionMixPrepareJob?.isActive != true) {
                    player.close()
                    return@onSuccess
                }
                sessionMixPlayer = player
                _sessionMixState.value = player.state.value.copy(
                    available = true,
                    preparing = false,
                    settings = automaticSettings,
                    backingCachePath = backing.absolutePath,
                    renderedMixPath = previousMix.renderedMixPath,
                    renderedMixSha256 = previousMix.renderedMixSha256,
                    mastering = previousMix.mastering,
                    masteringProgress = previousMix.masteringProgress,
                    masteredMixPath = previousMix.masteredMixPath,
                    masteredMixSha256 = previousMix.masteredMixSha256
                )
                sessionMixCollectJob = viewModelScope.launch {
                    player.state.collect { live ->
                        val existing = _sessionMixState.value
                        _sessionMixState.value = live.copy(
                            backingCachePath = backing.absolutePath,
                            rendering = existing.rendering,
                            renderProgress = existing.renderProgress,
                            renderedMixPath = existing.renderedMixPath,
                            renderedMixSha256 = existing.renderedMixSha256,
                            mastering = existing.mastering,
                            masteringProgress = existing.masteringProgress,
                            masteredMixPath = existing.masteredMixPath,
                            masteredMixSha256 = existing.masteredMixSha256
                        )
                    }
                }
            }.onFailure { error ->
                if (sessionMixPrepareJob?.isActive != true) return@onFailure
                _sessionMixState.value = SessionMixState(
                    available = true,
                    preparing = false,
                    errorMessage = error.message ?: "הכנת Session Mix נכשלה"
                )
            }
        }
    }

    fun toggleSessionMix() = sessionMixPlayer?.toggle() ?: Unit
    fun seekSessionMix(positionMs: Long) = sessionMixPlayer?.seekTo(positionMs) ?: Unit

    fun setSessionMixVocalGain(value: Float) = updateSessionMix { copy(vocalGainDb = value) }
    fun setSessionMixPlaybackGain(value: Float) = updateSessionMix { copy(playbackGainDb = value) }
    fun setSessionMixHeadroom(value: Float) = updateSessionMix { copy(masterHeadroomDb = value) }
    fun setSessionMixPreviewSource(source: PreviewSource) = updateSessionMix { copy(previewSource = source) }

    private fun updateSessionMix(transform: SessionMixSettings.() -> SessionMixSettings) {
        compositionPreviewEngine.invalidate()
        val updated = _sessionMixState.value.settings.transform().sanitized()
        sessionMixPlayer?.updateMixSettings(updated)
        _sessionMixState.value = _sessionMixState.value.copy(
            settings = updated,
            renderedMixPath = null,
            renderedMixSha256 = null,
            mastering = false,
            masteringProgress = 0f,
            masteredMixPath = null,
            masteredMixSha256 = null
        )
    }

    fun renderSessionMix() {
        if (_sessionMixState.value.rendering) return
        compositionPreviewEngine.invalidate()
        val backingPath = _sessionMixState.value.backingCachePath ?: return
        val rawPath = currentSavedRawPath() ?: return
        val processedPath = _dspState.value.outputFilePath ?: return
        val offset = currentPlaybackStartOffsetMs() ?: return
        val outputDir = File(File(rawPath).parentFile, "mix")
        val mixSettings = _sessionMixState.value.settings
        val fxSettings = _editorState.value.settings
        sessionMixRenderJob?.cancel()
        // Clear a previous render error synchronously so Retry cannot immediately
        // match stale error state before this render coroutine starts.
        _sessionMixState.value = _sessionMixState.value.copy(
            rendering = true,
            renderProgress = 0f,
            renderedMixPath = null,
            renderedMixSha256 = null,
            mastering = false,
            masteringProgress = 0f,
            masteredMixPath = null,
            masteredMixSha256 = null,
            errorMessage = null
        )
        sessionMixRenderJob = viewModelScope.launch {
            runCatching {
                withContext(Dispatchers.Default) {
                    sessionMixRenderEngine.render(
                        backingFile = File(backingPath),
                        rawVocalFile = File(rawPath),
                        processedVocalFile = File(processedPath),
                        playbackStartOffsetMs = offset,
                        mixSettings = mixSettings,
                        fxSettings = fxSettings,
                        outputDirectory = outputDir
                    ) { progress ->
                        _sessionMixState.value = _sessionMixState.value.copy(renderProgress = progress.coerceIn(0f, 1f))
                    }
                }
            }.onSuccess { result ->
                _sessionMixState.value = _sessionMixState.value.copy(
                    rendering = false,
                    renderProgress = 1f,
                    durationMs = result.durationMs,
                    renderedMixPath = result.outputFilePath,
                    renderedMixSha256 = result.outputSha256
                )
            }.onFailure { error ->
                _sessionMixState.value = _sessionMixState.value.copy(
                    rendering = false,
                    errorMessage = error.message ?: "שמירת Session Mix נכשלה"
                )
            }
        }
    }

    fun setVideoTitle(text: String) = updateVideoProject { copy(title = title.copy(text = text)) }
    fun setVideoTitleSize(sizeSp: Float) = updateVideoProject { copy(title = title.copy(fontSizeSp = sizeSp)) }
    fun setVideoTitleColor(argb: Long) = updateVideoProject { copy(title = title.copy(colorArgb = argb)) }
    fun setVideoTitleFont(font: TextFontPreset) = updateVideoProject { copy(title = title.copy(fontPreset = font)) }
    fun setVideoTitleAnimation(animation: TextAnimationPreset) = updateVideoProject { copy(title = title.copy(animation = animation)) }
    fun setVideoTitleOutline(enabled: Boolean) = updateVideoProject { copy(title = title.copy(outline = enabled)) }
    fun setVideoTitleShadow(enabled: Boolean) = updateVideoProject { copy(title = title.copy(shadow = enabled)) }
    fun setVideoTitleX(value: Float) = updateVideoProject { copy(title = title.copy(xNormalized = value)) }
    fun setVideoTitleY(value: Float) = updateVideoProject { copy(title = title.copy(yNormalized = value)) }
    fun setVideoZoom(value: Float) = updateVideoProject { copy(zoom = value.coerceIn(0.5f, 3f)) }
    fun setVideoOffsetX(value: Float) = updateVideoProject { copy(visualOffsetX = value.coerceIn(-0.35f, 0.35f)) }
    fun setVideoOffsetY(value: Float) = updateVideoProject { copy(visualOffsetY = value.coerceIn(-0.35f, 0.35f)) }
    fun setExportResolution(value: ExportResolution) = updateVideoProject { copy(exportSettings = exportSettings.copy(resolution = value)) }
    fun setExportCodec(value: ExportVideoCodec) = updateVideoProject { copy(exportSettings = exportSettings.copy(codec = value)) }
    fun setExportTrimStart(valueMs: Long) = updateVideoProject { copy(exportSettings = exportSettings.copy(trimStartMs = valueMs.coerceAtLeast(0L))) }
    fun setExportTrimEnd(valueMs: Long) = updateVideoProject { copy(exportSettings = exportSettings.copy(trimEndMs = valueMs.coerceAtLeast(0L))) }
    fun applyExportPreset(preset: PlatformExportPreset) = updateVideoProject {
        copy(exportSettings = preset.applyTo(exportSettings))
    }

    fun publishLatestExportToGallery() {
        if (_deliveryState.value.running) return
        val path = exportState.value.outputPath ?: run {
            _deliveryState.value = DeliveryState(phase = DeliveryPhase.Failed, errorMessage = "אין סרטון מוכן לשמירה")
            return
        }
        val file = File(path)
        if (!file.isFile) {
            _deliveryState.value = DeliveryState(phase = DeliveryPhase.Failed, errorMessage = "קובץ הסרטון אינו קיים")
            return
        }
        val title = _videoProjectState.value.title.text.ifBlank { playbackSource?.title ?: "Kolbo Studio" }
        _deliveryState.value = DeliveryState(phase = DeliveryPhase.Publishing, message = "שומר לגלריה…")
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { mediaStorePublisher.publishVideo(file, title) }
                .onSuccess { uri ->
                    val takeId = currentSavedRawPath()?.let { File(it).nameWithoutExtension }
                    if (takeId != null) {
                        libraryRepository.load().firstOrNull { it.takeId == takeId }?.let { item ->
                            libraryRepository.setGalleryUri(item.id, uri.toString())
                        }
                    }
                    _deliveryState.value = DeliveryState(
                        phase = DeliveryPhase.Published,
                        galleryUri = uri.toString(),
                        message = "הסרטון נשמר בגלריה ✓"
                    )
                }
                .onFailure { error ->
                    _deliveryState.value = DeliveryState(
                        phase = DeliveryPhase.Failed,
                        errorMessage = error.message ?: "השמירה לגלריה נכשלה"
                    )
                }
        }
    }

    fun clearDeliveryState() { _deliveryState.value = DeliveryState() }

    fun prepareVideoPreview() {
        if (compositionPreviewState.value.preparing) return
        val playback = playbackSource ?: return compositionPreviewEngine.showError("ההפקה עדיין אינה מוכנה לתצוגה")
        val source = ProductionSourcePolicy.resolve(playback, _productionBackingSource.value)
        val scene = visualScene ?: return compositionPreviewEngine.showError("ההפקה עדיין אינה מוכנה לתצוגה")
        val mixPath = _sessionMixState.value.masteredMixPath
            ?: _sessionMixState.value.renderedMixPath
            ?: run {
                currentSavedRawPath()?.let { preparePostTakeForExport(it, autoStartExport = false) }
                return compositionPreviewEngine.showError("ההפקה האוטומטית עדיין מתבצעת")
            }
        val mixFile = File(mixPath)
        if (!mixFile.isFile) return compositionPreviewEngine.showError("קובץ Session Mix לא נמצא")
        val durationMs = _sessionMixState.value.durationMs.takeIf { it > 0L } ?: return compositionPreviewEngine.showError("משך המיקס אינו ידוע")
        val rawPath = currentSavedRawPath() ?: return compositionPreviewEngine.showError("הטייק אינו שמור")
        val takeId = File(rawPath).nameWithoutExtension
        val current = _videoProjectState.value.copy(aspectRatio = scene.aspectRatio).sanitized(durationMs)
        val plan = runCatching {
            ExportPlanBuilder.build(
                takeId = takeId,
                sessionDurationMs = durationMs,
                aspectRatio = scene.aspectRatio,
                settings = current.exportSettings,
                title = current.title,
                playbackStartOffsetMs = currentPlaybackStartOffsetMs(),
                cameraStartOffsetMs = recorder.state.value.cameraStartOffsetMs,
                hasCamera = scene.mode.usesCamera
            )
        }.getOrElse { return compositionPreviewEngine.showError(it.message ?: "לא ניתן לבנות תצוגה מקדימה") }
        val cameraFile = recorder.state.value.cameraFilePath?.let(::File)
        if (scene.mode.usesCamera && (cameraFile == null || !cameraFile.isFile)) return compositionPreviewEngine.showError("קובץ המצלמה חסר")

        compositionPreviewEngine.beginPreparing()
        viewModelScope.launch(Dispatchers.IO) {
            val working = File(File(rawPath).parentFile, "preview-work").apply {
                deleteRecursively()
                mkdirs()
            }
            runCatching {
                CompositionFactory(getApplication()).build(
                    plan = plan,
                    scene = scene,
                    project = current,
                    playbackSource = source,
                    sessionMixFile = mixFile,
                    cameraFile = cameraFile,
                    workingDirectory = working
                )
            }.onSuccess { prepared ->
                withContext(Dispatchers.Main) { compositionPreviewEngine.prepare(prepared) }
            }.onFailure { error ->
                withContext(Dispatchers.Main) { compositionPreviewEngine.showError(error.message ?: "הכנת התצוגה נכשלה") }
            }
        }
    }

    fun toggleVideoPreview() = compositionPreviewEngine.togglePlayback()
    fun seekVideoPreview(positionMs: Long) = compositionPreviewEngine.seekTo(positionMs)

    fun startVideoExport() {
        if (exportEngine.state.value.running) return
        val source = playbackSource ?: return setVideoProjectError("מקור הפלייבק חסר")
        if (!ProductionSourcePolicy.canStartFullProduction(source, _productionBackingSource.value)) {
            return setVideoProjectError("מקור ההפקה הסופי לא הוכן לפני הטייק")
        }
        if (_sessionMixState.value.masteredMixPath == null) {
            val rawPath = currentSavedRawPath() ?: return setVideoProjectError("הטייק אינו שמור")
            preparePostTakeForExport(rawPath, autoStartExport = true)
            return
        }
        startVideoExportPrepared()
    }

    private fun startVideoExportPrepared() {
        if (exportEngine.state.value.running) return
        _deliveryState.value = DeliveryState()
        viewModelScope.launch(Dispatchers.IO) { _runtimeHealth.value = runtimeHealthProbe.snapshot() }
        val playback = playbackSource ?: return setVideoProjectError("מקור הפלייבק חסר")
        val productionSource = ProductionSourcePolicy.resolve(playback, _productionBackingSource.value)
            ?: return setVideoProjectError("מקור ההפקה הסופי אינו זמין")
        val scene = visualScene ?: return setVideoProjectError("הגדרת ההפקה חסרה")
        val mixPath = _sessionMixState.value.masteredMixPath
            ?: _sessionMixState.value.renderedMixPath
            ?: return setVideoProjectError("המיקס הסופי עדיין לא מוכן")
        val mixFile = File(mixPath)
        if (!mixFile.isFile) return setVideoProjectError("קובץ המיקס הסופי לא נמצא")
        val durationMs = _sessionMixState.value.durationMs.takeIf { it > 0L } ?: return setVideoProjectError("משך המיקס אינו ידוע")
        val rawPath = currentSavedRawPath() ?: return setVideoProjectError("הטייק אינו שמור")
        val takeId = File(rawPath).nameWithoutExtension
        val current = _videoProjectState.value.copy(aspectRatio = scene.aspectRatio).sanitized(durationMs)
        val plan = runCatching {
            ExportPlanBuilder.build(
                takeId = takeId,
                sessionDurationMs = durationMs,
                aspectRatio = scene.aspectRatio,
                settings = current.exportSettings,
                title = current.title,
                playbackStartOffsetMs = currentPlaybackStartOffsetMs(),
                cameraStartOffsetMs = recorder.state.value.cameraStartOffsetMs,
                hasCamera = scene.mode.usesCamera
            )
        }.getOrElse { return setVideoProjectError(it.message ?: "לא ניתן לבנות תוכנית ייצוא") }
        val cameraFile = recorder.state.value.cameraFilePath?.let(::File)
        if (scene.mode.usesCamera && (cameraFile == null || !cameraFile.isFile)) return setVideoProjectError("קובץ המצלמה חסר")
        _videoProjectState.value = current.copy(errorMessage = null)
        exportEngine.start(
            plan = plan,
            scene = scene,
            project = current,
            playbackSource = productionSource,
            sessionMixFile = mixFile,
            sessionMixExpectedSha256 = _sessionMixState.value.masteredMixSha256 ?: _sessionMixState.value.renderedMixSha256,
            cameraFile = cameraFile,
            outputDirectory = File(File(rawPath).parentFile, "exports")
        )
    }

    fun cancelVideoExport() = exportEngine.cancel()

    private fun setVideoProjectError(message: String) {
        _videoProjectState.value = _videoProjectState.value.copy(errorMessage = message)
    }

    private fun updateVideoProject(transform: VideoProjectState.() -> VideoProjectState) {
        compositionPreviewEngine.invalidate()
        _videoProjectState.value = _videoProjectState.value.transform().copy(savedProjectPath = null, errorMessage = null)
    }

    fun saveVideoProject() {
        val rawPath = currentSavedRawPath() ?: run {
            _videoProjectState.value = _videoProjectState.value.copy(errorMessage = "אין טייק שמור")
            return
        }
        val scene = visualScene ?: return
        val takeId = File(rawPath).nameWithoutExtension
        val current = _videoProjectState.value.copy(aspectRatio = scene.aspectRatio)
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                VideoProjectMetadataStore.save(
                    directory = File(File(rawPath).parentFile, "project"),
                    takeId = takeId,
                    scene = scene,
                    state = current,
                    playbackSource = playbackSource,
                    productionBackingSource = _productionBackingSource.value,
                    rawVocalPath = rawPath,
                    processedVocalPath = _dspState.value.outputFilePath,
                    sessionMixPath = _sessionMixState.value.renderedMixPath,
                    sessionMixSettings = _sessionMixState.value.settings,
                    vocalFxSettings = _editorState.value.settings,
                    cameraFilePath = recorder.state.value.cameraFilePath,
                    playbackStartOffsetMs = currentPlaybackStartOffsetMs(),
                    cameraStartOffsetMs = recorder.state.value.cameraStartOffsetMs
                )
            }.onSuccess { file ->
                runCatching {
                    libraryRepository.registerDraft(
                        takeId = takeId,
                        title = current.title.text,
                        projectPath = file.absolutePath,
                        sourceTitle = playbackSource?.title,
                        aspectRatio = scene.aspectRatio.name
                    )
                }
                _videoProjectState.value = current.copy(savedProjectPath = file.absolutePath, errorMessage = null)
            }.onFailure { error ->
                _videoProjectState.value = current.copy(errorMessage = error.message ?: "שמירת פרויקט הווידאו נכשלה")
            }
        }
    }

    private fun indexSavedTake(rawPath: String) {
        val rawFile = File(rawPath)
        if (!rawFile.isFile) return
        val takeId = rawFile.nameWithoutExtension
        val title = _videoProjectState.value.title.text.ifBlank { playbackSource?.title ?: "ביצוע חדש" }
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                libraryRepository.registerTakeDraft(
                    takeId = takeId,
                    title = title,
                    rawVocalPath = rawFile.absolutePath,
                    sourceTitle = playbackSource?.title,
                    aspectRatio = visualScene?.aspectRatio?.name
                )
            }
        }
    }

    private fun indexCompletedExport(state: ExportState) {
        val outputPath = state.outputPath ?: return
        val outputFile = File(outputPath)
        if (!outputFile.isFile) return
        val rawPath = currentSavedRawPath() ?: return
        val takeId = File(rawPath).nameWithoutExtension
        val scene = visualScene
        val title = _videoProjectState.value.title.text.ifBlank { playbackSource?.title ?: "ביצוע חדש" }
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                libraryRepository.registerExport(
                    takeId = takeId,
                    title = title,
                    exportFile = outputFile,
                    projectPath = _videoProjectState.value.savedProjectPath,
                    sourceTitle = playbackSource?.title,
                    aspectRatio = scene?.aspectRatio?.name,
                    durationMs = state.verification?.durationMs ?: _sessionMixState.value.durationMs,
                    sha256 = state.outputSha256 ?: state.verification?.sha256
                )
            }
        }
    }

    private fun resetDerivedPostProductionForNewTake() {
        postTakePrepareJob?.cancel()
        postTakePrepareJob = null
        dspJob?.cancel()
        dspJob = null
        sessionMixRenderJob?.cancel()
        sessionMixRenderJob = null
        pendingExportStart = false
        releasePreview()
        releaseSessionMix()
        exportEngine.cancel()
        compositionPreviewEngine.invalidate()
        _postTakeState.value = PostTakeState()
        _dspState.value = DspUiState(selectedPreset = VocalPresetId.Auto)
        _editorState.value = VocalEditorState()
        _sessionMixState.value = SessionMixState()
        _deliveryState.value = DeliveryState()
        lastSavedRawPath = null
        lastProcessedRawPath = null
        lastPlaybackStartOffsetMs = null
        lastIndexedExportPath = null
        lastIndexedTakePath = null
        fxPersistJob?.cancel()
        tapTempo.reset()
    }

    private fun currentSavedRawPath(): String? =
        lastSavedRawPath?.takeIf { File(it).isFile } ?: recorder.state.value.savedFilePath?.takeIf { File(it).isFile }

    private fun currentPlaybackStartOffsetMs(): Long? =
        lastPlaybackStartOffsetMs ?: recorder.state.value.playbackStartOffsetMs

    private fun invalidateSessionMixRender() {
        compositionPreviewEngine.invalidate()
        _sessionMixState.value = _sessionMixState.value.copy(
            renderedMixPath = null,
            renderedMixSha256 = null,
            mastering = false,
            masteringProgress = 0f,
            masteredMixPath = null,
            masteredMixSha256 = null,
            renderProgress = 0f
        )
    }

    private fun releaseSessionMix() {
        sessionMixRenderJob?.cancel()
        sessionMixRenderJob = null
        sessionMixPrepareJob?.cancel()
        sessionMixPrepareJob = null
        sessionMixCollectJob?.cancel()
        sessionMixCollectJob = null
        sessionMixPlayer?.close()
        sessionMixPlayer = null
    }

    private fun scheduleFxPersistence() {
        val outputPath = _dspState.value.outputFilePath ?: return
        fxPersistJob?.cancel()
        fxPersistJob = viewModelScope.launch {
            delay(450L)
            val snapshot = _editorState.value
            withContext(Dispatchers.IO) {
                runCatching { VocalFxMetadataStore.save(outputPath, snapshot) }
            }
        }
    }

    private fun releasePreview() {
        previewCollectJob?.cancel()
        previewCollectJob = null
        previewPlayer?.close()
        previewPlayer = null
    }

    fun reset() {
        takeCoordinatorJob?.cancel()
        takeCoordinatorJob = null
        _countdown.value = null
        _sessionMessage.value = null
        postTakePrepareJob?.cancel()
        postTakePrepareJob = null
        dspJob?.cancel()
        dspJob = null
        sessionMixRenderJob?.cancel()
        sessionMixRenderJob = null
        pendingExportStart = false
        _postTakeState.value = PostTakeState()
        if (_productionBackingSource.value?.let(ProductionSourcePolicy::isGeneratedVoiceOnlyBacking) == true) {
            _productionBackingSource.value = playbackSource?.let(ProductionSourcePolicy::automaticFor)
        }
        releasePreview()
        releaseSessionMix()
        exportEngine.cancel()
        compositionPreviewEngine.invalidate()
        _sessionMixState.value = SessionMixState()
        _videoProjectState.value = VideoProjectState()
        _deliveryState.value = DeliveryState()
        lastIndexedExportPath = null
        lastIndexedTakePath = null
        lastSavedRawPath = null
        lastProcessedRawPath = null
        lastPlaybackStartOffsetMs = null
        tempoGeneration.incrementAndGet()
        tempoJob?.cancel()
        fxPersistJob?.cancel()
        tapTempo.reset()
        _dspState.value = DspUiState()
        _editorState.value = VocalEditorState()
        playbackControl?.pause()
        playbackControl?.seekTo(0L)
        cameraEngine?.abort()
        recorder.resetSavedState()
    }

    override fun onCleared() {
        postTakePrepareJob?.cancel()
        dspJob?.cancel()
        sessionMixRenderJob?.cancel()
        takeCoordinatorJob?.cancel()
        playbackCollectJob?.cancel()
        tempoGeneration.incrementAndGet()
        tempoJob?.cancel()
        fxPersistJob?.cancel()
        releasePreview()
        releaseSessionMix()
        exportEngine.release()
        compositionPreviewEngine.release()
        cameraEngine?.abort()
        super.onCleared()
    }
}
