package com.kolbomusic.singstudio.ui.library

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.sizeIn
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.IosShare
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.kolbomusic.singstudio.core.delivery.ShareIntentFactory
import com.kolbomusic.singstudio.core.library.LibraryFilter
import com.kolbomusic.singstudio.core.library.LibraryItem
import com.kolbomusic.singstudio.core.library.LibraryItemStatus
import com.kolbomusic.singstudio.ui.theme.ElectricViolet
import com.kolbomusic.singstudio.ui.theme.GraphiteElevated
import com.kolbomusic.singstudio.ui.theme.RecordRose
import com.kolbomusic.singstudio.ui.theme.WarmGold
import java.io.File
import java.text.DateFormat
import java.util.Date

@Composable
fun LibraryScreen(
    onBack: () -> Unit,
    onOpenProject: (LibraryItem) -> Unit,
    viewModel: LibraryViewModel = viewModel()
) {
    val context = LocalContext.current
    val state by viewModel.state.collectAsStateWithLifecycle()
    var renameItem by remember { mutableStateOf<LibraryItem?>(null) }
    var deleteItem by remember { mutableStateOf<LibraryItem?>(null) }
    var pendingLegacyGalleryId by remember { mutableStateOf<String?>(null) }

    val legacyStoragePermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        val id = pendingLegacyGalleryId
        pendingLegacyGalleryId = null
        if (granted && id != null) viewModel.publishToGallery(id)
    }

    LaunchedEffect(Unit) { viewModel.refresh() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.statusBars)
            .windowInsetsPadding(WindowInsets.navigationBars)
            .padding(horizontal = 18.dp, vertical = 12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "חזרה") }
            Column(modifier = Modifier.weight(1f)) {
                Text("היצירות שלי", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
                Text("טייקים, טיוטות וסרטונים מוכנים", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text("0.18.0", color = WarmGold, fontWeight = FontWeight.Bold)
        }

        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = state.searchQuery,
            onValueChange = viewModel::setSearch,
            modifier = Modifier.fillMaxWidth(),
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            label = { Text("חיפוש") },
            singleLine = true
        )
        Spacer(Modifier.height(10.dp))
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            LibraryFilter.entries.forEach { filter ->
                FilterChip(
                    selected = state.filter == filter,
                    onClick = { viewModel.setFilter(filter) },
                    label = { Text(filter.labelHe) }
                )
            }
        }

        state.message?.let {
            Spacer(Modifier.height(8.dp))
            StatusBanner(it, error = false, onDismiss = viewModel::clearMessage)
        }
        state.errorMessage?.let {
            Spacer(Modifier.height(8.dp))
            StatusBanner(it, error = true, onDismiss = viewModel::clearMessage)
        }

        Spacer(Modifier.height(10.dp))
        if (!state.loading && state.visibleItems.isEmpty()) {
            EmptyLibrary(modifier = Modifier.weight(1f))
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(state.visibleItems, key = { it.id }) { item ->
                    LibraryItemCard(
                        item = item,
                        onOpenProject = { onOpenProject(item) },
                        onFavorite = { viewModel.toggleFavorite(item.id) },
                        onRename = { renameItem = item },
                        onDelete = { deleteItem = item },
                        onGallery = {
                            if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
                                ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
                            ) {
                                pendingLegacyGalleryId = item.id
                                legacyStoragePermission.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                            } else {
                                viewModel.publishToGallery(item.id)
                            }
                        },
                        onShare = {
                            val file = item.exportPath?.let(::File)
                            if (file?.isFile == true) {
                                runCatching { context.startActivity(ShareIntentFactory.createVideoChooser(context, file, item.title)) }
                            }
                        }
                    )
                }
            }
        }
    }

    renameItem?.let { item ->
        var value by remember(item.id) { mutableStateOf(item.title) }
        AlertDialog(
            onDismissRequest = { renameItem = null },
            title = { Text("שינוי שם") },
            text = {
                OutlinedTextField(
                    value = value,
                    onValueChange = { value = it.take(120) },
                    label = { Text("שם היצירה") },
                    singleLine = true
                )
            },
            confirmButton = {
                Button(onClick = { viewModel.rename(item.id, value); renameItem = null }) { Text("שמור") }
            },
            dismissButton = { TextButton(onClick = { renameItem = null }) { Text("ביטול") } }
        )
    }

    deleteItem?.let { item ->
        AlertDialog(
            onDismissRequest = { deleteItem = null },
            title = { Text("להסיר את היצירה?") },
            text = { Text("קבצי הפרויקט הפרטיים יימחקו. אם כבר שמרת עותק לגלריה, הוא יישאר שם ולא יימחק אוטומטית.") },
            confirmButton = {
                Button(
                    onClick = { viewModel.deletePrivate(item.id); deleteItem = null },
                    colors = ButtonDefaults.buttonColors(containerColor = RecordRose)
                ) { Text("מחק מהמכשיר") }
            },
            dismissButton = { TextButton(onClick = { deleteItem = null }) { Text("ביטול") } }
        )
    }
}

@Composable
private fun LibraryItemCard(
    item: LibraryItem,
    onOpenProject: () -> Unit,
    onFavorite: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit,
    onGallery: () -> Unit,
    onShare: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = GraphiteElevated),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Thumbnail(item)
                Column(modifier = Modifier.weight(1f)) {
                    Text(item.title, fontWeight = FontWeight.ExtraBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(
                        buildString {
                            append(if (item.status == LibraryItemStatus.Ready) "סרטון מוכן" else "טיוטה")
                            if (item.durationMs > 0L) append(" · ${formatDuration(item.durationMs)}")
                        },
                        color = if (item.status == LibraryItemStatus.Ready) WarmGold else MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(item.updatedAtEpochMs)),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = onFavorite) {
                    Icon(
                        if (item.favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = if (item.favorite) "הסר ממועדפים" else "הוסף למועדפים",
                        tint = if (item.favorite) RecordRose else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (item.projectPath != null) {
                    Button(
                        onClick = onOpenProject,
                        modifier = Modifier.sizeIn(minHeight = 48.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricViolet)
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = null)
                        Spacer(Modifier.width(5.dp))
                        Text("המשך עריכה")
                    }
                }
                OutlinedButton(onClick = onRename, modifier = Modifier.sizeIn(minHeight = 48.dp)) { Text("שנה שם") }
                if (item.status == LibraryItemStatus.Ready && item.exportPath != null) {
                    OutlinedButton(onClick = onGallery, enabled = item.galleryUri == null, modifier = Modifier.sizeIn(minHeight = 48.dp)) {
                        Icon(Icons.Default.PhotoLibrary, contentDescription = null)
                        Spacer(Modifier.width(5.dp))
                        Text(if (item.galleryUri != null) "נשמר בגלריה" else "שמור לגלריה")
                    }
                    Button(
                        onClick = onShare,
                        modifier = Modifier.sizeIn(minHeight = 48.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricViolet)
                    ) {
                        Icon(Icons.Default.IosShare, contentDescription = null)
                        Spacer(Modifier.width(5.dp))
                        Text("שתף")
                    }
                }
                IconButton(onClick = onDelete, modifier = Modifier.sizeIn(minWidth = 48.dp, minHeight = 48.dp)) {
                    Icon(Icons.Default.DeleteOutline, contentDescription = "מחק מהמכשיר", tint = RecordRose)
                }
            }
        }
    }
}

@Composable
private fun Thumbnail(item: LibraryItem) {
    val bitmap = remember(item.thumbnailPath) {
        item.thumbnailPath?.let { path -> runCatching { BitmapFactory.decodeFile(path)?.asImageBitmap() }.getOrNull() }
    }
    Box(
        modifier = Modifier
            .width(112.dp)
            .aspectRatio(16f / 9f)
            .background(Color.Black, RoundedCornerShape(14.dp)),
        contentAlignment = Alignment.Center
    ) {
        if (bitmap != null) {
            Image(bitmap = bitmap, contentDescription = "תמונה מקדימה של ${item.title}", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Icon(if (item.status == LibraryItemStatus.Ready) Icons.Default.Movie else Icons.Default.FolderOpen, contentDescription = null, tint = WarmGold)
        }
    }
}

@Composable
private fun EmptyLibrary(modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Icon(Icons.Default.FolderOpen, contentDescription = null, tint = ElectricViolet)
            Text("עוד אין כאן יצירות", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("אחרי שמירת טיוטה או הפקת סרטון הם יופיעו כאן אוטומטית.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun StatusBanner(text: String, error: Boolean, onDismiss: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = if (error) RecordRose.copy(alpha = 0.14f) else ElectricViolet.copy(alpha = 0.14f))) {
        Row(modifier = Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(text, modifier = Modifier.weight(1f), color = if (error) RecordRose else MaterialTheme.colorScheme.onSurface)
            TextButton(onClick = onDismiss) { Text("סגור") }
        }
    }
}

private fun formatDuration(ms: Long): String {
    val totalSeconds = (ms.coerceAtLeast(0L) / 1000L)
    val minutes = totalSeconds / 60L
    val seconds = totalSeconds % 60L
    return "%d:%02d".format(minutes, seconds)
}
