@file:androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)

package com.kolbomusic.singstudio.core.export

import android.graphics.Matrix
import androidx.media3.effect.MatrixTransformation

class PositionZoomTransformation(
    private val zoom: Float,
    private val offsetX: Float,
    private val offsetY: Float
) : MatrixTransformation {
    private val matrix = Matrix()

    override fun getMatrix(presentationTimeUs: Long): Matrix {
        matrix.reset()
        val safeZoom = zoom.coerceIn(0.5f, 3f)
        matrix.postScale(safeZoom, safeZoom)
        matrix.postTranslate(offsetX.coerceIn(-1f, 1f) * 2f, -offsetY.coerceIn(-1f, 1f) * 2f)
        return matrix
    }

    override fun isNoOp(inputWidth: Int, inputHeight: Int): Boolean =
        zoom == 1f && offsetX == 0f && offsetY == 0f
}
