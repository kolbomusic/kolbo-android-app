package com.kolbomusic.singstudio.core.mix

import com.kolbomusic.singstudio.core.dsp.Biquad
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.sqrt

/**
 * Phrase-aware automatic vocal riding for the final render.
 *
 * 0.17.0 measures the vocal-presence band rather than full-band accompaniment RMS.
 * Bass/kick energy must not trick the balance engine into over-attenuating the singer.
 * The processor follows phrase dynamics slowly enough to stay musical and uses only
 * modest accompaniment ducking when the vocal is genuinely masked in the midrange.
 */
class AdaptiveVocalBalanceProcessor(private val sampleRate: Int) {
    data class BlockBalance(
        val vocalGainMultiplier: Float,
        val playbackGainMultiplier: Float,
        val vocalRideDb: Double,
        val playbackDuckDb: Double,
        val vocalActive: Boolean,
        val vocalLevelDbfs: Double,
        val backingLevelDbfs: Double
    )

    private val vocalHp = Biquad.highPass(sampleRate, 250.0)
    private val vocalLp = Biquad.lowPass(sampleRate, minOf(6_500.0, sampleRate * 0.42))
    private val backingLeftHp = Biquad.highPass(sampleRate, 250.0)
    private val backingLeftLp = Biquad.lowPass(sampleRate, minOf(6_500.0, sampleRate * 0.42))
    private val backingRightHp = Biquad.highPass(sampleRate, 250.0)
    private val backingRightLp = Biquad.lowPass(sampleRate, minOf(6_500.0, sampleRate * 0.42))

    private var smoothedRideDb = 0.0
    private var smoothedDuckDb = 0.0
    private var runningActiveVocalDb: Double? = null

    fun balance(
        backingInterleaved: FloatArray,
        backingChannels: Int,
        vocalMono: FloatArray,
        frames: Int,
        basePlaybackGain: Float,
        baseVocalGain: Float
    ): BlockBalance {
        if (frames <= 0) {
            return BlockBalance(1f, 1f, smoothedRideDb, smoothedDuckDb, false, -250.0, -250.0)
        }

        var backingSquares = 0.0
        var vocalSquares = 0.0
        var vocalPeak = 0.0
        repeat(frames) { frame ->
            val vocal = vocalMono[frame].toDouble() * baseVocalGain
            val vocalPresence = vocalLp.process(vocalHp.process(vocal))
            vocalSquares += vocalPresence * vocalPresence
            vocalPeak = maxOf(vocalPeak, abs(vocal))

            if (backingChannels == 1) {
                val raw = backingInterleaved[frame].toDouble() * basePlaybackGain
                val p = backingLeftLp.process(backingLeftHp.process(raw))
                backingSquares += p * p
            } else {
                val leftRaw = backingInterleaved[frame * backingChannels].toDouble() * basePlaybackGain
                val rightRaw = backingInterleaved[frame * backingChannels + 1].toDouble() * basePlaybackGain
                val left = backingLeftLp.process(backingLeftHp.process(leftRaw))
                val right = backingRightLp.process(backingRightHp.process(rightRaw))
                backingSquares += (left * left + right * right) * 0.5
            }
        }

        val backingDb = linearToDb(sqrt(backingSquares / frames.toDouble()))
        val vocalDb = linearToDb(sqrt(vocalSquares / frames.toDouble()))
        val vocalPeakDb = linearToDb(vocalPeak)
        val vocalActive = vocalDb > -54.0 && vocalPeakDb > -44.0

        var desiredRideDb = -0.8
        var desiredDuckDb = 0.0
        if (vocalActive) {
            val running = runningActiveVocalDb
            if (running == null) {
                runningActiveVocalDb = vocalDb
            } else {
                val bounded = vocalDb.coerceIn(running - 5.0, running + 5.0)
                runningActiveVocalDb = running + (bounded - running) * 0.015
            }

            val typical = runningActiveVocalDb ?: vocalDb
            val phraseCorrection = ((typical - vocalDb) * 0.52).coerceIn(-3.0, 3.0)

            // Presence-band target: the singer may sit slightly behind the accompaniment
            // energy overall, but should stay close enough in the 250 Hz-6.5 kHz band to
            // remain intelligible and naturally forward.
            val relativeTargetDb = (backingDb - 2.5).coerceIn(-27.0, -18.0)
            val relativeCorrection = ((relativeTargetDb - vocalDb) * 0.44).coerceIn(-3.0, 3.0)
            desiredRideDb = (phraseCorrection + relativeCorrection).coerceIn(-4.0, 3.5)

            val predictedVocalDb = vocalDb + desiredRideDb
            val maskingGap = backingDb - predictedVocalDb
            desiredDuckDb = when {
                maskingGap > 6.5 -> -1.10
                maskingGap > 5.0 -> -0.75
                maskingGap > 3.8 -> -0.40
                else -> 0.0
            }
        }

        val blockMs = frames.toDouble() * 1000.0 / sampleRate.coerceAtLeast(8_000).toDouble()
        smoothedRideDb = smooth(
            current = smoothedRideDb,
            target = desiredRideDb,
            blockMs = blockMs,
            towardMoreGainMs = 280.0,
            towardLessGainMs = 95.0
        )
        smoothedDuckDb = smooth(
            current = smoothedDuckDb,
            target = desiredDuckDb,
            blockMs = blockMs,
            towardMoreGainMs = 500.0,
            towardLessGainMs = 170.0
        )

        return BlockBalance(
            vocalGainMultiplier = dbToLinear(smoothedRideDb).toFloat(),
            playbackGainMultiplier = dbToLinear(smoothedDuckDb).toFloat(),
            vocalRideDb = smoothedRideDb,
            playbackDuckDb = smoothedDuckDb,
            vocalActive = vocalActive,
            vocalLevelDbfs = vocalDb,
            backingLevelDbfs = backingDb
        )
    }

    private fun smooth(
        current: Double,
        target: Double,
        blockMs: Double,
        towardMoreGainMs: Double,
        towardLessGainMs: Double
    ): Double {
        val timeMs = if (target > current) towardMoreGainMs else towardLessGainMs
        val alpha = 1.0 - exp(-blockMs / timeMs.coerceAtLeast(1.0))
        return current + (target - current) * alpha
    }

    private fun linearToDb(value: Double): Double =
        if (value <= 1e-12) -250.0 else 20.0 * log10(value)

    private fun dbToLinear(db: Double): Double = 10.0.pow(db / 20.0)
}
