package com.kolbomusic.singstudio.ui.playback

import android.os.SystemClock
import android.view.ViewGroup
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.kolbomusic.singstudio.core.model.PlaybackState
import com.kolbomusic.singstudio.core.playback.PlaybackControl
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.PlayerConstants
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.options.IFramePlayerOptions
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.atomic.AtomicReference

/**
 * Stable YouTube IFrame playback bridge.
 *
 * The player View is created once for the lifetime of this composable and is not rebuilt when the
 * recording UI changes. This is important on devices where a WebView video surface can turn black
 * when it is detached/resized while CameraX starts an encoder.
 */
class YouTubePlaybackHandle : PlaybackControl {
    private val _state = MutableStateFlow(PlaybackState())
    override val state: StateFlow<PlaybackState> = _state.asStateFlow()

    private var player: YouTubePlayer? = null
    private var playerView: YouTubePlayerView? = null
    private var released = false
    private var durationMs: Long = 0L
    private var currentMs: Long = 0L
    private var lastPlayerState: PlayerConstants.PlayerState? = null

    internal fun attachView(view: YouTubePlayerView) {
        if (!released) playerView = view
    }

    internal fun onReady(youtubePlayer: YouTubePlayer) {
        if (released) return
        player = youtubePlayer
        // Wait for VIDEO_CUED before exposing the take controls. onReady only means
        // that the iframe bridge exists; the selected video may not be ready yet.
        _state.value = _state.value.copy(prepared = false, buffering = true, errorMessage = null)
    }

    internal fun onStateChange(state: PlayerConstants.PlayerState) {
        if (released) return
        val wasPlaying = lastPlayerState == PlayerConstants.PlayerState.PLAYING
        lastPlayerState = state
        when (state) {
            PlayerConstants.PlayerState.PLAYING -> {
                val startedNs = if (!wasPlaying) SystemClock.elapsedRealtimeNanos()
                else _state.value.startedElapsedRealtimeNs
                _state.value = _state.value.copy(
                    prepared = true,
                    playing = true,
                    buffering = false,
                    ended = false,
                    positionMs = currentMs,
                    durationMs = durationMs,
                    startedElapsedRealtimeNs = startedNs,
                    errorMessage = null
                )
            }
            PlayerConstants.PlayerState.PAUSED -> _state.value = _state.value.copy(
                playing = false, buffering = false, positionMs = currentMs, durationMs = durationMs
            )
            PlayerConstants.PlayerState.BUFFERING -> _state.value = _state.value.copy(
                prepared = true, playing = false, buffering = true, positionMs = currentMs, durationMs = durationMs
            )
            PlayerConstants.PlayerState.ENDED -> _state.value = _state.value.copy(
                playing = false, buffering = false, ended = true, positionMs = durationMs, durationMs = durationMs
            )
            PlayerConstants.PlayerState.VIDEO_CUED -> _state.value = _state.value.copy(
                prepared = true, playing = false, buffering = false, positionMs = currentMs, durationMs = durationMs
            )
            else -> Unit
        }
    }

    internal fun onCurrentSecond(second: Float) {
        currentMs = (second.coerceAtLeast(0f) * 1000f).toLong()
        _state.value = _state.value.copy(positionMs = currentMs, durationMs = durationMs)
    }

    internal fun onDuration(seconds: Float) {
        durationMs = (seconds.coerceAtLeast(0f) * 1000f).toLong()
        _state.value = _state.value.copy(durationMs = durationMs)
    }

    internal fun onError(error: PlayerConstants.PlayerError) {
        _state.value = _state.value.copy(
            playing = false,
            buffering = false,
            errorMessage = "YouTube Player error: ${error.name}"
        )
    }

    override fun playFromStart() {
        if (released) return
        _state.value = _state.value.copy(ended = false, errorMessage = null)
        player?.seekTo(0f)
        player?.play()
    }

    override fun pause() {
        if (!released) player?.pause()
    }

    override fun seekTo(positionMs: Long) {
        if (!released) player?.seekTo(positionMs.coerceAtLeast(0L) / 1000f)
    }

    override fun release() {
        if (released) return
        released = true
        player = null
        runCatching { playerView?.release() }
        playerView = null
    }
}

@Composable
fun YouTubePlayerSurface(
    videoId: String,
    handle: YouTubePlaybackHandle,
    modifier: Modifier = Modifier
) {
    require(Regex("^[A-Za-z0-9_-]{11}$").matches(videoId)) { "Invalid YouTube video id" }

    val lifecycleOwner = LocalLifecycleOwner.current
    val playerViewRef = remember { AtomicReference<YouTubePlayerView?>(null) }

    val listener = remember(videoId, handle) {
        object : AbstractYouTubePlayerListener() {
            override fun onReady(youTubePlayer: YouTubePlayer) {
                handle.onReady(youTubePlayer)
                youTubePlayer.cueVideo(videoId, 0f)
            }

            override fun onStateChange(youTubePlayer: YouTubePlayer, state: PlayerConstants.PlayerState) {
                handle.onStateChange(state)
            }

            override fun onCurrentSecond(youTubePlayer: YouTubePlayer, second: Float) {
                handle.onCurrentSecond(second)
            }

            override fun onVideoDuration(youTubePlayer: YouTubePlayer, duration: Float) {
                handle.onDuration(duration)
            }

            override fun onError(youTubePlayer: YouTubePlayer, error: PlayerConstants.PlayerError) {
                handle.onError(error)
            }
        }
    }

    AndroidView(
        modifier = modifier,
        factory = { context ->
            YouTubePlayerView(context).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                enableAutomaticInitialization = false
                handle.attachView(this)
                playerViewRef.set(this)
                lifecycleOwner.lifecycle.addObserver(this)
                val options = IFramePlayerOptions.Builder(context)
                    .controls(0)
                    .rel(0)
                    .fullscreen(0)
                    .ivLoadPolicy(3)
                    .build()
                initialize(listener, true, options)
            }
        }
    )

    DisposableEffect(handle, lifecycleOwner) {
        onDispose {
            playerViewRef.getAndSet(null)?.let { view ->
                lifecycleOwner.lifecycle.removeObserver(view)
            }
            handle.release()
        }
    }
}
