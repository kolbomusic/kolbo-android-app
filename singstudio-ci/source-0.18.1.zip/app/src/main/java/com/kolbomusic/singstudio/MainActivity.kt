package com.kolbomusic.singstudio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.kolbomusic.singstudio.ui.KolboSingApp
import com.kolbomusic.singstudio.ui.theme.KolboSingTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            KolboSingTheme {
                KolboSingApp()
            }
        }
    }
}
