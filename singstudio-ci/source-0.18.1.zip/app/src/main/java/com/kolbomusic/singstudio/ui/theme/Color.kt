package com.kolbomusic.singstudio.ui.theme

import androidx.compose.ui.graphics.Color

val Night = Color(0xFF0B0B10)
val Graphite = Color(0xFF15151D)
val GraphiteElevated = Color(0xFF1E1E29)
val ElectricViolet = Color(0xFF8B5CF6)
val ElectricVioletBright = Color(0xFFA78BFA)
val RecordRose = Color(0xFFFF3B6B)
val WarmGold = Color(0xFFFFC857)
val Mint = Color(0xFF2DD4BF)
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFFB7BBC7)
val Hairline = Color(0xFF2A2A37)
