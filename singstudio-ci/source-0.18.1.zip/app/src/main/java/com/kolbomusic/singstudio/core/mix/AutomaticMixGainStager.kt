package com.kolbomusic.singstudio.core.mix

import com.kolbomusic.singstudio.core.dsp.PreviewSource
import com.kolbomusic.singstudio.core.dsp.Biquad
import com.kolbomusic.singstudio.core.dsp.VocalFxSettings
import java.io.File
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.sqrt

/**
 * Analyses the backing and processed vocal independently and establishes conservative
 * gain staging before the final mix/master. This prevents the previous fixed 0 dB
 * vocal / -2 dB backing relationship from making the singer unnaturally dominant.
 */
class AutomaticMixGainStager {
    data class StemAnalysis(
        val peakDbfs: Double,
        val activeRmsDbfs: Double,
        val activeBlocks: Int
    )

    data class Result(
        val settings: SessionMixSettings,
        val backing: StemAnalysis,
        val vocal: StemAnalysis
    )

    fun recommend(
        backingFile: File,
        processedVocalFile: File,
        fxSettings: VocalFxSettings = VocalFxSettings()
    ): Result {
        val backing = analyse(backingFile)
        val vocal = analyse(processedVocalFile)
        val fx = fxSettings.sanitized()

        // Reverb/delay add correlated energy after the dry vocal has been measured.
        // Reserve explicit headroom for that wet build-up so the automatic mix does
        // not make a polished-but-too-loud vocal jump in front of the karaoke track.
        val wetSafetyDb = (
            fx.reverbMix * 2.8f +
                fx.delayMix * 2.2f +
                fx.outputGainDb.coerceAtLeast(0f)
            ).toDouble().coerceIn(0.0, 2.0)

        val playbackGainDb = recommendedGain(
            analysis = backing,
            targetActiveRmsDb = -19.5,
            targetPeakDb = -4.0,
            fallbackDb = -3.0
        )
        val vocalGainDb = recommendedGain(
            analysis = vocal,
            targetActiveRmsDb = -22.5 - wetSafetyDb,
            targetPeakDb = -6.5 - wetSafetyDb,
            fallbackDb = -6.0
        )

        return Result(
            settings = SessionMixSettings(
                vocalGainDb = vocalGainDb.toFloat(),
                playbackGainDb = playbackGainDb.toFloat(),
                masterHeadroomDb = -4.0f,
                previewSource = PreviewSource.Processed
            ).sanitized(),
            backing = backing,
            vocal = vocal
        )
    }

    private fun recommendedGain(
        analysis: StemAnalysis,
        targetActiveRmsDb: Double,
        targetPeakDb: Double,
        fallbackDb: Double
    ): Double {
        if (analysis.activeBlocks == 0 || analysis.activeRmsDbfs <= -100.0) return fallbackDb
        val rmsGain = targetActiveRmsDb - analysis.activeRmsDbfs
        val peakGain = targetPeakDb - analysis.peakDbfs
        return minOf(rmsGain, peakGain).coerceIn(-12.0, 3.0)
    }

    private fun analyse(file: File): StemAnalysis {
        Pcm16InterleavedWavReader(file).use { reader ->
            val blockFrames = 2048
            val samples = FloatArray(blockFrames * reader.channels)
            val activeRms = ArrayList<Double>()
            val hp = Array(reader.channels.coerceAtMost(2)) { Biquad.highPass(reader.sampleRate, 250.0) }
            val lp = Array(reader.channels.coerceAtMost(2)) {
                Biquad.lowPass(reader.sampleRate, minOf(6_500.0, reader.sampleRate * 0.42))
            }
            var peak = 0.0
            var frame = 0L
            while (frame < reader.frameCount) {
                val requested = minOf(blockFrames.toLong(), reader.frameCount - frame).toInt()
                val read = reader.readFrames(frame, samples, 0, requested)
                check(read > 0) { "קריאת Stem נקטעה בזמן Gain Staging" }
                var energy = 0.0
                var measured = 0
                repeat(read) { f ->
                    val channelsToMeasure = reader.channels.coerceAtMost(2)
                    repeat(channelsToMeasure) { c ->
                        val value = samples[f * reader.channels + c].toDouble()
                        peak = maxOf(peak, abs(value))
                        val presence = lp[c].process(hp[c].process(value))
                        energy += presence * presence
                        measured++
                    }
                }
                val rms = if (measured > 0) sqrt(energy / measured.toDouble()) else 0.0
                val db = linearToDb(rms)
                if (db > -58.0) activeRms += db
                frame += read
            }

            val typical = if (activeRms.isEmpty()) {
                -250.0
            } else {
                val sorted = activeRms.sorted()
                sorted[(sorted.lastIndex * 0.60).toInt().coerceIn(0, sorted.lastIndex)]
            }
            return StemAnalysis(
                peakDbfs = linearToDb(peak),
                activeRmsDbfs = typical,
                activeBlocks = activeRms.size
            )
        }
    }

    private fun linearToDb(value: Double): Double =
        if (value <= 1e-12) -250.0 else 20.0 * log10(value)
}
