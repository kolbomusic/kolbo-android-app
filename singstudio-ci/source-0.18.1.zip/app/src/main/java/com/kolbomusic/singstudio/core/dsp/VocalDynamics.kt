package com.kolbomusic.singstudio.core.dsp

import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.log10
import kotlin.math.pow

internal object VocalDynamics {
    fun noiseGate(samples: FloatArray, sampleRate: Int, thresholdDb: Double, floorDb: Double) {
        val threshold = dbToLinear(thresholdDb)
        val floor = dbToLinear(floorDb)
        val attack = coefficient(4.0, sampleRate)
        val release = coefficient(95.0, sampleRate)
        var gain = 1.0
        for (i in samples.indices) {
            val target = if (abs(samples[i].toDouble()) >= threshold) 1.0 else floor
            val coeff = if (target > gain) attack else release
            gain = target + coeff * (gain - target)
            samples[i] = (samples[i] * gain).toFloat()
        }
    }

    fun compressor(
        samples: FloatArray,
        sampleRate: Int,
        thresholdDb: Double,
        ratio: Double,
        attackMs: Double,
        releaseMs: Double
    ) {
        val attack = coefficient(attackMs, sampleRate)
        val release = coefficient(releaseMs, sampleRate)
        var envelope = 0.0
        for (i in samples.indices) {
            val level = abs(samples[i].toDouble()).coerceAtLeast(1e-9)
            val coeff = if (level > envelope) attack else release
            envelope = level + coeff * (envelope - level)
            val envDb = linearToDb(envelope)
            val reductionDb = if (envDb > thresholdDb) {
                val compressed = thresholdDb + (envDb - thresholdDb) / ratio
                compressed - envDb
            } else 0.0
            samples[i] = (samples[i] * dbToLinear(reductionDb)).toFloat()
        }
    }

    fun deEsser(
        samples: FloatArray,
        sampleRate: Int,
        thresholdDb: Double,
        maxReductionDb: Double
    ) {
        val detector = Biquad.highPass(sampleRate, minOf(5_600.0, sampleRate * 0.2), 0.707)
        val attack = coefficient(2.0, sampleRate)
        val release = coefficient(70.0, sampleRate)
        var env = 0.0
        for (i in samples.indices) {
            val hf = abs(detector.process(samples[i].toDouble()))
            val coeff = if (hf > env) attack else release
            env = hf + coeff * (env - hf)
            val db = linearToDb(env.coerceAtLeast(1e-9))
            val over = (db - thresholdDb).coerceAtLeast(0.0)
            val reduction = (-over * 0.55).coerceAtLeast(-maxReductionDb)
            samples[i] = (samples[i] * dbToLinear(reduction)).toFloat()
        }
    }

    fun limiter(samples: FloatArray, ceilingDb: Double) {
        val ceiling = dbToLinear(ceilingDb)
        for (i in samples.indices) {
            val x = samples[i].toDouble()
            val absX = abs(x)
            if (absX <= ceiling) continue
            val excess = (absX - ceiling) / (1.0 - ceiling).coerceAtLeast(1e-6)
            val softened = ceiling + (1.0 - exp(-2.4 * excess)) * (1.0 - ceiling) * 0.16
            samples[i] = (kotlin.math.sign(x) * softened.coerceAtMost(0.9995)).toFloat()
        }
    }

    fun applyGain(samples: FloatArray, gainDb: Double) {
        val gain = dbToLinear(gainDb)
        for (i in samples.indices) samples[i] = (samples[i] * gain).toFloat()
    }

    fun linearToDb(value: Double): Double = 20.0 * log10(value.coerceAtLeast(1e-12))
    fun dbToLinear(db: Double): Double = 10.0.pow(db / 20.0)
    private fun coefficient(ms: Double, sampleRate: Int): Double = exp(-1.0 / (0.001 * ms.coerceAtLeast(0.1) * sampleRate))
}
