package com.kolbomusic.singstudio.core.recording

import com.kolbomusic.singstudio.core.audio.WavFileTools
import org.json.JSONObject
import java.io.File

class TakeRecoveryManager(private val takesDirectory: File) {

    fun recoverInterruptedTakes(): Int {
        if (!takesDirectory.exists()) return 0
        var recovered = 0

        takesDirectory.listFiles { file -> file.name.endsWith(".pcm.partial") }
            ?.forEach { pcm ->
                runCatching {
                    val baseName = pcm.name.removeSuffix(".pcm.partial")
                    val partialMetadata = File(takesDirectory, "$baseName.session.partial.json")
                    val originalMetadata = readMetadata(partialMetadata)
                    val sampleRate = originalMetadata?.optInt("sampleRate", 48_000) ?: 48_000
                    val recoveredWav = File(takesDirectory, "$baseName-recovered.wav")

                    if (pcm.length() > 0L) {
                        WavFileTools.finalizePcm16Mono(pcm, recoveredWav, sampleRate)
                        check(WavFileTools.validatePcm16Mono(recoveredWav))
                        val recoveredMetadata = JSONObject()
                            .put("id", baseName)
                            .put("recovered", true)
                            .put("sampleRate", sampleRate)
                            .put("file", recoveredWav.name)
                            .put("fileSizeBytes", recoveredWav.length())
                            .put("sha256", WavFileTools.sha256(recoveredWav))

                        originalMetadata?.let { source ->
                            listOf(
                                "playbackSourceId",
                                "playbackSourceType",
                                "playbackSourceTitle",
                                "playbackPositionMs",
                                "playbackStartOffsetMs",
                                "visualMode",
                                "outputAspectRatio",
                                "cameraFacing",
                                "backgroundType",
                                "backgroundId",
                                "backgroundTitle",
                                "backgroundUri",
                                "cameraFile",
                                "cameraRequestedAspectRatio",
                                "cameraStartOffsetMs"
                            ).forEach { key ->
                                if (source.has(key)) recoveredMetadata.put(key, source.get(key))
                            }
                        }

                        File(takesDirectory, "$baseName-recovered.json").writeText(
                            recoveredMetadata.toString(2)
                        )
                        recovered++
                    }
                    pcm.delete()
                    partialMetadata.delete()
                }
            }

        return recovered
    }

    private fun readMetadata(metadata: File): JSONObject? {
        if (!metadata.exists()) return null
        return runCatching { JSONObject(metadata.readText()) }.getOrNull()
    }
}
