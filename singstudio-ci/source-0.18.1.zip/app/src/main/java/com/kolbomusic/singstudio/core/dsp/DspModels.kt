package com.kolbomusic.singstudio.core.dsp

enum class VocalPresetId(val labelHe: String) {
    Auto("חכם"),
    Natural("טבעי"),
    Studio("אולפן"),
    Live("במה"),
    Ballad("בלדה"),
    Mizrahi("מזרחי"),
    Pop("פופ"),
    Dry("יבש")
}

data class VocalPreset(
    val id: VocalPresetId,
    val highPassHz: Double,
    val noiseReductionStrength: Double,
    val noiseFloorMarginDb: Double,
    val gateThresholdDb: Double,
    val gateFloorDb: Double,
    val compressorThresholdDb: Double,
    val compressorRatio: Double,
    val compressorAttackMs: Double,
    val compressorReleaseMs: Double,
    val deEsserThresholdDb: Double,
    val deEsserMaxReductionDb: Double,
    val warmthDb: Double,
    val presenceDb: Double,
    val outputGainDb: Double,
    val limiterCeilingDb: Double
)

data class VocalAnalysis(
    val durationMs: Long,
    val sampleRate: Int,
    val peakDbfs: Double,
    val rmsDbfs: Double,
    val estimatedNoiseFloorDbfs: Double,
    val clippingSamples: Long,
    val dynamicRangeEstimateDb: Double,
    val recommendedPreset: VocalPresetId
)

enum class DspStage(val labelHe: String) {
    Idle("מוכן"),
    Loading("טוען הקלטה"),
    Analysing("מנתח קול"),
    NoiseReduction("מנקה רעשים"),
    Tone("מאזן תדרים"),
    Dynamics("מאזן דינמיקה"),
    Finalising("מסיים ומאמת"),
    Completed("מוכן להאזנה"),
    Error("שגיאה")
}

data class DspUiState(
    val stage: DspStage = DspStage.Idle,
    val progress: Float = 0f,
    val selectedPreset: VocalPresetId = VocalPresetId.Auto,
    val resolvedPreset: VocalPresetId? = null,
    val analysis: VocalAnalysis? = null,
    val outputFilePath: String? = null,
    val outputSha256: String? = null,
    val errorMessage: String? = null
) {
    val processing: Boolean get() = when (stage) {
        DspStage.Loading,
        DspStage.Analysing,
        DspStage.NoiseReduction,
        DspStage.Tone,
        DspStage.Dynamics,
        DspStage.Finalising -> true
        else -> false
    }
}

data class DspRenderResult(
    val outputFilePath: String,
    val outputSha256: String,
    val analysis: VocalAnalysis,
    val resolvedPreset: VocalPresetId
)

object VocalPresets {
    private val presets = mapOf(
        VocalPresetId.Natural to VocalPreset(
            VocalPresetId.Natural, 75.0, 0.58, 7.0, -49.0, -22.0,
            -18.0, 2.2, 14.0, 120.0, -24.0, 4.0,
            0.6, 1.1, 0.5, -1.0
        ),
        VocalPresetId.Studio to VocalPreset(
            VocalPresetId.Studio, 85.0, 0.72, 8.0, -47.0, -26.0,
            -20.0, 3.0, 10.0, 135.0, -25.0, 5.5,
            0.8, 2.0, 1.0, -0.9
        ),
        VocalPresetId.Live to VocalPreset(
            VocalPresetId.Live, 90.0, 0.52, 7.0, -45.0, -20.0,
            -17.0, 2.4, 8.0, 100.0, -23.0, 4.0,
            0.2, 2.4, 1.4, -0.8
        ),
        VocalPresetId.Ballad to VocalPreset(
            VocalPresetId.Ballad, 72.0, 0.65, 8.0, -50.0, -24.0,
            -22.0, 2.5, 18.0, 180.0, -27.0, 4.5,
            1.4, 1.4, 0.7, -1.0
        ),
        VocalPresetId.Mizrahi to VocalPreset(
            VocalPresetId.Mizrahi, 88.0, 0.68, 8.0, -47.0, -24.0,
            -20.0, 2.8, 9.0, 125.0, -25.5, 5.0,
            0.9, 2.7, 1.1, -0.9
        ),
        VocalPresetId.Pop to VocalPreset(
            VocalPresetId.Pop, 95.0, 0.72, 8.0, -46.0, -25.0,
            -21.0, 3.4, 7.0, 105.0, -26.0, 6.0,
            -0.2, 3.0, 1.5, -0.8
        ),
        VocalPresetId.Dry to VocalPreset(
            VocalPresetId.Dry, 70.0, 0.42, 6.0, -53.0, -16.0,
            -14.0, 1.5, 18.0, 160.0, -20.0, 2.0,
            0.0, 0.4, 0.0, -1.0
        )
    )

    fun resolve(id: VocalPresetId, analysis: VocalAnalysis): VocalPreset {
        val resolved = if (id == VocalPresetId.Auto) analysis.recommendedPreset else id
        val base = requireNotNull(presets[resolved])
        if (id != VocalPresetId.Auto) return base

        val noisy = analysis.estimatedNoiseFloorDbfs > -43.0
        val quiet = analysis.rmsDbfs < -29.0
        return base.copy(
            noiseReductionStrength = (base.noiseReductionStrength + if (noisy) 0.12 else 0.0).coerceAtMost(0.9),
            compressorThresholdDb = base.compressorThresholdDb + if (quiet) -3.0 else 0.0,
            outputGainDb = base.outputGainDb + if (quiet) 1.5 else 0.0
        )
    }
}
