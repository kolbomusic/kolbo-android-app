package com.kolbomusic.singstudio.core.preferences

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.kolboPreferences by preferencesDataStore(name = "kolbo_user_preferences")

data class AppPreferences(
    val onboardingCompleted: Boolean = false,
    val largeControls: Boolean = true,
    val reduceMotion: Boolean = false
)

class AppPreferencesStore(private val context: Context) {
    private object Keys {
        val onboarding = booleanPreferencesKey("onboarding_completed")
        val largeControls = booleanPreferencesKey("large_controls")
        val reduceMotion = booleanPreferencesKey("reduce_motion")
    }

    val preferences: Flow<AppPreferences> = context.kolboPreferences.data.map { values ->
        AppPreferences(
            onboardingCompleted = values[Keys.onboarding] ?: false,
            largeControls = values[Keys.largeControls] ?: true,
            reduceMotion = values[Keys.reduceMotion] ?: false
        )
    }

    suspend fun completeOnboarding(largeControls: Boolean, reduceMotion: Boolean) {
        context.kolboPreferences.edit { values ->
            values[Keys.onboarding] = true
            values[Keys.largeControls] = largeControls
            values[Keys.reduceMotion] = reduceMotion
        }
    }


    suspend fun updateAccessibility(largeControls: Boolean, reduceMotion: Boolean) {
        context.kolboPreferences.edit { values ->
            values[Keys.largeControls] = largeControls
            values[Keys.reduceMotion] = reduceMotion
        }
    }

    suspend fun resetOnboarding() {
        context.kolboPreferences.edit { it[Keys.onboarding] = false }
    }
}
