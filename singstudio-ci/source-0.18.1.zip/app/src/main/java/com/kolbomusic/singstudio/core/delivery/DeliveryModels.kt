package com.kolbomusic.singstudio.core.delivery

enum class DeliveryPhase { Idle, Publishing, Published, Failed }

data class DeliveryState(
    val phase: DeliveryPhase = DeliveryPhase.Idle,
    val galleryUri: String? = null,
    val message: String? = null,
    val errorMessage: String? = null
) {
    val running: Boolean get() = phase == DeliveryPhase.Publishing
}
