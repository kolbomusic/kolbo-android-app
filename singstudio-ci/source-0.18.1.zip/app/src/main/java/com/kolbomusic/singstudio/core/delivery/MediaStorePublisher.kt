package com.kolbomusic.singstudio.core.delivery

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class MediaStorePublisher(private val context: Context) {
    fun publishVideo(source: File, displayTitle: String): Uri {
        require(source.isFile && source.length() > 0L) { "קובץ הסרטון אינו קיים" }
        val safeTitle = displayTitle.trim().replace(Regex("[\\/:*?\"<>|]+"), "-").take(80).ifBlank { "Kolbo Studio" }
        val fileName = "$safeTitle-${System.currentTimeMillis()}.mp4"
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            publishScoped(source, fileName)
        } else {
            publishLegacy(source, fileName)
        }
    }

    private fun publishScoped(source: File, fileName: String): Uri {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/Kolbo Studio")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val uri = requireNotNull(resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)) {
            "לא ניתן ליצור קובץ בגלריה"
        }
        try {
            val copied = resolver.openOutputStream(uri, "w").use { output ->
                requireNotNull(output) { "לא ניתן לפתוח יעד בגלריה" }
                FileInputStream(source).use { input -> input.copyTo(output, DEFAULT_BUFFER_SIZE) }
            }
            check(copied == source.length()) { "העתקת הסרטון לגלריה לא הושלמה במלואה" }
            val done = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
            resolver.update(uri, done, null, null)
            return uri
        } catch (error: Throwable) {
            runCatching { resolver.delete(uri, null, null) }
            throw error
        }
    }

    @Suppress("DEPRECATION")
    private fun publishLegacy(source: File, fileName: String): Uri {
        check(ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
            "STORAGE_PERMISSION_REQUIRED"
        }
        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "Kolbo Studio").apply { mkdirs() }
        val target = File(dir, fileName)
        try {
            FileInputStream(source).use { input ->
                FileOutputStream(target).use { output ->
                    input.copyTo(output, DEFAULT_BUFFER_SIZE)
                    output.fd.sync()
                }
            }
            check(target.length() == source.length()) { "העתקת הסרטון לגלריה לא הושלמה במלואה" }
        } catch (error: Throwable) {
            runCatching { target.delete() }
            throw error
        }
        var scanned: Uri? = null
        val latch = CountDownLatch(1)
        MediaScannerConnection.scanFile(context, arrayOf(target.absolutePath), arrayOf("video/mp4")) { _, uri ->
            scanned = uri
            latch.countDown()
        }
        latch.await(3, TimeUnit.SECONDS)
        return scanned ?: Uri.fromFile(target)
    }
}
