package com.kolbomusic.singstudio.core.device

import android.content.Context
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.os.StatFs

class RuntimeHealthProbe(private val context: Context) {
    fun snapshot(): RuntimeHealthState {
        val power = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        val battery = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val freeBytes = runCatching { StatFs(context.filesDir.absolutePath).availableBytes }.getOrDefault(0L)
        val batteryPercent = runCatching { battery.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) }
            .getOrNull()
            ?.takeIf { it in 0..100 }
        val thermal = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            when (power.currentThermalStatus) {
                PowerManager.THERMAL_STATUS_NONE, PowerManager.THERMAL_STATUS_LIGHT -> ThermalLevel.Normal
                PowerManager.THERMAL_STATUS_MODERATE -> ThermalLevel.Warm
                PowerManager.THERMAL_STATUS_SEVERE,
                PowerManager.THERMAL_STATUS_CRITICAL,
                PowerManager.THERMAL_STATUS_EMERGENCY,
                PowerManager.THERMAL_STATUS_SHUTDOWN -> ThermalLevel.Severe
                else -> ThermalLevel.Unknown
            }
        } else ThermalLevel.Unknown
        return RuntimeHealthState(
            batteryPercent = batteryPercent,
            powerSaveMode = power.isPowerSaveMode,
            thermalLevel = thermal,
            freeStorageBytes = freeBytes,
            checkedAtEpochMs = System.currentTimeMillis()
        )
    }
}
