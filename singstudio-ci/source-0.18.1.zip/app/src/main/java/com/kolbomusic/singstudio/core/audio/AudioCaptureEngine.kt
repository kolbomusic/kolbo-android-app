package com.kolbomusic.singstudio.core.audio

import com.kolbomusic.singstudio.core.model.CameraSyncMarker
import com.kolbomusic.singstudio.core.model.PlaybackSyncMarker
import com.kolbomusic.singstudio.core.model.RecordingState
import com.kolbomusic.singstudio.core.model.VisualScene
import kotlinx.coroutines.flow.StateFlow
import java.io.File

interface AudioCaptureEngine {
    val state: StateFlow<RecordingState>
    suspend fun start(): Result<Unit>
    suspend fun stop(): Result<File>
    fun configureVisualScene(scene: VisualScene)
    fun markPlaybackStarted(marker: PlaybackSyncMarker)
    fun markCameraStarted(marker: CameraSyncMarker)
    fun resetSavedState()
    fun restoreSavedTake(rawFilePath: String, playbackStartOffsetMs: Long?, cameraStartOffsetMs: Long?, cameraFilePath: String?): Result<Unit>
}
