package com.kolbomusic.singstudio.core.export

import com.kolbomusic.singstudio.core.editor.TitleOverlay
import com.kolbomusic.singstudio.core.model.OutputAspectRatio

object ExportPlanBuilder {
    fun build(
        takeId: String,
        sessionDurationMs: Long,
        aspectRatio: OutputAspectRatio,
        settings: ExportSettings,
        title: TitleOverlay,
        playbackStartOffsetMs: Long?,
        cameraStartOffsetMs: Long?,
        hasCamera: Boolean
    ): ExportPlan {
        require(sessionDurationMs > 0L) { "Session duration must be positive" }
        val safe = settings.sanitized(sessionDurationMs)
        val duration = safe.trimEndMs - safe.trimStartMs
        require(duration >= 1L) { "Export duration is empty" }

        val camera = if (hasCamera) {
            val playbackOffset = requireNotNull(playbackStartOffsetMs) { "Missing playback sync marker" }
            val cameraOffset = requireNotNull(cameraStartOffsetMs) { "Missing camera sync marker" }
            val mediaAtOutputStart = playbackOffset + safe.trimStartMs - cameraOffset
            val gap = (-mediaAtOutputStart).coerceAtLeast(0L)
            val clipStart = mediaAtOutputStart.coerceAtLeast(0L)
            val visibleDuration = (duration - gap).coerceAtLeast(1L)
            CameraTimelinePlan(
                clipStartMs = clipStart,
                clipEndMs = clipStart + visibleDuration,
                gapBeforeMs = gap
            )
        } else null

        val cleanTitle = title.sanitized()
        val titleStart = (cleanTitle.startMs - safe.trimStartMs).coerceAtLeast(0L)
        val titleEnd = (cleanTitle.endMs - safe.trimStartMs).coerceIn(0L, duration)
        val visible = cleanTitle.text.isNotBlank() && cleanTitle.endMs > safe.trimStartMs && cleanTitle.startMs < safe.trimEndMs && titleEnd > titleStart

        return ExportPlan(
            takeId = takeId,
            sourceDurationMs = sessionDurationMs,
            outputDurationMs = duration,
            trimStartMs = safe.trimStartMs,
            trimEndMs = safe.trimEndMs,
            dimensions = safe.dimensions(aspectRatio),
            settings = safe,
            camera = camera,
            adjustedTitleStartMs = titleStart,
            adjustedTitleEndMs = titleEnd,
            titleVisible = visible
        )
    }
}
