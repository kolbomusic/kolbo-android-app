package com.kolbomusic.singstudio.core.export

import android.media.MediaMetadataRetriever
import com.kolbomusic.singstudio.core.audio.WavFileTools
import java.io.File
import kotlin.math.abs

object ExportVerifier {
    fun verify(file: File, plan: ExportPlan): ExportVerification {
        if (!file.isFile || file.length() < 1024L) {
            return ExportVerification(valid = false, errorMessage = "קובץ הייצוא חסר או ריק")
        }
        return runCatching {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(file.absolutePath)
                val duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                val width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
                val height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
                val rotation = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                val hasVideo = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_VIDEO) == "yes"
                val hasAudio = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO) == "yes"
                val durationTolerance = maxOf(850L, (plan.outputDurationMs * 0.025).toLong())
                val rotated = rotation == 90 || rotation == 270
                val displayWidth = if (rotated) height else width
                val displayHeight = if (rotated) width else height
                val dimensionsMatch = displayWidth == plan.dimensions.width && displayHeight == plan.dimensions.height
                val durationMatches = duration > 0L && abs(duration - plan.outputDurationMs) <= durationTolerance
                val valid = hasVideo && hasAudio && dimensionsMatch && durationMatches
                ExportVerification(
                    valid = valid,
                    durationMs = duration,
                    width = displayWidth,
                    height = displayHeight,
                    rotationDegrees = rotation,
                    hasVideo = hasVideo,
                    hasAudio = hasAudio,
                    fileSizeBytes = file.length(),
                    sha256 = WavFileTools.sha256(file),
                    errorMessage = if (valid) null else buildString {
                        append("אימות MP4 נכשל:")
                        if (!hasVideo) append(" אין וידאו;")
                        if (!hasAudio) append(" אין אודיו;")
                        if (!dimensionsMatch) append(" מידות תצוגה $displayWidth×$displayHeight (rotation=$rotation) במקום ${plan.dimensions.width}×${plan.dimensions.height};")
                        if (!durationMatches) append(" משך ${duration}ms במקום ~${plan.outputDurationMs}ms;")
                    }
                )
            } finally {
                retriever.release()
            }
        }.getOrElse { error ->
            ExportVerification(valid = false, fileSizeBytes = file.length(), errorMessage = error.message ?: "לא ניתן לאמת את קובץ ה־MP4")
        }
    }
}
