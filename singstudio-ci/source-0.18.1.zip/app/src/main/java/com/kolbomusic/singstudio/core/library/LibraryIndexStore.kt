package com.kolbomusic.singstudio.core.library

import android.content.Context
import android.util.AtomicFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class LibraryIndexStore(context: Context) {
    private val directory = File(context.filesDir, "library").also { it.mkdirs() }
    private val atomicFile = AtomicFile(File(directory, "library-index.json"))
    private val lock = Any()

    fun load(): List<LibraryItem> = synchronized(lock) {
        val bytes = runCatching { atomicFile.openRead().use { it.readBytes() } }.getOrNull() ?: return@synchronized emptyList()
        val root = runCatching { JSONObject(bytes.toString(Charsets.UTF_8)) }.getOrNull() ?: return@synchronized emptyList()
        val array = root.optJSONArray("items") ?: JSONArray()
        buildList {
            for (index in 0 until array.length()) {
                val json = array.optJSONObject(index) ?: continue
                runCatching { add(json.toLibraryItem()) }
            }
        }
    }

    fun save(items: List<LibraryItem>) = synchronized(lock) {
        val root = JSONObject()
            .put("schema", 1)
            .put("engineVersion", "0.10.0")
            .put("items", JSONArray().apply { items.forEach { put(it.toJson()) } })
        val output = atomicFile.startWrite()
        try {
            output.write(root.toString(2).toByteArray(Charsets.UTF_8))
            output.flush()
            atomicFile.finishWrite(output)
        } catch (error: Throwable) {
            atomicFile.failWrite(output)
            throw error
        }
    }

    private fun LibraryItem.toJson(): JSONObject = JSONObject()
        .put("id", id)
        .put("takeId", takeId)
        .put("title", title)
        .put("createdAtEpochMs", createdAtEpochMs)
        .put("updatedAtEpochMs", updatedAtEpochMs)
        .put("status", status.name)
        .put("favorite", favorite)
        .put("rawVocalPath", rawVocalPath)
        .put("projectPath", projectPath)
        .put("exportPath", exportPath)
        .put("galleryUri", galleryUri)
        .put("thumbnailPath", thumbnailPath)
        .put("durationMs", durationMs)
        .put("fileSizeBytes", fileSizeBytes)
        .put("sha256", sha256)
        .put("aspectRatio", aspectRatio)
        .put("sourceTitle", sourceTitle)

    private fun JSONObject.toLibraryItem(): LibraryItem = LibraryItem(
        id = getString("id"),
        takeId = optString("takeId", getString("id")),
        title = optString("title", "ביצוע ללא שם").ifBlank { "ביצוע ללא שם" },
        createdAtEpochMs = optLong("createdAtEpochMs", 0L),
        updatedAtEpochMs = optLong("updatedAtEpochMs", optLong("createdAtEpochMs", 0L)),
        status = runCatching { LibraryItemStatus.valueOf(optString("status", LibraryItemStatus.Draft.name)) }
            .getOrDefault(LibraryItemStatus.Draft),
        favorite = optBoolean("favorite", false),
        rawVocalPath = optNullableString("rawVocalPath"),
        projectPath = optNullableString("projectPath"),
        exportPath = optNullableString("exportPath"),
        galleryUri = optNullableString("galleryUri"),
        thumbnailPath = optNullableString("thumbnailPath"),
        durationMs = optLong("durationMs", 0L),
        fileSizeBytes = optLong("fileSizeBytes", 0L),
        sha256 = optNullableString("sha256"),
        aspectRatio = optNullableString("aspectRatio"),
        sourceTitle = optNullableString("sourceTitle")
    )

    private fun JSONObject.optNullableString(key: String): String? {
        if (!has(key) || isNull(key)) return null
        return optString(key).takeIf { it.isNotBlank() && it != "null" }
    }
}
