package com.kolbomusic.singstudio.core.dsp

import kotlin.math.roundToInt

enum class PreviewSource(val labelHe: String) {
    Raw("A · לפני"),
    Processed("B · אחרי")
}

enum class BeatDivision(val labelHe: String, val beats: Double) {
    Quarter("1/4", 1.0),
    Eighth("1/8", 0.5),
    DottedEighth("1/8.", 0.75),
    Sixteenth("1/16", 0.25)
}

enum class TempoSource(val labelHe: String) {
    Unknown("ללא קצב"),
    Automatic("זוהה אוטומטית"),
    Tap("Tap Tempo")
}

data class BpmEstimate(
    val bpm: Double,
    val confidence: Double
)

data class VocalFxSettings(
    val enabled: Boolean = true,
    val reverbMix: Float = 0.20f,
    val reverbRoom: Float = 0.68f,
    val delayMix: Float = 0.10f,
    val delayFeedback: Float = 0.28f,
    val delayMs: Float = 280f,
    val delayDivision: BeatDivision = BeatDivision.DottedEighth,
    val outputGainDb: Float = 0f
) {
    fun sanitized(): VocalFxSettings = copy(
        reverbMix = reverbMix.coerceIn(0f, 0.65f),
        reverbRoom = reverbRoom.coerceIn(0.15f, 0.92f),
        delayMix = delayMix.coerceIn(0f, 0.55f),
        delayFeedback = delayFeedback.coerceIn(0f, 0.72f),
        delayMs = delayMs.coerceIn(35f, 1_200f),
        outputGainDb = outputGainDb.coerceIn(-12f, 6f)
    )
}

data class VocalEditorState(
    val prepared: Boolean = false,
    val playing: Boolean = false,
    val previewSource: PreviewSource = PreviewSource.Processed,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val settings: VocalFxSettings = VocalFxSettings(),
    val bpm: Double? = null,
    val bpmConfidence: Double = 0.0,
    val tempoSource: TempoSource = TempoSource.Unknown,
    val tempoAnalysing: Boolean = false,
    val advancedOpen: Boolean = false,
    val manuallyEdited: Boolean = false,
    val rendering: Boolean = false,
    val renderProgress: Float = 0f,
    val renderedFilePath: String? = null,
    val renderedSha256: String? = null,
    val errorMessage: String? = null
)

object TempoSync {
    fun delayMs(bpm: Double, division: BeatDivision): Float {
        if (!bpm.isFinite() || bpm <= 0.0) return 280f
        return ((60_000.0 / bpm) * division.beats)
            .coerceIn(35.0, 1_200.0)
            .toFloat()
    }

    fun label(bpm: Double?, division: BeatDivision, delayMs: Float): String {
        return if (bpm != null) {
            "${division.labelHe} · ${delayMs.roundToInt()}ms · ${bpm.roundToInt()} BPM"
        } else {
            "${delayMs.roundToInt()}ms"
        }
    }
}

object SmartFxAdvisor {
    fun recommend(preset: VocalPresetId, bpm: Double?): VocalFxSettings {
        val base = when (preset) {
            VocalPresetId.Ballad -> VocalFxSettings(
                reverbMix = 0.22f,
                reverbRoom = 0.80f,
                delayMix = 0.09f,
                delayFeedback = 0.30f,
                delayDivision = BeatDivision.Quarter
            )
            VocalPresetId.Mizrahi -> VocalFxSettings(
                reverbMix = 0.15f,
                reverbRoom = 0.74f,
                delayMix = 0.09f,
                delayFeedback = 0.24f,
                delayDivision = BeatDivision.DottedEighth
            )
            VocalPresetId.Pop -> VocalFxSettings(
                reverbMix = 0.14f,
                reverbRoom = 0.62f,
                delayMix = 0.07f,
                delayFeedback = 0.27f,
                delayDivision = BeatDivision.Eighth
            )
            VocalPresetId.Live -> VocalFxSettings(
                reverbMix = 0.18f,
                reverbRoom = 0.76f,
                delayMix = 0.03f,
                delayFeedback = 0.22f,
                delayDivision = BeatDivision.Eighth
            )
            VocalPresetId.Dry -> VocalFxSettings(
                reverbMix = 0.04f,
                reverbRoom = 0.45f,
                delayMix = 0.0f,
                delayFeedback = 0.0f,
                delayDivision = BeatDivision.Eighth
            )
            VocalPresetId.Natural -> VocalFxSettings(
                reverbMix = 0.10f,
                reverbRoom = 0.58f,
                delayMix = 0.03f,
                delayFeedback = 0.18f,
                delayDivision = BeatDivision.Eighth
            )
            VocalPresetId.Studio, VocalPresetId.Auto -> VocalFxSettings(
                reverbMix = 0.15f,
                reverbRoom = 0.68f,
                delayMix = 0.06f,
                delayFeedback = 0.22f,
                delayDivision = BeatDivision.DottedEighth
            )
        }
        return bpm?.let { base.copy(delayMs = TempoSync.delayMs(it, base.delayDivision)) } ?: base
    }
}
