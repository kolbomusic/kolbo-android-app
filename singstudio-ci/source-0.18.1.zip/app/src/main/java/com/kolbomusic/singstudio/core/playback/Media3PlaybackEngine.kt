package com.kolbomusic.singstudio.core.playback

import android.content.Context
import android.net.Uri
import android.os.SystemClock
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.kolbomusic.singstudio.core.model.PlaybackState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class Media3PlaybackEngine(
    context: Context,
    uri: Uri
) : PlaybackControl {

    val player: ExoPlayer = ExoPlayer.Builder(context.applicationContext).build()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val _state = MutableStateFlow(PlaybackState())
    override val state: StateFlow<PlaybackState> = _state.asStateFlow()
    private var ticker: Job? = null
    private var released = false

    init {
        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                publishState(
                    prepared = playbackState == Player.STATE_READY || playbackState == Player.STATE_ENDED,
                    buffering = playbackState == Player.STATE_BUFFERING,
                    ended = playbackState == Player.STATE_ENDED
                )
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                val newStart = if (isPlaying && !_state.value.playing) {
                    SystemClock.elapsedRealtimeNanos()
                } else {
                    _state.value.startedElapsedRealtimeNs
                }
                _state.value = _state.value.copy(
                    playing = isPlaying,
                    startedElapsedRealtimeNs = newStart,
                    positionMs = player.currentPosition.coerceAtLeast(0L),
                    durationMs = player.duration.takeIf { it > 0L } ?: _state.value.durationMs
                )
            }

            override fun onPlayerError(error: PlaybackException) {
                _state.value = _state.value.copy(
                    playing = false,
                    buffering = false,
                    errorMessage = error.message ?: "ניגון הפלייבק נכשל"
                )
            }
        })

        player.setMediaItem(MediaItem.fromUri(uri))
        player.prepare()
        ticker = scope.launch {
            while (isActive) {
                if (!released) {
                    _state.value = _state.value.copy(
                        positionMs = player.currentPosition.coerceAtLeast(0L),
                        durationMs = player.duration.takeIf { it > 0L } ?: _state.value.durationMs
                    )
                }
                delay(100L)
            }
        }
    }

    override fun playFromStart() {
        if (released) return
        _state.value = _state.value.copy(ended = false, errorMessage = null)
        player.seekTo(0L)
        player.playWhenReady = true
    }

    override fun pause() {
        if (!released) player.pause()
    }

    override fun seekTo(positionMs: Long) {
        if (!released) player.seekTo(positionMs.coerceAtLeast(0L))
    }

    override fun release() {
        if (released) return
        released = true
        ticker?.cancel()
        player.release()
        scope.cancel()
    }

    private fun publishState(
        prepared: Boolean = _state.value.prepared,
        buffering: Boolean = _state.value.buffering,
        ended: Boolean = _state.value.ended
    ) {
        _state.value = _state.value.copy(
            prepared = prepared,
            buffering = buffering,
            ended = ended,
            positionMs = player.currentPosition.coerceAtLeast(0L),
            durationMs = player.duration.takeIf { it > 0L } ?: _state.value.durationMs
        )
    }
}
