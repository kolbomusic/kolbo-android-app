package com.kolbomusic.singstudio.core.mix

import com.kolbomusic.singstudio.core.model.PlaybackSource
import com.kolbomusic.singstudio.core.model.PlaybackSourceType
import java.io.File

/**
 * YouTube audio and video are NOT copied, decoded or included in this output.
 * Silence supplies a deterministic, local, authorized timeline for vocal/camera
 * processing. Created once per saved take using a small, fixed memory buffer.
 */
object VoiceOnlyBacking {
    fun prepare(rawVocalWav: File, playbackStartOffsetMs: Long = 0L): Pair<File, PlaybackSource> {
        require(rawVocalWav.isFile) { "הקלטת הקול אינה זמינה" }
        val safeOffsetMs = playbackStartOffsetMs.coerceAtLeast(0L)
        val output = File(rawVocalWav.parentFile, rawVocalWav.nameWithoutExtension + "-voice-only-" + safeOffsetMs + "ms.wav")
        Pcm16InterleavedWavReader(rawVocalWav).use { reader ->
            val rate = reader.sampleRate
            val elapsedFrames = safeOffsetMs * rate.toLong() / 1000L
            val frameCount = reader.frameCount - elapsedFrames
            require(frameCount > 0L) { "לא הוקלט קול לאחר תחילת השיר" }
            // Regenerate every time. Equal length is not proof of identical source
            // or silence (especially if an earlier job was interrupted).
            require(frameCount * 2L < 0xFFFF_F000L) { "הקלטה ארוכה מדי ל-WAV יחיד" }
            Pcm16InterleavedWavWriter(output, rate, 1).use { writer ->
                val zeros = FloatArray(4096)
                var framesLeft = frameCount
                while (framesLeft > 0L) {
                    val frames = minOf(zeros.size.toLong(), framesLeft).toInt()
                    writer.writeInterleaved(zeros, 0, frames)
                    framesLeft -= frames
                }
                writer.commit()
            }
        }
        return output to PlaybackSource(
            id = "kolbo-voice-only:${rawVocalWav.nameWithoutExtension}:${safeOffsetMs}ms",
            type = PlaybackSourceType.LocalAudio,
            title = "קול מוקלט ללא מוזיקת YouTube",
            uriString = output.toURI().toString(),
            mimeType = "audio/wav"
        )
    }
}
