package com.kolbomusic.singstudio.core.export

import com.kolbomusic.singstudio.core.model.OutputAspectRatio

enum class ExportResolution(val labelHe: String, val shortSide: Int) {
    HD720("720p", 720),
    FullHD1080("1080p", 1080)
}

enum class ExportVideoCodec(val labelHe: String) {
    H264("H.264 – תאימות מרבית"),
    HEVC("HEVC – קובץ קטן יותר")
}

enum class ExportPhase {
    Idle,
    Preparing,
    Exporting,
    Verifying,
    Completed,
    Cancelled,
    Failed
}

data class ExportSettings(
    val resolution: ExportResolution = ExportResolution.FullHD1080,
    val codec: ExportVideoCodec = ExportVideoCodec.H264,
    val frameRate: Int = 30,
    val allowCodecFallback: Boolean = true,
    val trimStartMs: Long = 0L,
    val trimEndMs: Long = 0L
) {
    fun sanitized(durationMs: Long): ExportSettings {
        val safeDuration = durationMs.coerceAtLeast(1L)
        val start = trimStartMs.coerceIn(0L, (safeDuration - 1L).coerceAtLeast(0L))
        val requestedEnd = if (trimEndMs <= 0L) safeDuration else trimEndMs
        val end = requestedEnd.coerceIn(start + 1L, safeDuration)
        return copy(
            frameRate = frameRate.coerceIn(24, 60),
            trimStartMs = start,
            trimEndMs = end
        )
    }

    fun dimensions(aspectRatio: OutputAspectRatio): ExportDimensions {
        val s = resolution.shortSide
        return when (aspectRatio) {
            OutputAspectRatio.Portrait9x16 -> ExportDimensions(s, s * 16 / 9)
            OutputAspectRatio.Landscape16x9 -> ExportDimensions(s * 16 / 9, s)
            OutputAspectRatio.Square1x1 -> ExportDimensions(s, s)
        }.even()
    }
}

data class ExportDimensions(val width: Int, val height: Int) {
    fun even(): ExportDimensions = ExportDimensions(
        width = if (width % 2 == 0) width else width - 1,
        height = if (height % 2 == 0) height else height - 1
    )
}

data class CameraTimelinePlan(
    val clipStartMs: Long,
    val clipEndMs: Long,
    val gapBeforeMs: Long
)

data class ExportPlan(
    val takeId: String,
    val sourceDurationMs: Long,
    val outputDurationMs: Long,
    val trimStartMs: Long,
    val trimEndMs: Long,
    val dimensions: ExportDimensions,
    val settings: ExportSettings,
    val camera: CameraTimelinePlan?,
    val adjustedTitleStartMs: Long,
    val adjustedTitleEndMs: Long,
    val titleVisible: Boolean
)

data class ExportVerification(
    val valid: Boolean,
    val durationMs: Long = 0L,
    val width: Int = 0,
    val height: Int = 0,
    val rotationDegrees: Int = 0,
    val hasVideo: Boolean = false,
    val hasAudio: Boolean = false,
    val fileSizeBytes: Long = 0L,
    val sha256: String? = null,
    val errorMessage: String? = null
)

data class ExportState(
    val phase: ExportPhase = ExportPhase.Idle,
    val progressPercent: Int = 0,
    val requestedCodec: ExportVideoCodec = ExportVideoCodec.H264,
    val effectiveCodec: ExportVideoCodec = ExportVideoCodec.H264,
    val codecFallbackApplied: Boolean = false,
    val outputPath: String? = null,
    val outputSha256: String? = null,
    val verification: ExportVerification? = null,
    val message: String? = null,
    val errorMessage: String? = null
) {
    val running: Boolean get() = phase == ExportPhase.Preparing || phase == ExportPhase.Exporting || phase == ExportPhase.Verifying
}

data class CompositionPreviewState(
    val preparing: Boolean = false,
    val ready: Boolean = false,
    val playing: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val multipleVideoInputs: Boolean = false,
    val message: String? = null,
    val errorMessage: String? = null
)
