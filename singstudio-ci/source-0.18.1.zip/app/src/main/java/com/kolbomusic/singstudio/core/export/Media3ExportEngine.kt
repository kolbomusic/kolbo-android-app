@file:androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)

package com.kolbomusic.singstudio.core.export

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.media3.common.MimeTypes
import androidx.media3.transformer.Composition
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.kolbomusic.singstudio.core.audio.WavFileTools
import com.kolbomusic.singstudio.core.model.VisualScene
import com.kolbomusic.singstudio.core.model.PlaybackSource
import com.kolbomusic.singstudio.core.editor.VideoProjectState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.isActive
import java.io.File

class Media3ExportEngine(private val context: Context) {
    private val mainHandler = Handler(Looper.getMainLooper())
    private val verifyScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _state = MutableStateFlow(ExportState())
    val state: StateFlow<ExportState> = _state.asStateFlow()

    private var transformer: Transformer? = null
    private var prepareJob: Job? = null
    private var activePlan: ExportPlan? = null
    private var prepared: CompositionFactory.PreparedComposition? = null
    private var partialFile: File? = null
    private var finalFile: File? = null
    private var checkpointFile: File? = null
    private var currentCodec = ExportVideoCodec.H264
    private var retryingCodecFallback = false

    fun start(
        plan: ExportPlan,
        scene: VisualScene,
        project: VideoProjectState,
        playbackSource: PlaybackSource?,
        sessionMixFile: File,
        sessionMixExpectedSha256: String?,
        cameraFile: File?,
        outputDirectory: File
    ) {
        check(Looper.myLooper() == Looper.getMainLooper()) { "Export engine must start on the main thread" }
        if (_state.value.running) return
        outputDirectory.mkdirs()
        val work = File(outputDirectory, "work").apply { mkdirs() }
        val checkpoint = File(outputDirectory, "export-checkpoint.json")
        val interruptedPartial = ExportCheckpointStore.stalePartialPath(checkpoint)?.let(::File)
        val interruptedDetected = interruptedPartial?.exists() == true
        interruptedPartial?.delete()
        ExportCheckpointStore.clear(checkpoint)

        val exportId = System.currentTimeMillis()
        val final = File(
            outputDirectory,
            "${plan.takeId}-${plan.dimensions.width}x${plan.dimensions.height}-$exportId.mp4"
        )
        val partial = File(outputDirectory, "${final.nameWithoutExtension}.exporting.mp4")
        partial.delete()

        activePlan = plan
        finalFile = final
        partialFile = partial
        checkpointFile = checkpoint
        currentCodec = plan.settings.codec
        retryingCodecFallback = false
        _state.value = ExportState(
            phase = ExportPhase.Preparing,
            requestedCodec = plan.settings.codec,
            effectiveCodec = currentCodec,
            message = if (interruptedDetected) "נמצא ייצוא קודם שנקטע — נוקה בבטחה ומתחיל מחדש…" else "מכין את שכבות הסרטון…"
        )

        prepareJob?.cancel()
        prepareJob = verifyScope.launch {
            val result = runCatching {
                checkExportStorage(outputDirectory, plan)
                if (!sessionMixExpectedSha256.isNullOrBlank()) {
                    val actualMixSha = WavFileTools.sha256(sessionMixFile)
                    require(actualMixSha.equals(sessionMixExpectedSha256, ignoreCase = true)) {
                        "Session Mix השתנה מאז הרינדור. נדרש לרנדר אותו מחדש לפני ייצוא."
                    }
                }
                CompositionFactory(context).build(plan, scene, project, playbackSource, sessionMixFile, cameraFile, work)
            }
            if (!isActive) return@launch
            mainHandler.post {
                if (_state.value.phase != ExportPhase.Preparing) return@post
                result.onSuccess { preparedResult ->
                    prepared = preparedResult
                    ExportCheckpointStore.write(checkpoint, plan, partial, currentCodec, ExportPhase.Exporting)
                    startTransformer(preparedResult.composition, currentCodec)
                }.onFailure { error -> fail(error.message ?: "בניית הקומפוזיציה נכשלה") }
            }
        }
    }

    fun cancel() {
        if (!_state.value.running) return
        prepareJob?.cancel()
        prepareJob = null
        transformer?.cancel()
        transformer = null
        stopProgressPolling()
        partialFile?.delete()
        checkpointFile?.let(ExportCheckpointStore::clear)
        _state.value = _state.value.copy(
            phase = ExportPhase.Cancelled,
            progressPercent = 0,
            message = "הייצוא בוטל בבטחה",
            errorMessage = null
        )
    }

    fun release() {
        prepareJob?.cancel()
        prepareJob = null
        runCatching { transformer?.cancel() }
        stopProgressPolling()
        transformer = null
        verifyScope.cancel()
    }

    private fun startTransformer(composition: Composition, codec: ExportVideoCodec) {
        val partial = requireNotNull(partialFile)
        partial.delete()
        currentCodec = codec
        _state.value = _state.value.copy(
            phase = ExportPhase.Exporting,
            progressPercent = 0,
            effectiveCodec = codec,
            message = if (retryingCodecFallback) "HEVC לא זמין — ממשיך אוטומטית ב־H.264" else "מייצא את הסרטון…",
            errorMessage = null
        )
        val listener = object : Transformer.Listener {
            override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                stopProgressPolling()
                transformer = null
                verifyExport()
            }

            override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                stopProgressPolling()
                transformer = null
                val plan = activePlan
                if (
                    plan != null && currentCodec == ExportVideoCodec.HEVC &&
                    plan.settings.allowCodecFallback && !retryingCodecFallback
                ) {
                    retryingCodecFallback = true
                    partial.delete()
                    _state.value = _state.value.copy(codecFallbackApplied = true)
                    checkpointFile?.let { ExportCheckpointStore.write(it, plan, partial, ExportVideoCodec.H264, ExportPhase.Exporting) }
                    mainHandler.post { startTransformer(composition, ExportVideoCodec.H264) }
                } else {
                    partial.delete()
                    fail(exportException.message ?: "Media3 Transformer נכשל")
                }
            }

            override fun onFallbackApplied(
                composition: Composition,
                originalTransformationRequest: androidx.media3.transformer.TransformationRequest,
                fallbackTransformationRequest: androidx.media3.transformer.TransformationRequest
            ) {
                _state.value = _state.value.copy(
                    codecFallbackApplied = true,
                    message = "המכשיר בחר קידוד תואם חלופי כדי להשלים את הייצוא"
                )
            }
        }
        val videoMime = if (codec == ExportVideoCodec.HEVC) MimeTypes.VIDEO_H265 else MimeTypes.VIDEO_H264
        transformer = Transformer.Builder(context)
            .setVideoMimeType(videoMime)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .setPortraitEncodingEnabled(false)
            .addListener(listener)
            .build()
        transformer!!.start(composition, partial.absolutePath)
        pollProgress()
    }

    private fun verifyExport() {
        val plan = activePlan ?: return fail("Export plan missing")
        val partial = partialFile ?: return fail("Partial output missing")
        val final = finalFile ?: return fail("Final output missing")
        _state.value = _state.value.copy(phase = ExportPhase.Verifying, progressPercent = 100, message = "בודק שהסרטון תקין…")
        verifyScope.launch {
            val verification = ExportVerifier.verify(partial, plan)
            mainHandler.post {
                if (!verification.valid) {
                    partial.delete()
                    fail(verification.errorMessage ?: "בדיקת הסרטון נכשלה")
                    return@post
                }
                if (!partial.renameTo(final)) {
                    partial.copyTo(final, overwrite = true)
                    partial.delete()
                }
                val finalVerification = verification.copy(fileSizeBytes = final.length())
                runCatching {
                    ExportMetadataStore.write(
                        outputFile = final,
                        plan = plan,
                        verification = finalVerification,
                        requestedCodec = plan.settings.codec,
                        effectiveCodec = currentCodec,
                        fallbackApplied = _state.value.codecFallbackApplied
                    )
                }
                checkpointFile?.let(ExportCheckpointStore::clear)
                _state.value = _state.value.copy(
                    phase = ExportPhase.Completed,
                    progressPercent = 100,
                    outputPath = final.absolutePath,
                    outputSha256 = finalVerification.sha256,
                    verification = finalVerification,
                    message = "הסרטון מוכן",
                    errorMessage = null
                )
            }
        }
    }

    private val progressRunnable = object : Runnable {
        override fun run() {
            val current = transformer ?: return
            val holder = ProgressHolder()
            val progressState = runCatching { current.getProgress(holder) }.getOrNull()
            if (progressState == Transformer.PROGRESS_STATE_AVAILABLE) {
                _state.value = _state.value.copy(progressPercent = holder.progress.coerceIn(0, 99))
            }
            if (_state.value.phase == ExportPhase.Exporting) mainHandler.postDelayed(this, 350L)
        }
    }

    private fun pollProgress() {
        stopProgressPolling()
        mainHandler.post(progressRunnable)
    }

    private fun stopProgressPolling() {
        mainHandler.removeCallbacks(progressRunnable)
    }

    private fun checkExportStorage(outputDirectory: File, plan: ExportPlan) {
        val bytesPerSecond = when (plan.settings.resolution) {
            ExportResolution.HD720 -> 1_250_000L
            ExportResolution.FullHD1080 -> 2_250_000L
        }
        val estimatedPayload = ((plan.outputDurationMs + 999L) / 1000L) * bytesPerSecond
        val safetyReserve = 192L * 1024L * 1024L
        val required = estimatedPayload + safetyReserve
        require(outputDirectory.usableSpace >= required) {
            "אין מספיק מקום פנוי לייצוא. נדרשים לפחות ${required / (1024L * 1024L)}MB פנויים."
        }
    }

    private fun fail(message: String) {
        stopProgressPolling()
        checkpointFile?.let { file ->
            val plan = activePlan
            val partial = partialFile
            if (plan != null && partial != null) ExportCheckpointStore.write(file, plan, partial, currentCodec, ExportPhase.Failed)
        }
        _state.value = _state.value.copy(
            phase = ExportPhase.Failed,
            message = null,
            errorMessage = message
        )
    }
}
