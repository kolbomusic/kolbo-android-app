package com.kolbomusic.singstudio.ui.library

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.kolbomusic.singstudio.core.delivery.MediaStorePublisher
import com.kolbomusic.singstudio.core.library.LibraryFilter
import com.kolbomusic.singstudio.core.library.LibraryRepository
import com.kolbomusic.singstudio.core.library.LibraryState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class LibraryViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = LibraryRepository(application)
    private val publisher = MediaStorePublisher(application)
    private val _state = MutableStateFlow(LibraryState())
    val state: StateFlow<LibraryState> = _state.asStateFlow()

    init { refresh() }

    fun refresh() {
        viewModelScope.launch(Dispatchers.IO) {
            val items = repository.load()
            _state.value = _state.value.copy(loading = false, items = items, errorMessage = null)
        }
    }

    fun setFilter(filter: LibraryFilter) { _state.value = _state.value.copy(filter = filter) }
    fun setSearch(query: String) { _state.value = _state.value.copy(searchQuery = query.take(80)) }
    fun clearMessage() { _state.value = _state.value.copy(message = null, errorMessage = null) }

    fun rename(id: String, title: String) = mutate { repository.rename(id, title) }
    fun toggleFavorite(id: String) = mutate {
        val item = repository.find(id) ?: return@mutate null
        repository.setFavorite(id, !item.favorite)
    }

    fun deletePrivate(id: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val ok = repository.deletePrivateProject(id)
            val items = repository.load()
            _state.value = _state.value.copy(
                loading = false,
                items = items,
                message = if (ok) "היצירה הוסרה מהמכשיר. קובץ שכבר נשמר בגלריה לא נמחק." else null,
                errorMessage = if (!ok) "לא נמצאה יצירה למחיקה" else null
            )
        }
    }

    fun publishToGallery(id: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val item = repository.find(id)
            val export = item?.exportPath?.let(::File)
            if (item == null || export == null || !export.isFile) {
                _state.value = _state.value.copy(errorMessage = "ליצירה הזו עדיין אין סרטון מוכן")
                return@launch
            }
            runCatching { publisher.publishVideo(export, item.title) }
                .onSuccess { uri ->
                    repository.setGalleryUri(id, uri.toString())
                    _state.value = _state.value.copy(
                        items = repository.load(),
                        message = "הסרטון נשמר בגלריה ✓",
                        errorMessage = null
                    )
                }
                .onFailure { error ->
                    _state.value = _state.value.copy(errorMessage = error.message ?: "השמירה לגלריה נכשלה")
                }
        }
    }

    private fun mutate(block: suspend () -> Any?) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { block() }
                .onSuccess { _state.value = _state.value.copy(items = repository.load(), errorMessage = null) }
                .onFailure { _state.value = _state.value.copy(errorMessage = it.message ?: "הפעולה נכשלה") }
        }
    }
}
