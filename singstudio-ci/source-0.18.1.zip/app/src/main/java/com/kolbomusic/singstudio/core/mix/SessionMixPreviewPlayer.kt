package com.kolbomusic.singstudio.core.mix

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Process
import com.kolbomusic.singstudio.core.dsp.PreviewSource
import com.kolbomusic.singstudio.core.dsp.RealtimeVocalFxProcessor
import com.kolbomusic.singstudio.core.dsp.VocalFxSettings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.Closeable
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference
import kotlin.concurrent.thread
import kotlin.math.floor
import kotlin.math.max

/**
 * One-clock session preview: backing + aligned vocal are mixed into one AudioTrack.
 * This avoids dual-player drift and keeps A/B switches aligned for the entire song.
 */
class SessionMixPreviewPlayer(
    backingFile: File,
    rawVocalFile: File,
    processedVocalFile: File,
    playbackStartOffsetMs: Long,
    initialMixSettings: SessionMixSettings,
    initialFxSettings: VocalFxSettings
) : Closeable {
    private val backing = Pcm16InterleavedWavReader(backingFile)
    private val raw = try {
        Pcm16InterleavedWavReader(rawVocalFile)
    } catch (error: Throwable) {
        backing.close()
        throw error
    }
    private val processed = try {
        Pcm16InterleavedWavReader(processedVocalFile)
    } catch (error: Throwable) {
        backing.close()
        raw.close()
        throw error
    }
    private val targetRate = backing.sampleRate
    private val rawStart = SessionMixMath.vocalStartFrame(playbackStartOffsetMs, raw.sampleRate)
    private val processedStart = SessionMixMath.vocalStartFrame(playbackStartOffsetMs, processed.sampleRate)
    private val mixSettings = AtomicReference(initialMixSettings.sanitized())
    private val fxSettings = AtomicReference(initialFxSettings.sanitized())
    private val cursor = AtomicLong(0L)
    private val playing = AtomicBoolean(false)
    private val released = AtomicBoolean(false)
    private val fxProcessor = RealtimeVocalFxProcessor(targetRate)
    private val _state = MutableStateFlow(
        SessionMixState(
            available = true,
            prepared = true,
            settings = initialMixSettings.sanitized(),
            durationMs = backing.frameCount * 1000L / targetRate,
            backingCachePath = backingFile.absolutePath
        )
    )
    val state: StateFlow<SessionMixState> = _state.asStateFlow()
    private val worker: Thread

    init {
        try {
            require(raw.channels in 1..2 && processed.channels in 1..2)
            require(rawStart < raw.frameCount) { "סמן הסנכרון נמצא אחרי סוף קובץ ה־RAW" }
            require(processedStart < processed.frameCount) { "סמן הסנכרון נמצא אחרי סוף הקול המעובד" }
        } catch (error: Throwable) {
            closeReaders()
            throw error
        }
        worker = thread(name = "KolboSessionMix", isDaemon = true, start = true) { audioLoop() }
    }

    fun play() {
        if (released.get()) return
        playing.set(true)
        _state.value = _state.value.copy(playing = true, errorMessage = null)
    }

    fun pause() {
        playing.set(false)
        _state.value = _state.value.copy(playing = false)
    }

    fun toggle() = if (playing.get()) pause() else play()

    fun seekTo(positionMs: Long) {
        val frame = (positionMs * targetRate / 1000L).coerceIn(0L, (backing.frameCount - 1L).coerceAtLeast(0L))
        cursor.set(frame)
        fxProcessor.reset()
        _state.value = _state.value.copy(positionMs = frame * 1000L / targetRate)
    }

    fun updateMixSettings(value: SessionMixSettings) {
        val safe = value.sanitized()
        val previous = mixSettings.getAndSet(safe)
        if (previous.previewSource != safe.previewSource) fxProcessor.reset()
        _state.value = _state.value.copy(settings = safe)
    }

    fun updateFxSettings(value: VocalFxSettings) {
        fxSettings.set(value.sanitized())
    }

    override fun close() {
        if (!released.compareAndSet(false, true)) return
        playing.set(false)
        worker.interrupt()
    }

    private fun audioLoop() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
        val minBuffer = AudioTrack.getMinBufferSize(
            targetRate,
            AudioFormat.CHANNEL_OUT_STEREO,
            AudioFormat.ENCODING_PCM_FLOAT
        )
        val track = try {
            AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setSampleRate(targetRate)
                        .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                        .build()
                )
                .setTransferMode(AudioTrack.MODE_STREAM)
                .setBufferSizeInBytes(max(minBuffer, 512 * 2 * 4 * 4))
                .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
                .build()
        } catch (error: Throwable) {
            _state.value = _state.value.copy(prepared = false, errorMessage = error.message ?: "פתיחת Session Mix נכשלה")
            closeReaders()
            return
        }

        val framesPerBlock = 512
        val backingBlock = FloatArray(framesPerBlock * backing.channels)
        val vocalBlock = FloatArray(framesPerBlock)
        val stereoOut = FloatArray(framesPerBlock * 2)
        val maxVocalRate = max(raw.sampleRate, processed.sampleRate)
        val maxVocalChannels = max(raw.channels, processed.channels)
        val maxSourceFrames = ((framesPerBlock.toLong() * maxVocalRate + targetRate - 1L) / targetRate + 4L).toInt()
        val vocalSourceScratch = FloatArray(maxSourceFrames * maxVocalChannels)
        var started = false
        try {
            while (!released.get()) {
                if (!playing.get()) {
                    if (started) {
                        runCatching { track.pause() }
                        runCatching { track.flush() }
                        started = false
                    }
                    Thread.sleep(12L)
                    continue
                }
                if (!started) {
                    track.play()
                    started = true
                }
                var frame = cursor.get()
                if (frame >= backing.frameCount) {
                    cursor.set(0L)
                    playing.set(false)
                    fxProcessor.reset()
                    _state.value = _state.value.copy(playing = false, positionMs = 0L)
                    continue
                }
                val count = minOf(framesPerBlock.toLong(), backing.frameCount - frame).toInt()
                val backingRead = backing.readFrames(frame, backingBlock, 0, count)
                if (backingRead <= 0) {
                    playing.set(false)
                    continue
                }

                val mix = mixSettings.get()
                val selectedReader = if (mix.previewSource == PreviewSource.Raw) raw else processed
                val selectedStart = if (mix.previewSource == PreviewSource.Raw) rawStart else processedStart
                readResampledMono(
                    selectedReader, frame, targetRate, selectedStart, vocalBlock, backingRead, vocalSourceScratch
                )
                if (mix.previewSource == PreviewSource.Processed) {
                    fxProcessor.processInPlace(vocalBlock, 0, backingRead, fxSettings.get())
                }

                val playbackGain = mix.playbackGain
                val vocalGain = mix.vocalGain
                val masterGain = mix.masterGain
                var outIndex = 0
                repeat(backingRead) { i ->
                    val left: Float
                    val right: Float
                    if (backing.channels == 1) {
                        left = backingBlock[i]
                        right = backingBlock[i]
                    } else {
                        left = backingBlock[i * 2]
                        right = backingBlock[i * 2 + 1]
                    }
                    stereoOut[outIndex++] = SessionMixMath.mixChannel(
                        left, vocalBlock[i], playbackGain, vocalGain, masterGain
                    )
                    stereoOut[outIndex++] = SessionMixMath.mixChannel(
                        right, vocalBlock[i], playbackGain, vocalGain, masterGain
                    )
                }
                val samplesWritten = track.write(stereoOut, 0, backingRead * 2, AudioTrack.WRITE_BLOCKING)
                if (samplesWritten < 0) error("AudioTrack write failed: $samplesWritten")
                val framesWritten = samplesWritten / 2
                frame += framesWritten
                cursor.set(frame)
                if ((frame / framesPerBlock) % 6L == 0L) {
                    _state.value = _state.value.copy(
                        playing = true,
                        positionMs = frame * 1000L / targetRate,
                        settings = mix
                    )
                }
            }
        } catch (_: InterruptedException) {
            // Normal release.
        } catch (error: Throwable) {
            playing.set(false)
            _state.value = _state.value.copy(playing = false, errorMessage = error.message ?: "Session Mix נכשל")
        } finally {
            runCatching { track.pause() }
            runCatching { track.flush() }
            runCatching { track.release() }
            closeReaders()
        }
    }

    private fun readResampledMono(
        reader: Pcm16InterleavedWavReader,
        targetStartFrame: Long,
        targetSampleRate: Int,
        sourceStartFrame: Long,
        output: FloatArray,
        count: Int,
        sourceSamples: FloatArray
    ) {
        output.fill(0f, 0, count)
        val range = SessionMixMath.requiredSourceWindow(
            targetStartFrame,
            count,
            targetSampleRate,
            reader.sampleRate,
            sourceStartFrame
        )
        if (range.isEmpty() || range.first >= reader.frameCount) return
        val first = range.first.coerceAtLeast(0L)
        val last = minOf(range.last, reader.frameCount - 1L)
        val framesNeeded = (last - first + 1L).toInt()
        check(sourceSamples.size >= framesNeeded * reader.channels) { "Vocal resample scratch too small" }
        val framesRead = reader.readFrames(first, sourceSamples, 0, framesNeeded)
        if (framesRead <= 0) return

        fun monoAt(frameIndex: Int): Float {
            val safe = frameIndex.coerceIn(0, framesRead - 1)
            return if (reader.channels == 1) sourceSamples[safe]
            else (sourceSamples[safe * 2] + sourceSamples[safe * 2 + 1]) * 0.5f
        }

        repeat(count) { i ->
            val sourcePosition = SessionMixMath.sourcePositionForTargetFrame(
                targetStartFrame + i,
                targetSampleRate,
                reader.sampleRate,
                sourceStartFrame
            )
            if (sourcePosition < first || sourcePosition > last) return@repeat
            val local = sourcePosition - first
            val i0 = floor(local).toInt().coerceIn(0, framesRead - 1)
            val i1 = (i0 + 1).coerceIn(0, framesRead - 1)
            val frac = (local - i0).toFloat()
            output[i] = monoAt(i0) * (1f - frac) + monoAt(i1) * frac
        }
    }

    private fun closeReaders() {
        runCatching { backing.close() }
        runCatching { raw.close() }
        runCatching { processed.close() }
    }
}
