package com.kolbomusic.singstudio.core.playback

import java.net.URI

/** Restricts the in-app browser/player to HTTPS YouTube surfaces we intentionally support. */
object YouTubeNavigationPolicy {
    fun isAllowed(url: String?, allowKolboOrigin: Boolean = false): Boolean {
        if (url.isNullOrBlank()) return false
        val uri = runCatching { URI(url) }.getOrNull() ?: return false
        if (!uri.scheme.equals("https", ignoreCase = true)) return false
        val host = uri.host?.lowercase()?.trimEnd('.') ?: return false
        if (allowKolboOrigin && host == "kolbomusic.com") return true
        return host == "youtu.be" ||
            host == "youtube.com" || host.endsWith(".youtube.com") ||
            host == "youtube-nocookie.com" || host.endsWith(".youtube-nocookie.com")
    }
}
