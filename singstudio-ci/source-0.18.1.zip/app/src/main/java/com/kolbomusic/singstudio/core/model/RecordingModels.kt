package com.kolbomusic.singstudio.core.model

data class DeviceCapabilities(
    val manufacturer: String,
    val model: String,
    val androidVersion: String,
    val sdkInt: Int,
    val hasMicrophone: Boolean,
    val hasCamera: Boolean,
    val cameraCount: Int,
    val supportsLowLatencyAudio: Boolean,
    val supportsProAudio: Boolean,
    val supportsUnprocessedAudio: Boolean,
    val nativeSampleRate: Int,
    val nativeFramesPerBuffer: Int
)

enum class RecordingPhase {
    Idle,
    Starting,
    Recording,
    Stopping,
    Saved,
    Error
}

data class RecordingTelemetry(
    val linearLevel: Float = 0f,
    val peakDbfs: Float = -96f,
    val clipping: Boolean = false,
    val elapsedMs: Long = 0L
)

data class RecordingState(
    val phase: RecordingPhase = RecordingPhase.Idle,
    val telemetry: RecordingTelemetry = RecordingTelemetry(),
    val activeTakeId: String? = null,
    val savedFilePath: String? = null,
    val playbackStartOffsetMs: Long? = null,
    val cameraStartOffsetMs: Long? = null,
    val cameraFilePath: String? = null,
    val recoveredTakeCount: Int = 0,
    val errorMessage: String? = null
)

data class AudioInputProfile(
    val audioSource: Int,
    val sourceLabel: String,
    val sampleRate: Int,
    val framesPerBuffer: Int,
    val bufferSizeBytes: Int,
    val rawPreferred: Boolean
)
