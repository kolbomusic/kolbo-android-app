package com.kolbomusic.singstudio.ui.onboarding

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.sizeIn
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.kolbomusic.singstudio.ui.theme.ElectricViolet
import com.kolbomusic.singstudio.ui.theme.GraphiteElevated
import com.kolbomusic.singstudio.ui.theme.WarmGold

@Composable
fun OnboardingScreen(
    largeControls: Boolean,
    reduceMotion: Boolean,
    onLargeControlsChange: (Boolean) -> Unit,
    onReduceMotionChange: (Boolean) -> Unit,
    onContinue: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.statusBars)
            .windowInsetsPadding(WindowInsets.navigationBars)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 22.dp, vertical = 26.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier.background(ElectricViolet.copy(alpha = 0.16f), RoundedCornerShape(999.dp)).padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.Mic, contentDescription = null, tint = ElectricViolet)
        }
        Spacer(Modifier.height(24.dp))
        Text("ברוכים הבאים לקולבו סטודיו", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        Text(
            "בוחרים שיר, מתחילים לשיר, ובסיום שומרים סרטון מוכן.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))

        OnboardingFeature(Icons.Default.MusicNote, "בחירת שיר פשוטה", "YouTube או קובץ מהטלפון")
        OnboardingFeature(Icons.Default.AutoAwesome, "הכול אוטומטי", "עיבוד קול, איזון, מיקס ומאסטרינג בלי הגדרות ידניות")
        OnboardingFeature(Icons.Default.CheckCircle, "שמירה ברורה", "בסיום מופיע כפתור גדול אחד: שמור סרטון")

        Spacer(Modifier.height(18.dp))
        Card(colors = CardDefaults.cardColors(containerColor = GraphiteElevated), shape = RoundedCornerShape(20.dp)) {
            Column(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("נוחות ונגישות", fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleLarge)
                PreferenceRow(
                    title = "כפתורים גדולים וברורים",
                    subtitle = "מומלץ לשימוש נוח בזמן שירה",
                    checked = largeControls,
                    onChecked = onLargeControlsChange
                )
                PreferenceRow(
                    title = "הפחתת אנימציות",
                    subtitle = "מתאים למי שמעדיף ממשק רגוע יותר",
                    checked = reduceMotion,
                    onChecked = onReduceMotionChange
                )
            }
        }

        Spacer(Modifier.height(22.dp))
        Button(
            onClick = onContinue,
            modifier = Modifier.fillMaxWidth().heightIn(min = 58.dp).sizeIn(minHeight = 48.dp),
            shape = RoundedCornerShape(18.dp),
            colors = ButtonDefaults.buttonColors(containerColor = ElectricViolet)
        ) {
            Icon(Icons.Default.Visibility, contentDescription = null)
            Text("  כניסה לאולפן", fontWeight = FontWeight.ExtraBold)
        }
        Spacer(Modifier.height(10.dp))
        Text("הכפתורים הגדולים מומלצים כברירת מחדל.", style = MaterialTheme.typography.bodySmall, color = WarmGold)
    }
}

@Composable
private fun OnboardingFeature(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
        colors = CardDefaults.cardColors(containerColor = GraphiteElevated),
        shape = RoundedCornerShape(18.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = WarmGold)
            Column(modifier = Modifier.padding(start = 12.dp)) {
                Text(title, fontWeight = FontWeight.Bold)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun PreferenceRow(title: String, subtitle: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChecked)
    }
}
