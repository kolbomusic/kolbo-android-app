package com.kolbomusic.singstudio.core.export

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import com.kolbomusic.singstudio.core.model.BackgroundVisualStyle
import com.kolbomusic.singstudio.core.model.BuiltInBackgroundPreset
import java.io.File
import java.io.FileOutputStream

object BuiltInBackgroundRenderer {
    fun render(preset: BuiltInBackgroundPreset, width: Int, height: Int, output: File): File {
        require(width > 0 && height > 0) { "Invalid background dimensions" }
        output.parentFile?.mkdirs()
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val top = preset.topColorHex.toInt()
        val bottom = preset.bottomColorHex.toInt()
        val accent = preset.accentColorHex.toInt()

        paint.shader = LinearGradient(0f, 0f, 0f, height.toFloat(), top, bottom, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
        paint.shader = null

        drawAmbientLights(canvas, paint, width, height, accent)
        when (preset.visualStyle) {
            BackgroundVisualStyle.MediterraneanStage -> drawStage(canvas, paint, width, height, accent, 5)
            BackgroundVisualStyle.JerusalemNight -> drawJerusalem(canvas, paint, width, height, accent)
            BackgroundVisualStyle.NeonCity -> drawNeonCity(canvas, paint, width, height, accent)
            BackgroundVisualStyle.WeddingVelvet -> drawCurtains(canvas, paint, width, height, accent)
            BackgroundVisualStyle.DesertSunset -> drawDesert(canvas, paint, width, height, accent)
            BackgroundVisualStyle.KaraokeClub -> drawStage(canvas, paint, width, height, accent, 7)
            BackgroundVisualStyle.BlueWhiteStage -> drawBlueWhiteStage(canvas, paint, width, height)
            BackgroundVisualStyle.HennaGold -> drawOrnaments(canvas, paint, width, height, accent)
            BackgroundVisualStyle.BeachSunset -> drawBeach(canvas, paint, width, height, accent)
            BackgroundVisualStyle.PianoLounge -> drawLounge(canvas, paint, width, height, accent)
            BackgroundVisualStyle.MoroccanArch -> drawArches(canvas, paint, width, height, accent)
            BackgroundVisualStyle.EventHall -> drawHall(canvas, paint, width, height, accent)
            BackgroundVisualStyle.NeonWave -> drawNeonWaves(canvas, paint, width, height, accent)
            BackgroundVisualStyle.FestivalLights -> drawFestival(canvas, paint, width, height, accent)
        }

        FileOutputStream(output).use { bitmap.compress(Bitmap.CompressFormat.PNG, 96, it) }
        bitmap.recycle()
        check(output.isFile && output.length() > 0L) { "Background render failed" }
        return output
    }

    private fun drawAmbientLights(canvas: Canvas, paint: Paint, w: Int, h: Int, accent: Int) {
        paint.shader = RadialGradient(w * .22f, h * .20f, w * .68f,
            intArrayOf(withAlpha(accent, 105), Color.TRANSPARENT), floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)
        canvas.drawCircle(w * .22f, h * .20f, w * .68f, paint)
        paint.shader = RadialGradient(w * .82f, h * .75f, w * .52f,
            intArrayOf(withAlpha(accent, 64), Color.TRANSPARENT), floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)
        canvas.drawCircle(w * .82f, h * .75f, w * .52f, paint)
        paint.shader = null
    }

    private fun drawStage(canvas: Canvas, paint: Paint, w: Int, h: Int, accent: Int, beams: Int) {
        paint.color = withAlpha(accent, 38)
        repeat(beams) { i ->
            val x = w * (0.08f + i * (0.84f / (beams - 1).coerceAtLeast(1)))
            val path = Path().apply {
                moveTo(x, 0f); lineTo(x - w * .12f, h * .82f); lineTo(x + w * .12f, h * .82f); close()
            }
            canvas.drawPath(path, paint)
        }
        paint.color = withAlpha(Color.WHITE, 34)
        canvas.drawOval(RectF(w * .07f, h * .78f, w * .93f, h * 1.04f), paint)
        drawSparkles(canvas, paint, w, h, accent, 26)
    }

    private fun drawJerusalem(canvas: Canvas, paint: Paint, w: Int, h: Int, accent: Int) {
        paint.color = withAlpha(accent, 58)
        val base = h * .72f
        repeat(9) { i ->
            val left = w * (i / 9f)
            val bw = w / 8.2f
            val bh = h * (.08f + (i % 4) * .025f)
            canvas.drawRect(left, base - bh, left + bw, base, paint)
            if (i % 3 == 1) canvas.drawCircle(left + bw * .5f, base - bh, bw * .23f, paint)
        }
        paint.color = withAlpha(accent, 85)
        canvas.drawCircle(w * .78f, h * .19f, w * .045f, paint)
        drawSparkles(canvas, paint, w, (h * .65f).toInt(), accent, 18)
    }

    private fun drawNeonCity(canvas: Canvas, paint: Paint, w: Int, h: Int, accent: Int) {
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = (w * .004f).coerceAtLeast(3f)
        repeat(7) { i ->
            paint.color = withAlpha(if (i % 2 == 0) accent else Color.MAGENTA, 145)
            val x = w * (.08f + i * .14f)
            canvas.drawLine(x, h * .22f, x, h * .84f, paint)
        }
        paint.style = Paint.Style.FILL
        drawSparkles(canvas, paint, w, h, accent, 34)
    }

    private fun drawCurtains(canvas: Canvas, paint: Paint, w: Int, h: Int, accent: Int) {
        paint.color = withAlpha(Color.BLACK, 78)
        canvas.drawOval(RectF(-w * .25f, -h * .1f, w * .38f, h * 1.1f), paint)
        canvas.drawOval(RectF(w * .62f, -h * .1f, w * 1.25f, h * 1.1f), paint)
        paint.color = withAlpha(accent, 120)
        canvas.drawCircle(w * .5f, h * .12f, w * .018f, paint)
        drawSparkles(canvas, paint, w, h, accent, 22)
    }

    private fun drawDesert(canvas: Canvas, paint: Paint, w: Int, h: Int, accent: Int) {
        paint.color = withAlpha(accent, 95)
        canvas.drawCircle(w * .72f, h * .25f, w * .085f, paint)
        paint.color = withAlpha(Color.BLACK, 48)
        val p = Path().apply { moveTo(0f,h*.82f); cubicTo(w*.25f,h*.67f,w*.46f,h*.92f,w*.7f,h*.75f); cubicTo(w*.82f,h*.67f,w*.92f,h*.75f,w.toFloat(),h*.70f); lineTo(w.toFloat(),h.toFloat()); lineTo(0f,h.toFloat()); close() }
        canvas.drawPath(p, paint)
    }

    private fun drawBlueWhiteStage(canvas: Canvas, paint: Paint, w: Int, h: Int) {
        paint.color = Color.argb(64, 255,255,255)
        repeat(5) { i ->
            val x = w * (.1f + i*.2f)
            val path=Path().apply { moveTo(x,0f); lineTo(x-w*.10f,h*.75f); lineTo(x+w*.10f,h*.75f); close() }
            canvas.drawPath(path,paint)
        }
        paint.color = Color.argb(85, 56,132,255)
        canvas.drawRect(0f,h*.86f,w.toFloat(),h*.89f,paint)
    }

    private fun drawOrnaments(canvas: Canvas, paint: Paint, w: Int, h: Int, accent: Int) {
        paint.style=Paint.Style.STROKE; paint.strokeWidth=(w*.003f).coerceAtLeast(2f); paint.color=withAlpha(accent,115)
        repeat(6){i-> val r=w*(.04f+i*.018f); canvas.drawCircle(w*.5f,h*.5f,r,paint) }
        paint.style=Paint.Style.FILL; drawSparkles(canvas,paint,w,h,accent,30)
    }

    private fun drawBeach(canvas: Canvas, paint: Paint, w: Int, h: Int, accent: Int) {
        paint.color=withAlpha(accent,105); canvas.drawCircle(w*.72f,h*.22f,w*.07f,paint)
        paint.color=Color.argb(52,100,205,255); canvas.drawRect(0f,h*.62f,w.toFloat(),h.toFloat(),paint)
        paint.color=Color.argb(90,255,255,255); paint.strokeWidth=(h*.003f).coerceAtLeast(2f)
        repeat(4){i-> canvas.drawLine(0f,h*(.68f+i*.055f),w.toFloat(),h*(.68f+i*.055f),paint) }
    }

    private fun drawLounge(canvas: Canvas, paint: Paint, w: Int, h: Int, accent: Int) {
        paint.color=withAlpha(accent,68); canvas.drawOval(RectF(w*.08f,h*.72f,w*.92f,h*.98f),paint)
        paint.color=Color.argb(95,0,0,0); canvas.drawRect(w*.12f,h*.55f,w*.45f,h*.79f,paint)
        repeat(9){i-> paint.color=if(i%2==0) Color.argb(160,240,240,240) else Color.argb(180,18,18,18); val x=w*(.14f+i*.032f); canvas.drawRect(x,h*.66f,x+w*.026f,h*.79f,paint)}
    }

    private fun drawArches(canvas: Canvas, paint: Paint, w: Int, h: Int, accent: Int) {
        paint.style=Paint.Style.STROKE; paint.strokeWidth=(w*.012f).coerceAtLeast(8f); paint.color=withAlpha(accent,90)
        repeat(3){i-> val cx=w*(.2f+i*.3f); canvas.drawArc(RectF(cx-w*.13f,h*.25f,cx+w*.13f,h*.62f),180f,180f,false,paint); canvas.drawLine(cx-w*.13f,h*.435f,cx-w*.13f,h*.85f,paint); canvas.drawLine(cx+w*.13f,h*.435f,cx+w*.13f,h*.85f,paint)}
        paint.style=Paint.Style.FILL
    }

    private fun drawHall(canvas: Canvas, paint: Paint, w: Int, h: Int, accent: Int) {
        paint.color=withAlpha(accent,70); repeat(7){i->canvas.drawCircle(w*(.08f+i*.14f),h*.18f,w*.018f,paint)}
        paint.color=Color.argb(48,255,255,255); canvas.drawOval(RectF(w*.1f,h*.75f,w*.9f,h*1.02f),paint)
    }

    private fun drawNeonWaves(canvas: Canvas, paint: Paint, w: Int, h: Int, accent: Int) {
        paint.style=Paint.Style.STROKE; paint.strokeWidth=(w*.006f).coerceAtLeast(4f)
        repeat(4){j-> paint.color=withAlpha(if(j%2==0)accent else Color.MAGENTA,140-j*18); val path=Path(); repeat(80){i-> val x=w*i/79f; val y=h*(.35f+j*.12f)+(kotlin.math.sin(i * 0.32 + j) * h.toDouble() * 0.045).toFloat(); if(i==0)path.moveTo(x,y) else path.lineTo(x,y)}; canvas.drawPath(path,paint)}
        paint.style=Paint.Style.FILL
    }

    private fun drawFestival(canvas: Canvas, paint: Paint, w: Int, h: Int, accent: Int) {
        drawSparkles(canvas,paint,w,h,accent,58)
        paint.color=withAlpha(Color.WHITE,30); repeat(5){i->canvas.drawOval(RectF(w*(.08f+i*.19f)-w*.05f,h*.05f,w*(.08f+i*.19f)+w*.05f,h*.82f),paint)}
    }

    private fun drawSparkles(canvas: Canvas, paint: Paint, w: Int, h: Int, accent: Int, count: Int) {
        repeat(count) { i ->
            val x = w * (((i * 37 + 7) % 101) / 100f)
            val y = h * (((i * 61 + 17) % 101) / 100f)
            val radius = (w.coerceAtMost(h) * (.0024f + (i % 3) * .0011f)).coerceAtLeast(2f)
            paint.color = if (i % 4 == 0) withAlpha(accent, 105) else Color.argb(62,255,255,255)
            canvas.drawCircle(x, y, radius, paint)
        }
    }

    private fun withAlpha(color: Int, alpha: Int): Int = Color.argb(alpha.coerceIn(0,255), Color.red(color), Color.green(color), Color.blue(color))
}
