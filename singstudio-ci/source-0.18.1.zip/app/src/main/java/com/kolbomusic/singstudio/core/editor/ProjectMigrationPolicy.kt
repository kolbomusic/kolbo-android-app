package com.kolbomusic.singstudio.core.editor

object ProjectMigrationPolicy {
    const val CURRENT_SCHEMA = 5
    const val MIN_SUPPORTED_SCHEMA = 1

    data class Decision(
        val accepted: Boolean,
        val migrated: Boolean,
        val warnings: List<String>
    )

    fun decide(schema: Int): Decision {
        if (schema < MIN_SUPPORTED_SCHEMA) {
            return Decision(false, false, listOf("גרסת פרויקט ישנה מדי ואינה נתמכת"))
        }
        if (schema > CURRENT_SCHEMA) {
            return Decision(false, false, listOf("הפרויקט נוצר בגרסה חדשה יותר של האפליקציה"))
        }
        if (schema == CURRENT_SCHEMA) return Decision(true, false, emptyList())
        return Decision(
            accepted = true,
            migrated = true,
            warnings = listOf("הפרויקט נטען מסכמה $schema והותאם בזיכרון לסכמה $CURRENT_SCHEMA; הקובץ המקורי לא שונה")
        )
    }
}
