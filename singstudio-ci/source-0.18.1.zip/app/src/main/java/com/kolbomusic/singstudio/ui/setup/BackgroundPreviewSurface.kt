package com.kolbomusic.singstudio.ui.setup

import android.net.Uri
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.VideoView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.unit.dp
import com.kolbomusic.singstudio.core.model.BackgroundVisualStyle
import com.kolbomusic.singstudio.core.model.BuiltInBackgrounds
import com.kolbomusic.singstudio.core.model.VisualBackground
import com.kolbomusic.singstudio.core.model.VisualBackgroundType
import com.kolbomusic.singstudio.ui.theme.ElectricViolet

@Composable
fun BackgroundPreviewSurface(
    background: VisualBackground,
    modifier: Modifier = Modifier
) {
    when (background.type) {
        VisualBackgroundType.BuiltIn -> {
            val preset = BuiltInBackgrounds.byId(background.id)
            Box(
                modifier = modifier.background(
                    if (preset != null) {
                        Brush.verticalGradient(listOf(Color(preset.topColorHex), Color(preset.bottomColorHex)))
                    } else {
                        Brush.linearGradient(listOf(ElectricViolet.copy(alpha = 0.4f), Color(0xFF10131A)))
                    }
                ),
                contentAlignment = Alignment.Center
            ) {
                if (preset != null) {
                    val accent = Color(preset.accentColorHex)
                    Canvas(Modifier.fillMaxSize()) {
                        val w = size.width
                        val h = size.height
                        when (preset.visualStyle) {
                            BackgroundVisualStyle.MediterraneanStage,
                            BackgroundVisualStyle.KaraokeClub,
                            BackgroundVisualStyle.BlueWhiteStage -> {
                                repeat(5) { i ->
                                    val x = w * (0.1f + i * 0.2f)
                                    val beam = Path().apply {
                                        moveTo(x, 0f)
                                        lineTo(x - w * 0.11f, h * 0.82f)
                                        lineTo(x + w * 0.11f, h * 0.82f)
                                        close()
                                    }
                                    drawPath(beam, accent.copy(alpha = if (preset.visualStyle == BackgroundVisualStyle.BlueWhiteStage) 0.18f else 0.12f))
                                }
                            }
                            BackgroundVisualStyle.JerusalemNight -> {
                                repeat(8) { i ->
                                    val left = w * (i / 8f)
                                    val top = h * (0.64f - (i % 3) * 0.04f)
                                    drawRect(accent.copy(alpha = 0.20f), topLeft = androidx.compose.ui.geometry.Offset(left, top), size = androidx.compose.ui.geometry.Size(w / 7.2f, h * 0.18f))
                                }
                            }
                            BackgroundVisualStyle.NeonCity, BackgroundVisualStyle.NeonWave -> {
                                repeat(5) { j ->
                                    val path = Path()
                                    repeat(48) { i ->
                                        val x = w * i / 47f
                                        val y = h * (0.25f + j * 0.12f) + kotlin.math.sin(i * 0.34 + j).toFloat() * h * 0.035f
                                        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                                    }
                                    drawPath(path, accent.copy(alpha = 0.55f - j * 0.07f), style = Stroke(width = (w * 0.005f).coerceAtLeast(2f)))
                                }
                            }
                            BackgroundVisualStyle.MoroccanArch, BackgroundVisualStyle.HennaGold -> {
                                repeat(3) { i ->
                                    val cx = w * (0.2f + i * 0.3f)
                                    drawCircle(accent.copy(alpha = 0.16f), radius = w * 0.11f, center = androidx.compose.ui.geometry.Offset(cx, h * 0.42f), style = Stroke(width = (w * 0.012f).coerceAtLeast(3f)))
                                }
                            }
                            else -> {
                                repeat(18) { i ->
                                    val x = w * (((i * 37 + 7) % 101) / 100f)
                                    val y = h * (((i * 61 + 17) % 101) / 100f)
                                    drawCircle(if (i % 4 == 0) accent.copy(alpha = 0.55f) else Color.White.copy(alpha = 0.25f), radius = (w.coerceAtMost(h) * 0.006f).coerceAtLeast(2f), center = androidx.compose.ui.geometry.Offset(x, y))
                                }
                            }
                        }
                    }
                }
            }
        }

        VisualBackgroundType.Image -> {
            val uri = background.uriString?.let(Uri::parse)
            if (uri != null) {
                AndroidView(
                    modifier = modifier,
                    factory = { context ->
                        ImageView(context).apply {
                            layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                            scaleType = ImageView.ScaleType.CENTER_CROP
                            setImageURI(uri)
                        }
                    },
                    update = { view -> view.setImageURI(uri) }
                )
            } else EmptyBackground(modifier)
        }

        VisualBackgroundType.Video -> {
            val uri = background.uriString?.let(Uri::parse)
            if (uri != null) {
                var videoView: VideoView? = null
                AndroidView(
                    modifier = modifier,
                    factory = { context ->
                        VideoView(context).apply {
                            videoView = this
                            setVideoURI(uri)
                            setOnPreparedListener { player ->
                                player.isLooping = true
                                player.setVolume(0f, 0f)
                                start()
                            }
                        }
                    },
                    update = { view ->
                        if (!view.isPlaying) view.start()
                    }
                )
                DisposableEffect(uri) {
                    onDispose { runCatching { videoView?.stopPlayback() } }
                }
            } else EmptyBackground(modifier)
        }

        VisualBackgroundType.None -> EmptyBackground(modifier)
    }
}

@Composable
private fun EmptyBackground(modifier: Modifier) {
    Box(
        modifier = modifier.background(Color(0xFF10131A))
    )
}
