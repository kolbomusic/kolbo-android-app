package com.kolbomusic.singstudio.core.audio

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import com.kolbomusic.singstudio.core.model.AudioInputProfile
import com.kolbomusic.singstudio.core.model.DeviceCapabilities
import kotlin.math.max

object AudioInputSelector {

    fun candidates(capabilities: DeviceCapabilities): List<AudioInputProfile> {
        val rates = listOf(capabilities.nativeSampleRate, 48_000, 44_100)
            .filter { it in 8_000..192_000 }
            .distinct()

        val sources = buildList {
            // VOICE_PERFORMANCE is designed for musical/live-performance capture and
            // is a better first choice on modern Android devices than forcing a fully
            // unprocessed phone-mic path that may be noisy or poorly calibrated.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                add(MediaRecorder.AudioSource.VOICE_PERFORMANCE to "VOICE_PERFORMANCE")
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && capabilities.supportsUnprocessedAudio) {
                add(MediaRecorder.AudioSource.UNPROCESSED to "UNPROCESSED")
            }
            add(MediaRecorder.AudioSource.VOICE_RECOGNITION to "VOICE_RECOGNITION")
            add(MediaRecorder.AudioSource.MIC to "MIC")
        }.distinctBy { it.first }

        return sources.flatMap { (source, label) ->
            rates.mapNotNull { rate ->
                createProfile(
                    audioSource = source,
                    sourceLabel = label,
                    sampleRate = rate,
                    framesPerBuffer = capabilities.nativeFramesPerBuffer,
                    rawPreferred = source == MediaRecorder.AudioSource.UNPROCESSED
                )
            }
        }
    }

    private fun createProfile(
        audioSource: Int,
        sourceLabel: String,
        sampleRate: Int,
        framesPerBuffer: Int,
        rawPreferred: Boolean
    ): AudioInputProfile? {
        val safeFrames = framesPerBuffer.coerceAtLeast(96)
        val minimum = AudioRecord.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        if (minimum <= 0) return null

        // PCM16 mono = 2 bytes per frame. Align to the device buffer quantum,
        // but keep at least two quanta to reduce jitter on varied OEM stacks.
        val nativeBytes = safeFrames * 2
        val multiplier = ((minimum + nativeBytes - 1) / nativeBytes).coerceAtLeast(2)
        val bufferBytes = max(minimum, nativeBytes * multiplier)

        return AudioInputProfile(
            audioSource = audioSource,
            sourceLabel = sourceLabel,
            sampleRate = sampleRate,
            framesPerBuffer = safeFrames,
            bufferSizeBytes = bufferBytes,
            rawPreferred = rawPreferred
        )
    }
}
