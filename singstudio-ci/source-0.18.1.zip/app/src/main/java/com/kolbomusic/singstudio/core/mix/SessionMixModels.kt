package com.kolbomusic.singstudio.core.mix

import com.kolbomusic.singstudio.core.dsp.PreviewSource
import kotlin.math.pow


data class SessionMixSettings(
    val vocalGainDb: Float = -5f,
    val playbackGainDb: Float = -3f,
    val masterHeadroomDb: Float = -4f,
    val previewSource: PreviewSource = PreviewSource.Processed
) {
    fun sanitized(): SessionMixSettings = copy(
        vocalGainDb = vocalGainDb.coerceIn(-24f, 12f),
        playbackGainDb = playbackGainDb.coerceIn(-24f, 6f),
        masterHeadroomDb = masterHeadroomDb.coerceIn(-12f, 0f)
    )

    val vocalGain: Float get() = dbToLinear(vocalGainDb)
    val playbackGain: Float get() = dbToLinear(playbackGainDb)
    val masterGain: Float get() = dbToLinear(masterHeadroomDb)

    companion object {
        fun dbToLinear(db: Float): Float = 10.0.pow(db / 20.0).toFloat()
    }
}

data class SessionMixState(
    val available: Boolean = false,
    val preparing: Boolean = false,
    val prepared: Boolean = false,
    val playing: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val settings: SessionMixSettings = SessionMixSettings(),
    val backingCachePath: String? = null,
    val rendering: Boolean = false,
    val renderProgress: Float = 0f,
    val renderedMixPath: String? = null,
    val renderedMixSha256: String? = null,
    val mastering: Boolean = false,
    val masteringProgress: Float = 0f,
    val masteredMixPath: String? = null,
    val masteredMixSha256: String? = null,
    val errorMessage: String? = null
)

data class SessionMixRenderResult(
    val outputFilePath: String,
    val outputSha256: String,
    val sampleRate: Int,
    val durationMs: Long
)
