package com.kolbomusic.singstudio.core.mix

import com.kolbomusic.singstudio.core.audio.WavFileTools
import java.io.File
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.sqrt

/**
 * Deterministic two-pass finalizer for the rendered stereo Session Mix.
 * It raises/lower the final mix toward a conservative streaming-oriented RMS target,
 * while always respecting a -1 dBFS true-sample approximation ceiling.
 */
class AutomaticMasteringEngine {
    data class Result(
        val outputFilePath: String,
        val outputSha256: String,
        val durationMs: Long,
        val inputPeakDbfs: Double,
        val inputRmsDbfs: Double,
        val appliedGainDb: Double,
        val outputPeakDbfs: Double
    )

    fun master(
        input: File,
        outputDirectory: File,
        onProgress: (Float) -> Unit = {}
    ): Result {
        require(input.isFile && input.length() > 44L) { "Session Mix חסר או פגום" }
        outputDirectory.mkdirs()
        val output = File(outputDirectory, "session-master.wav")
        val inputShaBefore = WavFileTools.sha256(input)

        val analysis = analyse(input) { onProgress(it * 0.42f) }
        // Use active-program RMS rather than whole-file RMS. Quiet intros/outros must
        // not trick mastering into pushing an already healthy song too loud.
        val targetRmsDb = -16.5
        val ceilingDb = -1.0
        val rmsGainDb = targetRmsDb - analysis.rmsDbfs
        val peakGainDb = ceilingDb - analysis.peakDbfs
        val gainDb = minOf(rmsGainDb, peakGainDb).coerceIn(-9.0, 2.0)
        val gain = 10.0.pow(gainDb / 20.0).toFloat()

        var outputPeak = 0.0
        Pcm16InterleavedWavReader(input).use { reader ->
            val masterBus = StereoMasterBusProcessor(reader.sampleRate)
            Pcm16InterleavedWavWriter(output, reader.sampleRate, reader.channels).use { writer ->
                val blockFrames = 4096
                val samples = FloatArray(blockFrames * reader.channels)
                var frame = 0L
                while (frame < reader.frameCount) {
                    val requested = minOf(blockFrames.toLong(), reader.frameCount - frame).toInt()
                    val read = reader.readFrames(frame, samples, 0, requested)
                    check(read > 0) { "קריאת Session Mix נקטעה בזמן Mastering" }
                    val sampleCount = read * reader.channels
                    var i = 0
                    while (i < sampleCount) {
                        if (reader.channels >= 2 && i + 1 < sampleCount) {
                            val processed = masterBus.process(samples[i] * gain, samples[i + 1] * gain)
                            samples[i] = processed.first
                            samples[i + 1] = processed.second
                            outputPeak = maxOf(outputPeak, abs(processed.first.toDouble()), abs(processed.second.toDouble()))
                            i += 2
                        } else {
                            val processed = masterBus.processMono(samples[i] * gain)
                            samples[i] = processed
                            outputPeak = maxOf(outputPeak, abs(processed.toDouble()))
                            i++
                        }
                    }
                    writer.writeInterleaved(samples, 0, sampleCount)
                    frame += read
                    onProgress(0.42f + 0.53f * (frame.toFloat() / reader.frameCount.toFloat()))
                }
                writer.commit()
            }
        }

        check(inputShaBefore == WavFileTools.sha256(input)) { "Session Mix השתנה בזמן Mastering" }
        Pcm16InterleavedWavReader(output).use { mastered ->
            check(mastered.frameCount > 0L && mastered.channels in 1..2) { "Mastering output invalid" }
        }
        onProgress(1f)
        return Result(
            outputFilePath = output.absolutePath,
            outputSha256 = WavFileTools.sha256(output),
            durationMs = analysis.durationMs,
            inputPeakDbfs = analysis.peakDbfs,
            inputRmsDbfs = analysis.rmsDbfs,
            appliedGainDb = gainDb,
            outputPeakDbfs = linearToDb(outputPeak)
        )
    }

    private data class Analysis(
        val durationMs: Long,
        val peakDbfs: Double,
        val rmsDbfs: Double
    )

    private fun analyse(input: File, onProgress: (Float) -> Unit): Analysis {
        Pcm16InterleavedWavReader(input).use { reader ->
            val blockFrames = 4096
            val samples = FloatArray(blockFrames * reader.channels)
            var frame = 0L
            var peak = 0.0
            val activeBlocks = ArrayList<Double>()
            while (frame < reader.frameCount) {
                val requested = minOf(blockFrames.toLong(), reader.frameCount - frame).toInt()
                val read = reader.readFrames(frame, samples, 0, requested)
                check(read > 0) { "קריאת Session Mix נקטעה בזמן ניתוח" }
                val count = read * reader.channels
                var blockSquares = 0.0
                for (i in 0 until count) {
                    val value = samples[i].toDouble()
                    peak = maxOf(peak, kotlin.math.abs(value))
                    blockSquares += value * value
                }
                val blockRms = if (count > 0) sqrt(blockSquares / count) else 0.0
                val blockDb = linearToDb(blockRms)
                if (blockDb > -55.0) activeBlocks += blockDb
                frame += read
                onProgress(frame.toFloat() / reader.frameCount.toFloat())
            }
            val programRmsDb = if (activeBlocks.isEmpty()) {
                -120.0
            } else {
                val sorted = activeBlocks.sorted()
                sorted[(sorted.lastIndex * 0.55).toInt().coerceIn(0, sorted.lastIndex)]
            }
            return Analysis(
                durationMs = reader.frameCount * 1000L / reader.sampleRate,
                peakDbfs = linearToDb(peak),
                rmsDbfs = programRmsDb
            )
        }
    }

    /**
     * Linked stereo glue compressor + peak controller. It intentionally keeps gain
     * reduction modest so the master sounds controlled without crushing the singer.
     */
    private class StereoMasterBusProcessor(private val sampleRate: Int) {
        private var detector = 0.0
        private var gainReductionDb = 0.0
        private val thresholdDb = -12.5
        private val ratio = 1.45
        private val maxReductionDb = -2.8
        private val ceiling = 0.8912509 // -1 dBFS

        fun process(left: Float, right: Float): Pair<Float, Float> {
            val level = maxOf(abs(left.toDouble()), abs(right.toDouble())).coerceAtLeast(1e-9)
            val gr = updateGainReduction(level)
            val gain = 10.0.pow(gr / 20.0)
            return peakControl(left.toDouble() * gain).toFloat() to peakControl(right.toDouble() * gain).toFloat()
        }

        fun processMono(sample: Float): Float {
            val gr = updateGainReduction(abs(sample.toDouble()).coerceAtLeast(1e-9))
            val gain = 10.0.pow(gr / 20.0)
            return peakControl(sample.toDouble() * gain).toFloat()
        }

        private fun updateGainReduction(level: Double): Double {
            val attackCoeff = exp(-1.0 / (0.001 * 22.0 * sampleRate.coerceAtLeast(8_000)))
            val releaseCoeff = exp(-1.0 / (0.001 * 260.0 * sampleRate.coerceAtLeast(8_000)))
            val detectorCoeff = if (level > detector) attackCoeff else releaseCoeff
            detector = level + detectorCoeff * (detector - level)
            val levelDb = linearToDb(detector)
            val desired = if (levelDb > thresholdDb) {
                val compressedDb = thresholdDb + (levelDb - thresholdDb) / ratio
                (compressedDb - levelDb).coerceAtLeast(maxReductionDb)
            } else 0.0
            val grCoeff = if (desired < gainReductionDb) attackCoeff else releaseCoeff
            gainReductionDb = desired + grCoeff * (gainReductionDb - desired)
            return gainReductionDb
        }

        private fun linearToDb(value: Double): Double =
            if (value <= 1e-12) -120.0 else 20.0 * log10(value)

        private fun peakControl(value: Double): Double {
            val a = abs(value)
            if (a <= ceiling) return value
            val sign = if (value < 0.0) -1.0 else 1.0
            val excess = (a - ceiling) / (1.0 - ceiling).coerceAtLeast(1e-6)
            val softened = ceiling + (1.0 - exp(-2.8 * excess)) * (1.0 - ceiling) * 0.10
            return sign * softened.coerceAtMost(0.995)
        }
    }

    private fun linearToDb(value: Double): Double =
        if (value <= 1e-12) -120.0 else 20.0 * log10(value)
}
