package com.kolbomusic.singstudio.core.dsp

import java.io.Closeable
import java.io.File
import java.io.RandomAccessFile

/** Random-access reader for mono PCM16 WAV files used by the live A/B preview. */
internal class Pcm16WavRandomAccessReader(file: File) : Closeable {
    private val raf = RandomAccessFile(file, "r")
    val sampleRate: Int
    val frameCount: Long
    private val dataOffset: Long
    private val dataSize: Long
    private val byteBuffer = ByteArray(4096 * 2)

    init {
        require(file.exists() && file.length() >= 44L) { "קובץ WAV חסר או פגום" }
        val riff = ByteArray(4).also(raf::readFully).toString(Charsets.US_ASCII)
        require(riff == "RIFF") { "פורמט WAV לא נתמך" }
        raf.skipBytes(4)
        val wave = ByteArray(4).also(raf::readFully).toString(Charsets.US_ASCII)
        require(wave == "WAVE") { "פורמט WAV לא נתמך" }

        var rate = 0
        var channels = 0
        var bits = 0
        var format = 0
        var foundDataOffset = -1L
        var foundDataSize = 0L
        while (raf.filePointer + 8L <= raf.length()) {
            val chunkId = ByteArray(4).also(raf::readFully).toString(Charsets.US_ASCII)
            val chunkSize = raf.readUInt32LE()
            val chunkStart = raf.filePointer
            when (chunkId) {
                "fmt " -> {
                    format = raf.readUInt16LE()
                    channels = raf.readUInt16LE()
                    rate = raf.readUInt32LE().toInt()
                    raf.skipBytes(6)
                    bits = raf.readUInt16LE()
                }
                "data" -> {
                    foundDataOffset = raf.filePointer
                    foundDataSize = minOf(chunkSize, raf.length() - raf.filePointer)
                    break
                }
            }
            raf.seek(chunkStart + chunkSize + (chunkSize and 1L))
        }
        require(format == 1 && channels == 1 && bits == 16) { "נדרש WAV Mono PCM16" }
        require(rate in 8_000..192_000) { "קצב דגימה לא תקין" }
        require(foundDataOffset >= 0L && foundDataSize > 0L) { "WAV ללא נתוני אודיו" }
        sampleRate = rate
        dataOffset = foundDataOffset
        dataSize = foundDataSize - (foundDataSize % 2L)
        frameCount = dataSize / 2L
    }

    fun readFrames(startFrame: Long, output: FloatArray, outputOffset: Int, requestedFrames: Int): Int {
        if (startFrame < 0L || startFrame >= frameCount || requestedFrames <= 0) return 0
        val available = minOf(requestedFrames.toLong(), frameCount - startFrame).toInt()
        raf.seek(dataOffset + startFrame * 2L)
        var remaining = available
        var outIndex = outputOffset
        while (remaining > 0) {
            val framesThisRead = minOf(remaining, byteBuffer.size / 2)
            val bytesWanted = framesThisRead * 2
            val bytesRead = raf.read(byteBuffer, 0, bytesWanted)
            if (bytesRead <= 0) break
            val framesRead = bytesRead / 2
            var bi = 0
            repeat(framesRead) {
                val value = (byteBuffer[bi].toInt() and 0xFF) or (byteBuffer[bi + 1].toInt() shl 8)
                output[outIndex++] = value.toShort() / 32768f
                bi += 2
            }
            remaining -= framesRead
            if (framesRead < framesThisRead) break
        }
        return outIndex - outputOffset
    }

    override fun close() = raf.close()

    private fun RandomAccessFile.readUInt16LE(): Int {
        val b0 = readUnsignedByte()
        val b1 = readUnsignedByte()
        return b0 or (b1 shl 8)
    }

    private fun RandomAccessFile.readUInt32LE(): Long {
        val b0 = readUnsignedByte().toLong()
        val b1 = readUnsignedByte().toLong()
        val b2 = readUnsignedByte().toLong()
        val b3 = readUnsignedByte().toLong()
        return b0 or (b1 shl 8) or (b2 shl 16) or (b3 shl 24)
    }
}
