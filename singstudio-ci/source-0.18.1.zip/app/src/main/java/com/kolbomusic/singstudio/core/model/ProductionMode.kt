package com.kolbomusic.singstudio.core.model

enum class ProductionMode {
    Camera,
    Background,
    CameraWithBackground;

    val usesCamera: Boolean
        get() = this == Camera || this == CameraWithBackground

    val usesBackground: Boolean
        get() = this == Background || this == CameraWithBackground
}
