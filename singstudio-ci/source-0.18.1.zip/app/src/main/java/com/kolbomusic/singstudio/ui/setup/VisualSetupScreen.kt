package com.kolbomusic.singstudio.ui.setup

import android.content.Intent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.kolbomusic.singstudio.core.model.BuiltInBackgroundPreset
import com.kolbomusic.singstudio.core.model.BuiltInBackgrounds
import com.kolbomusic.singstudio.core.model.CameraFacing
import com.kolbomusic.singstudio.core.model.OutputAspectRatio
import com.kolbomusic.singstudio.core.model.ProductionMode
import com.kolbomusic.singstudio.core.model.VisualBackground
import com.kolbomusic.singstudio.core.model.VisualBackgroundType
import com.kolbomusic.singstudio.core.model.VisualScene
import com.kolbomusic.singstudio.ui.theme.ElectricViolet
import com.kolbomusic.singstudio.ui.theme.GraphiteElevated
import com.kolbomusic.singstudio.ui.theme.RecordRose
import com.kolbomusic.singstudio.ui.theme.WarmGold

@Composable
fun VisualSetupScreen(
    mode: ProductionMode,
    onBack: () -> Unit,
    onContinue: (VisualScene) -> Unit
) {
    val context = LocalContext.current
    var aspectRatio by remember { mutableStateOf(OutputAspectRatio.Portrait9x16) }
    var cameraFacing by remember { mutableStateOf(CameraFacing.Front) }
    var background by remember {
        mutableStateOf(
            if (mode.usesBackground) {
                VisualBackground(
                    type = VisualBackgroundType.BuiltIn,
                    id = BuiltInBackgrounds.presets.first().id,
                    title = BuiltInBackgrounds.presets.first().title
                )
            } else VisualBackground()
        )
    }
    var pickerMessage by remember { mutableStateOf<String?>(null) }
    var backgroundCategory by remember { mutableStateOf("הכול") }

    val backgroundPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            val mime = context.contentResolver.getType(uri).orEmpty()
            background = VisualBackground(
                type = if (mime.startsWith("video/")) VisualBackgroundType.Video else VisualBackgroundType.Image,
                id = uri.toString(),
                title = if (mime.startsWith("video/")) "וידאו מהטלפון" else "תמונה מהטלפון",
                uriString = uri.toString()
            )
            pickerMessage = "הקובץ נבחר ונשמר כחלק מהפרויקט"
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.statusBars)
            .windowInsetsPadding(WindowInsets.navigationBars)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "חזרה")
            }
            Column(modifier = Modifier.weight(1f)) {
                Text("הכנת הביצוע", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text(modeSubtitle(mode), color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text("0.18.0", color = WarmGold, fontWeight = FontWeight.ExtraBold)
        }

        SectionCard(title = "פורמט הסרטון", subtitle = "אפשר לשנות בהמשך לפני הייצוא") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutputAspectRatio.entries.forEach { ratio ->
                    FilterChip(
                        selected = aspectRatio == ratio,
                        onClick = { aspectRatio = ratio },
                        label = { Text(ratio.label) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
            Text(
                when (aspectRatio) {
                    OutputAspectRatio.Portrait9x16 -> "מומלץ ל־TikTok, Reels ו־Shorts"
                    OutputAspectRatio.Landscape16x9 -> "מומלץ ל־YouTube ולטלוויזיה"
                    OutputAspectRatio.Square1x1 -> "מתאים לפוסטים מרובעים"
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        if (mode.usesCamera) {
            SectionCard(title = "מצלמה", subtitle = "אפשר להחליף לפני הטייק; בזמן צילום היא ננעלת") {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    CameraChoice(
                        label = "קדמית",
                        selected = cameraFacing == CameraFacing.Front,
                        onClick = { cameraFacing = CameraFacing.Front },
                        modifier = Modifier.weight(1f)
                    )
                    CameraChoice(
                        label = "אחורית",
                        selected = cameraFacing == CameraFacing.Back,
                        onClick = { cameraFacing = CameraFacing.Back },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        if (mode.usesBackground) {
            SectionCard(
                title = "רקע לביצוע",
                subtitle = if (mode == ProductionMode.CameraWithBackground) {
                    "הרקע נשמר כשכבה נפרדת; חיתוך הדמות והרכבת הקליפ יבוצעו ללא פגיעה בצילום המקורי"
                } else {
                    "בחר רקע מוכן או תמונה/וידאו מהטלפון"
                }
            ) {
                BackgroundPreviewSurface(
                    background = background,
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(aspectRatio.ratio)
                        .clip(RoundedCornerShape(16.dp))
                )

                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(listOf("הכול") + BuiltInBackgrounds.categories) { category ->
                        FilterChip(
                            selected = backgroundCategory == category,
                            onClick = { backgroundCategory = category },
                            label = { Text(category) }
                        )
                    }
                }

                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(BuiltInBackgrounds.inCategory(backgroundCategory), key = { it.id }) { preset ->
                        BackgroundPresetCard(
                            preset = preset,
                            selected = background.type == VisualBackgroundType.BuiltIn && background.id == preset.id,
                            onClick = {
                                background = VisualBackground(
                                    type = VisualBackgroundType.BuiltIn,
                                    id = preset.id,
                                    title = preset.title
                                )
                            }
                        )
                    }
                }

                OutlinedButton(
                    onClick = {
                        backgroundPicker.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)
                        )
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.PhotoLibrary, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("בחר תמונה או וידאו מהטלפון")
                }

                if (background.type == VisualBackgroundType.Image || background.type == VisualBackgroundType.Video) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF22C55E))
                        Spacer(Modifier.width(8.dp))
                        Text(background.title ?: "קובץ נבחר", fontWeight = FontWeight.Bold)
                    }
                }
                pickerMessage?.let {
                    Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        SceneSummary(
            mode = mode,
            aspectRatio = aspectRatio,
            cameraFacing = cameraFacing,
            background = background
        )

        Button(
            onClick = {
                onContinue(
                    VisualScene(
                        mode = mode,
                        aspectRatio = aspectRatio,
                        cameraFacing = cameraFacing,
                        background = if (mode.usesBackground) background else VisualBackground()
                    )
                )
            },
            modifier = Modifier.fillMaxWidth().heightIn(min = 58.dp),
            shape = RoundedCornerShape(18.dp)
        ) {
            Text("מוכן — עבור להקלטה", style = MaterialTheme.typography.titleMedium)
        }
    }
}

@Composable
private fun SectionCard(
    title: String,
    subtitle: String,
    content: @Composable () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = GraphiteElevated)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            content()
        }
    }
}

@Composable
private fun CameraChoice(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.clickable(onClick = onClick),
        colors = CardDefaults.cardColors(
            containerColor = if (selected) ElectricViolet.copy(alpha = 0.22f) else Color(0xFF15171D)
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(Icons.Default.Cameraswitch, contentDescription = null, tint = if (selected) WarmGold else Color.White)
            Spacer(Modifier.width(8.dp))
            Text(label, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
        }
    }
}

@Composable
private fun BackgroundPresetCard(
    preset: BuiltInBackgroundPreset,
    selected: Boolean,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier.width(156.dp).clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = if (selected) ElectricViolet.copy(alpha = 0.18f) else Color(0xFF121419)),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(104.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(preset.topColorHex), Color(preset.bottomColorHex))
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .width(64.dp)
                        .height(3.dp)
                        .background(Color(preset.accentColorHex), RoundedCornerShape(99.dp))
                )
            }
            Text(preset.title, fontWeight = FontWeight.Bold, maxLines = 2)
            Text(preset.category, style = MaterialTheme.typography.bodySmall, color = Color(preset.accentColorHex))
        }
    }
}

@Composable
private fun SceneSummary(
    mode: ProductionMode,
    aspectRatio: OutputAspectRatio,
    cameraFacing: CameraFacing,
    background: VisualBackground
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = ElectricViolet.copy(alpha = 0.10f))
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Collections, contentDescription = null, tint = WarmGold)
                Spacer(Modifier.width(8.dp))
                Text("סיכום הפקה", fontWeight = FontWeight.Bold)
            }
            Text("פורמט: ${aspectRatio.label}")
            if (mode.usesCamera) Text("מצלמה: ${if (cameraFacing == CameraFacing.Front) "קדמית" else "אחורית"}")
            if (mode.usesBackground) Text("רקע: ${background.title ?: "ללא"}")
            Text(
                "הקול, המצלמה, הפלייבק והרקע נשמרים בנפרד כדי שהעריכה תישאר הפיכה.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

private fun modeSubtitle(mode: ProductionMode): String = when (mode) {
    ProductionMode.Camera -> "צילום חי + הקלטת קול איכותית"
    ProductionMode.Background -> "קליפ עם רקע לבחירה + הקלטת קול איכותית"
    ProductionMode.CameraWithBackground -> "מצלמה + שכבת רקע לעריכה מאוחרת"
}
