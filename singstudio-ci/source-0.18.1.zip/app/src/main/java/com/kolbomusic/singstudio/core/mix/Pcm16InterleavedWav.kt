package com.kolbomusic.singstudio.core.mix

import java.io.BufferedOutputStream
import java.io.Closeable
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import kotlin.math.roundToInt

internal class Pcm16InterleavedWavReader(file: File) : Closeable {
    private val raf = RandomAccessFile(file, "r")
    val sampleRate: Int
    val channels: Int
    val frameCount: Long
    private val dataOffset: Long
    private val dataSize: Long
    private var byteBuffer = ByteArray(16 * 1024)

    init {
        require(file.exists() && file.length() >= 44L) { "קובץ WAV חסר או פגום" }
        require(readAscii(4) == "RIFF") { "פורמט WAV לא נתמך" }
        raf.skipBytes(4)
        require(readAscii(4) == "WAVE") { "פורמט WAV לא נתמך" }
        var format = 0
        var foundChannels = 0
        var foundRate = 0
        var bits = 0
        var foundDataOffset = -1L
        var foundDataSize = 0L
        while (raf.filePointer + 8L <= raf.length()) {
            val chunkId = readAscii(4)
            val chunkSize = readUInt32LE()
            val chunkStart = raf.filePointer
            when (chunkId) {
                "fmt " -> {
                    format = readUInt16LE()
                    foundChannels = readUInt16LE()
                    foundRate = readUInt32LE().toInt()
                    raf.skipBytes(6)
                    bits = readUInt16LE()
                }
                "data" -> {
                    foundDataOffset = raf.filePointer
                    foundDataSize = minOf(chunkSize, raf.length() - raf.filePointer)
                    break
                }
            }
            raf.seek(chunkStart + chunkSize + (chunkSize and 1L))
        }
        require(format == 1 && bits == 16) { "נדרש WAV PCM16" }
        require(foundChannels in 1..2) { "נתמכים Mono/Stereo בלבד" }
        require(foundRate in 8_000..192_000) { "קצב דגימה לא תקין" }
        require(foundDataOffset >= 0L && foundDataSize > 0L) { "WAV ללא נתוני אודיו" }
        channels = foundChannels
        sampleRate = foundRate
        dataOffset = foundDataOffset
        val blockAlign = channels * 2L
        dataSize = foundDataSize - (foundDataSize % blockAlign)
        frameCount = dataSize / blockAlign
    }

    fun readFrames(startFrame: Long, output: FloatArray, outputOffsetSamples: Int, requestedFrames: Int): Int {
        if (startFrame < 0L || startFrame >= frameCount || requestedFrames <= 0) return 0
        val available = minOf(requestedFrames.toLong(), frameCount - startFrame).toInt()
        val bytesPerFrame = channels * 2
        val bytesWanted = available * bytesPerFrame
        if (byteBuffer.size < minOf(bytesWanted, 128 * 1024)) {
            byteBuffer = ByteArray(minOf(bytesWanted, 128 * 1024))
        }
        raf.seek(dataOffset + startFrame * bytesPerFrame)
        var framesRemaining = available
        var out = outputOffsetSamples
        while (framesRemaining > 0) {
            val framesThisRead = minOf(framesRemaining, byteBuffer.size / bytesPerFrame)
            val byteCount = framesThisRead * bytesPerFrame
            val bytesRead = raf.read(byteBuffer, 0, byteCount)
            if (bytesRead <= 0) break
            val framesRead = bytesRead / bytesPerFrame
            var bi = 0
            repeat(framesRead) {
                repeat(channels) {
                    val lo = byteBuffer[bi].toInt() and 0xFF
                    val hi = byteBuffer[bi + 1].toInt() shl 8
                    output[out++] = (lo or hi).toShort() / 32768f
                    bi += 2
                }
            }
            framesRemaining -= framesRead
            if (framesRead < framesThisRead) break
        }
        return available - framesRemaining
    }

    override fun close() = raf.close()

    private fun readAscii(count: Int): String = ByteArray(count).also(raf::readFully).toString(Charsets.US_ASCII)
    private fun readUInt16LE(): Int = raf.readUnsignedByte() or (raf.readUnsignedByte() shl 8)
    private fun readUInt32LE(): Long {
        val b0 = raf.readUnsignedByte().toLong()
        val b1 = raf.readUnsignedByte().toLong()
        val b2 = raf.readUnsignedByte().toLong()
        val b3 = raf.readUnsignedByte().toLong()
        return b0 or (b1 shl 8) or (b2 shl 16) or (b3 shl 24)
    }
}

internal class Pcm16InterleavedWavWriter(
    private val destination: File,
    private val sampleRate: Int,
    private val channels: Int
) : Closeable {
    private val temp = File(destination.parentFile, destination.name + ".partial")
    private val fos: FileOutputStream
    private val out: BufferedOutputStream
    private val bytes = ByteArray(16 * 1024)
    private var dataBytes = 0L
    private var finished = false

    init {
        require(sampleRate in 8_000..192_000)
        require(channels in 1..2)
        destination.parentFile?.mkdirs()
        temp.delete()
        fos = FileOutputStream(temp)
        out = BufferedOutputStream(fos, 64 * 1024)
        writeHeader()
    }

    fun writeInterleaved(samples: FloatArray, offsetSamples: Int, sampleCount: Int) {
        check(!finished)
        var index = offsetSamples
        val end = minOf(samples.size, offsetSamples + sampleCount)
        var bi = 0
        while (index < end) {
            val value = (samples[index].coerceIn(-1f, 0.999969f) * 32768f)
                .roundToInt().coerceIn(-32768, 32767)
            bytes[bi++] = (value and 0xFF).toByte()
            bytes[bi++] = ((value ushr 8) and 0xFF).toByte()
            if (bi >= bytes.size - 1) {
                out.write(bytes, 0, bi)
                dataBytes += bi
                bi = 0
            }
            index++
        }
        if (bi > 0) {
            out.write(bytes, 0, bi)
            dataBytes += bi
        }
    }

    fun commit(): File {
        check(!finished)
        return try {
            out.flush()
            fos.fd.sync()
            out.close()
            RandomAccessFile(temp, "rw").use { raf ->
                raf.seek(4L); raf.writeUInt32LE(36L + dataBytes)
                raf.seek(40L); raf.writeUInt32LE(dataBytes)
                raf.fd.sync()
            }
            destination.delete()
            runCatching {
                Files.move(temp.toPath(), destination.toPath(), StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING)
            }.getOrElse {
                Files.move(temp.toPath(), destination.toPath(), StandardCopyOption.REPLACE_EXISTING)
            }
            finished = true
            destination
        } catch (error: Throwable) {
            finished = true
            runCatching { out.close() }
            temp.delete()
            throw error
        }
    }

    override fun close() {
        if (!finished) {
            finished = true
            runCatching { out.close() }
            temp.delete()
        }
    }

    private fun writeHeader() {
        val blockAlign = channels * 2
        val byteRate = sampleRate.toLong() * blockAlign
        out.write("RIFF".toByteArray(Charsets.US_ASCII)); out.writeUInt32LE(0L)
        out.write("WAVE".toByteArray(Charsets.US_ASCII))
        out.write("fmt ".toByteArray(Charsets.US_ASCII)); out.writeUInt32LE(16L)
        out.writeUInt16LE(1); out.writeUInt16LE(channels); out.writeUInt32LE(sampleRate.toLong())
        out.writeUInt32LE(byteRate); out.writeUInt16LE(blockAlign); out.writeUInt16LE(16)
        out.write("data".toByteArray(Charsets.US_ASCII)); out.writeUInt32LE(0L)
    }

    private fun BufferedOutputStream.writeUInt16LE(value: Int) {
        write(value and 0xFF); write((value ushr 8) and 0xFF)
    }
    private fun BufferedOutputStream.writeUInt32LE(value: Long) {
        write((value and 0xFF).toInt()); write(((value ushr 8) and 0xFF).toInt())
        write(((value ushr 16) and 0xFF).toInt()); write(((value ushr 24) and 0xFF).toInt())
    }
    private fun RandomAccessFile.writeUInt32LE(value: Long) {
        write((value and 0xFF).toInt()); write(((value ushr 8) and 0xFF).toInt())
        write(((value ushr 16) and 0xFF).toInt()); write(((value ushr 24) and 0xFF).toInt())
    }
}
