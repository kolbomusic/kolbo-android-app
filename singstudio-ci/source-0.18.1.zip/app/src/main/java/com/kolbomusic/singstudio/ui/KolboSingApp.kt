package com.kolbomusic.singstudio.ui

import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.sizeIn
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.TextButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.kolbomusic.singstudio.core.editor.RestoredVideoProject
import com.kolbomusic.singstudio.core.editor.VideoProjectRestoreStore
import com.kolbomusic.singstudio.core.model.BuiltInBackgrounds
import com.kolbomusic.singstudio.core.model.CameraFacing
import com.kolbomusic.singstudio.core.model.OutputAspectRatio
import com.kolbomusic.singstudio.core.model.PlaybackSource
import com.kolbomusic.singstudio.core.model.ProductionMode
import com.kolbomusic.singstudio.core.model.VisualBackground
import com.kolbomusic.singstudio.core.model.VisualBackgroundType
import com.kolbomusic.singstudio.core.model.VisualScene
import com.kolbomusic.singstudio.core.playback.LocalMediaResolver
import com.kolbomusic.singstudio.core.preferences.AppPreferences
import com.kolbomusic.singstudio.core.preferences.AppPreferencesStore
import com.kolbomusic.singstudio.ui.playback.YouTubeBrowserScreen
import com.kolbomusic.singstudio.ui.accessibility.KolboAccessibilityPreferences
import com.kolbomusic.singstudio.ui.accessibility.LocalKolboAccessibility
import com.kolbomusic.singstudio.ui.library.LibraryScreen
import com.kolbomusic.singstudio.ui.onboarding.OnboardingScreen
import com.kolbomusic.singstudio.ui.recording.RecordingStudioScreen
import com.kolbomusic.singstudio.ui.setup.VisualSetupScreen
import com.kolbomusic.singstudio.ui.theme.ElectricViolet
import com.kolbomusic.singstudio.ui.theme.GraphiteElevated
import com.kolbomusic.singstudio.ui.theme.RecordRose
import com.kolbomusic.singstudio.ui.theme.WarmGold
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private enum class Screen { Home, Source, YouTubeBrowser, QuickSetup, ProductionMode, VisualSetup, Recording, Library, Accessibility }

@Composable
fun KolboSingApp() {
    val context = LocalContext.current
    val preferencesStore = remember { AppPreferencesStore(context.applicationContext) }
    val loadedPreferences by produceState<AppPreferences?>(initialValue = null, preferencesStore) {
        preferencesStore.preferences.collect { value = it }
    }
    val preferences = loadedPreferences

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        if (preferences == null) {
            Surface(modifier = Modifier.fillMaxSize()) {
                Box(contentAlignment = Alignment.Center) {
                    Text("קולבו סטודיו", color = WarmGold, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
                }
            }
            return@CompositionLocalProvider
        }

        val prefs = requireNotNull(preferences)
        val scope = rememberCoroutineScope()
        var onboardingLarge by remember(prefs.onboardingCompleted) { mutableStateOf(prefs.largeControls) }
        var onboardingReduceMotion by remember(prefs.onboardingCompleted) { mutableStateOf(prefs.reduceMotion) }

        if (!prefs.onboardingCompleted) {
            Surface(modifier = Modifier.fillMaxSize()) {
                OnboardingScreen(
                    largeControls = onboardingLarge,
                    reduceMotion = onboardingReduceMotion,
                    onLargeControlsChange = { onboardingLarge = it },
                    onReduceMotionChange = { onboardingReduceMotion = it },
                    onContinue = {
                        scope.launch { preferencesStore.completeOnboarding(onboardingLarge, onboardingReduceMotion) }
                    }
                )
            }
            return@CompositionLocalProvider
        }

        var screen by remember { mutableStateOf(Screen.Home) }
        var productionMode by remember { mutableStateOf(ProductionMode.Camera) }
        var playbackSource by remember { mutableStateOf<PlaybackSource?>(null) }
        var visualScene by remember { mutableStateOf<VisualScene?>(null) }
        var restoredProject by remember { mutableStateOf<RestoredVideoProject?>(null) }

        @Composable
        fun RenderScreen(current: Screen) {
            when (current) {
                Screen.Home -> HomeScreen(
                    onStart = { screen = Screen.Source },
                    onProjects = { screen = Screen.Library },
                    onAccessibility = { screen = Screen.Accessibility }
                )

                Screen.Accessibility -> AccessibilitySettingsScreen(
                    largeControls = prefs.largeControls,
                    reduceMotion = prefs.reduceMotion,
                    onBack = { screen = Screen.Home },
                    onLargeControls = { enabled ->
                        scope.launch { preferencesStore.updateAccessibility(enabled, prefs.reduceMotion) }
                    },
                    onReduceMotion = { enabled ->
                        scope.launch { preferencesStore.updateAccessibility(prefs.largeControls, enabled) }
                    }
                )

                Screen.Library -> LibraryScreen(
                    onBack = { screen = Screen.Home },
                    onOpenProject = { item ->
                        val path = item.projectPath
                        if (path == null) {
                            Toast.makeText(context, "לטייק הזה עדיין אין פרויקט עריכה שמור", Toast.LENGTH_SHORT).show()
                        } else {
                            scope.launch {
                                val result = withContext(Dispatchers.IO) {
                                    runCatching { VideoProjectRestoreStore.load(File(path)) }
                                }
                                result.onSuccess { project ->
                                    val source = project.playbackSource
                                    if (source == null) {
                                        Toast.makeText(context, "הפרויקט נטען, אך מקור הפלייבק חסר", Toast.LENGTH_LONG).show()
                                    } else {
                                        restoredProject = project
                                        playbackSource = source
                                        visualScene = project.scene
                                        productionMode = project.scene.mode
                                        screen = Screen.Recording
                                    }
                                }.onFailure { error ->
                                    Toast.makeText(context, error.message ?: "פתיחת הפרויקט נכשלה", Toast.LENGTH_LONG).show()
                                }
                            }
                        }
                    }
                )

                Screen.Source -> SourcePickerScreen(
                    onBack = { screen = Screen.Home },
                    onYouTube = { screen = Screen.YouTubeBrowser },
                    onLocalSource = { source ->
                        restoredProject = null
                        playbackSource = source
                        screen = Screen.QuickSetup
                    }
                )

                Screen.YouTubeBrowser -> YouTubeBrowserScreen(
                    onBack = { screen = Screen.Source },
                    onSelected = { source ->
                        restoredProject = null
                        playbackSource = source
                        screen = Screen.QuickSetup
                    }
                )

                Screen.QuickSetup -> QuickSetupScreen(
                    source = playbackSource,
                    onBack = { screen = Screen.Source },
                    onCamera = {
                        productionMode = ProductionMode.Camera
                        visualScene = VisualScene(
                            mode = ProductionMode.Camera,
                            aspectRatio = OutputAspectRatio.Portrait9x16,
                            cameraFacing = CameraFacing.Front
                        )
                        restoredProject = null
                        screen = Screen.Recording
                    },
                    onNoCamera = {
                        productionMode = ProductionMode.Background
                        val preset = BuiltInBackgrounds.presets.first()
                        visualScene = VisualScene(
                            mode = ProductionMode.Background,
                            aspectRatio = OutputAspectRatio.Portrait9x16,
                            background = VisualBackground(
                                type = VisualBackgroundType.BuiltIn,
                                id = preset.id,
                                title = preset.title
                            )
                        )
                        restoredProject = null
                        screen = Screen.Recording
                    },
                    onMoreOptions = { screen = Screen.ProductionMode }
                )

                Screen.ProductionMode -> ProductionModeScreen(
                    source = playbackSource,
                    onBack = { screen = Screen.QuickSetup },
                    onMode = {
                        productionMode = it
                        screen = Screen.VisualSetup
                    }
                )

                Screen.VisualSetup -> VisualSetupScreen(
                    mode = productionMode,
                    onBack = { screen = Screen.QuickSetup },
                    onContinue = { scene ->
                        restoredProject = null
                        visualScene = scene
                        screen = Screen.Recording
                    }
                )

                Screen.Recording -> playbackSource?.let { source ->
                    visualScene?.let { scene ->
                        RecordingStudioScreen(
                            scene = scene,
                            playbackSource = source,
                            restoredProject = restoredProject,
                            onBack = {
                                if (restoredProject != null) {
                                    restoredProject = null
                                    screen = Screen.Library
                                } else {
                                    screen = Screen.QuickSetup
                                }
                            }
                        )
                    } ?: run { screen = Screen.QuickSetup }
                } ?: run { screen = Screen.Source }
            }
        }

        CompositionLocalProvider(
            LocalKolboAccessibility provides KolboAccessibilityPreferences(
                largeControls = prefs.largeControls,
                reduceMotion = prefs.reduceMotion
            )
        ) {
            Surface(modifier = Modifier.fillMaxSize()) {
                if (prefs.reduceMotion) {
                    RenderScreen(screen)
                } else {
                    AnimatedContent(targetState = screen, label = "main-nav") { current -> RenderScreen(current) }
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(onStart: () -> Unit, onProjects: () -> Unit, onAccessibility: () -> Unit) {
    val accessibility = LocalKolboAccessibility.current
    Column(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.statusBars)
            .windowInsetsPadding(WindowInsets.navigationBars)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 22.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "KOLBO STUDIO",
                style = MaterialTheme.typography.titleLarge,
                color = WarmGold,
                fontWeight = FontWeight.ExtraBold
            )
            Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = "אולפן חכם",
                tint = ElectricViolet
            )
        }

        Spacer(Modifier.height(62.dp))

        Box(
            modifier = Modifier
                .background(ElectricViolet.copy(alpha = 0.14f), RoundedCornerShape(999.dp))
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Mic,
                contentDescription = null,
                tint = ElectricViolet,
                modifier = Modifier.height(64.dp)
            )
        }

        Spacer(Modifier.height(30.dp))
        Text(
            text = "בחר שיר, לחץ הקלטה — ואנחנו נדאג לכל השאר.",
            style = MaterialTheme.typography.displaySmall,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(12.dp))
        Text(
            text = "מסלול פשוט: בוחרים שיר, שרים, ובסיום מקבלים סרטון מוכן לשמירה.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )

        Spacer(Modifier.height(34.dp))
        Button(
            onClick = onStart,
            modifier = Modifier.fillMaxWidth().heightIn(min = if (accessibility.largeControls) 72.dp else 56.dp),
            shape = RoundedCornerShape(18.dp),
            colors = ButtonDefaults.buttonColors(containerColor = ElectricViolet)
        ) {
            Icon(Icons.Default.Mic, contentDescription = null)
            Text("  בחר שיר והתחל", style = MaterialTheme.typography.titleLarge)
        }

        Spacer(Modifier.height(14.dp))
        ActionCard(
            title = "היצירות שלי",
            subtitle = "טייקים, טיוטות וסרטונים מוכנים",
            icon = Icons.Default.FolderOpen,
            onClick = onProjects
        )
        Spacer(Modifier.height(6.dp))
        TextButton(
            onClick = onAccessibility,
            modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)
        ) {
            Text("נגישות", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun AccessibilitySettingsScreen(
    largeControls: Boolean,
    reduceMotion: Boolean,
    onBack: () -> Unit,
    onLargeControls: (Boolean) -> Unit,
    onReduceMotion: (Boolean) -> Unit
) {
    StudioPage(
        title = "נגישות ונוחות",
        subtitle = "ההגדרות נשמרות אוטומטית.",
        onBack = onBack
    ) {
        AccessibilityToggleCard(
            title = "כפתורים גדולים",
            subtitle = "מגדיל את אזורי הלחיצה בפעולות המרכזיות",
            checked = largeControls,
            onChecked = onLargeControls
        )
        AccessibilityToggleCard(
            title = "הפחתת אנימציות",
            subtitle = "מעברים רגועים יותר ופחות תנועה על המסך",
            checked = reduceMotion,
            onChecked = onReduceMotion
        )
        Text(
            "האפליקציה תומכת גם בהגדלת גופן של Android וב־TalkBack.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun AccessibilityToggleCard(
    title: String,
    subtitle: String,
    checked: Boolean,
    onChecked: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .sizeIn(minHeight = 88.dp)
            .semantics { contentDescription = "$title. $subtitle" },
        colors = CardDefaults.cardColors(containerColor = GraphiteElevated),
        shape = RoundedCornerShape(22.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(checked = checked, onCheckedChange = onChecked)
        }
    }
}

@Composable
private fun SourcePickerScreen(
    onBack: () -> Unit,
    onYouTube: () -> Unit,
    onLocalSource: (PlaybackSource) -> Unit
) {
    val context = LocalContext.current
    var pickerError by remember { mutableStateOf<String?>(null) }
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            runCatching { LocalMediaResolver.resolve(context, uri) }
                .onSuccess {
                    pickerError = null
                    onLocalSource(it)
                }
                .onFailure { pickerError = it.message ?: "לא ניתן לפתוח את הקובץ" }
        }
    }

    StudioPage(
        title = "בחר שיר",
        subtitle = "אפשר לבחור מ־YouTube או מהטלפון.",
        onBack = onBack
    ) {
        ActionCard(
            title = "YouTube",
            subtitle = "חפש ובחר שיר או קריוקי",
            icon = Icons.Default.MusicNote,
            accent = RecordRose,
            onClick = onYouTube
        )
        ActionCard(
            title = "מהטלפון",
            subtitle = "בחר קובץ אודיו או וידאו",
            icon = Icons.Default.MusicNote,
            accent = WarmGold,
            onClick = { filePicker.launch(arrayOf("audio/*", "video/*")) }
        )
        pickerError?.let {
            Text(it, color = RecordRose, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun QuickSetupScreen(
    source: PlaybackSource?,
    onBack: () -> Unit,
    onCamera: () -> Unit,
    onNoCamera: () -> Unit,
    onMoreOptions: () -> Unit
) {
    StudioPage(
        title = "איך תרצה להקליט?",
        subtitle = source?.title ?: "בחר מצב פשוט להתחלה",
        onBack = onBack
    ) {
        ActionCard(
            title = "עם מצלמה",
            subtitle = "מצלמה קדמית · וידאו אנכי · מומלץ",
            icon = Icons.Default.Videocam,
            accent = RecordRose,
            onClick = onCamera
        )
        ActionCard(
            title = "בלי מצלמה",
            subtitle = "הקול והפלייבק עם רקע נקי",
            icon = Icons.Default.MusicNote,
            accent = WarmGold,
            onClick = onNoCamera
        )
        TextButton(
            onClick = onMoreOptions,
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 56.dp)
                .semantics { contentDescription = "אפשרויות נוספות לצילום ולעיצוב" }
        ) {
            Text("אפשרויות נוספות", fontWeight = FontWeight.Bold)
        }
        Text(
            "אפשר לשנות מצלמה, רקע ופורמט רק אם רוצים. ברירת המחדל כבר מוכנה לשירה.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun ProductionModeScreen(
    source: PlaybackSource?,
    onBack: () -> Unit,
    onMode: (ProductionMode) -> Unit
) {
    StudioPage(
        title = "איך ייראה הביצוע?",
        subtitle = source?.let { "פלייבק: ${it.title}\nהקול נשמר כהקלטת מקור נפרדת כדי שכל עריכה תישאר הפיכה." }
            ?: "בחר מצב הפקה.",
        onBack = onBack
    ) {
        ActionCard(
            title = "צילום חי",
            subtitle = "המצלמה מצלמת אותך בזמן השירה",
            icon = Icons.Default.Videocam,
            accent = RecordRose,
            onClick = { onMode(ProductionMode.Camera) }
        )
        ActionCard(
            title = "רקע / תמונה",
            subtitle = "בחר רקע מוכן או קובץ מהטלפון",
            icon = Icons.Default.PhotoLibrary,
            accent = WarmGold,
            onClick = { onMode(ProductionMode.Background) }
        )
        ActionCard(
            title = "צילום + רקע",
            subtitle = "שלב את עצמך בתוך סצנה מעוצבת",
            icon = Icons.Default.AutoAwesome,
            accent = ElectricViolet,
            onClick = { onMode(ProductionMode.CameraWithBackground) }
        )
    }
}

@Composable
private fun StudioPage(
    title: String,
    subtitle: String,
    onBack: () -> Unit,
    content: @Composable () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.statusBars)
            .windowInsetsPadding(WindowInsets.navigationBars)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack, modifier = Modifier.sizeIn(minWidth = 56.dp, minHeight = 56.dp)) {
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = "חזרה")
            }
            Text(text = "קולבו סטודיו", color = WarmGold, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(22.dp))
        Text(title, style = MaterialTheme.typography.headlineMedium, modifier = Modifier.semantics { heading() })
        Spacer(Modifier.height(8.dp))
        Text(
            subtitle,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(24.dp))
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            content()
        }
    }
}

@Composable
private fun ActionCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accent: Color = ElectricViolet,
    onClick: () -> Unit
) {
    val accessibility = LocalKolboAccessibility.current
    Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .sizeIn(minHeight = if (accessibility.largeControls) 88.dp else 72.dp)
            .semantics {
                role = Role.Button
                contentDescription = "$title. $subtitle"
            },
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = GraphiteElevated)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .background(accent.copy(alpha = 0.16f), RoundedCornerShape(16.dp))
                    .padding(14.dp)
            ) {
                Icon(icon, contentDescription = null, tint = accent)
            }
            Column(modifier = Modifier.weight(1f).padding(horizontal = 14.dp)) {
                Text(title, style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(4.dp))
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
