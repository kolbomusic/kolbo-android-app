@file:androidx.annotation.OptIn(
    androidx.media3.common.util.UnstableApi::class,
    androidx.media3.common.util.ExperimentalApi::class
)

package com.kolbomusic.singstudio.core.export

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.effect.MultipleInputVideoGraph
import androidx.media3.transformer.CompositionPlayer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Exact Composition preview where Media3 supports it. For multiple visual inputs Media3's
 * preview API is still experimental; failures are surfaced to the UI and never affect export.
 */
class CompositionPreviewEngine(context: Context) {
    private val appContext = context.applicationContext
    private val handler = Handler(Looper.getMainLooper())
    private val _state = MutableStateFlow(CompositionPreviewState())
    val state: StateFlow<CompositionPreviewState> = _state.asStateFlow()

    var player: CompositionPlayer? = null
        private set

    fun beginPreparing(message: String = "מכין תצוגה מקדימה…") {
        releasePlayer(resetState = false)
        _state.value = CompositionPreviewState(preparing = true, message = message)
    }

    fun showError(message: String) {
        releasePlayer(resetState = false)
        _state.value = CompositionPreviewState(errorMessage = message)
    }

    fun prepare(prepared: CompositionFactory.PreparedComposition) {
        check(Looper.myLooper() == Looper.getMainLooper()) { "Composition preview must run on main thread" }
        releasePlayer(resetState = false)
        _state.value = CompositionPreviewState(
            preparing = true,
            multipleVideoInputs = prepared.containsMultipleVideoInputs,
            message = "מכין תצוגה מקדימה…"
        )
        runCatching {
            val builder = CompositionPlayer.Builder(appContext)
            if (prepared.containsMultipleVideoInputs) {
                builder.setVideoGraphFactory(MultipleInputVideoGraph.Factory())
            }
            builder.build().also { previewPlayer ->
                previewPlayer.addListener(object : Player.Listener {
                    override fun onPlaybackStateChanged(playbackState: Int) {
                        val ready = playbackState == Player.STATE_READY
                        val ended = playbackState == Player.STATE_ENDED
                        _state.value = _state.value.copy(
                            preparing = !ready && !ended && playbackState != Player.STATE_IDLE,
                            ready = ready || ended,
                            playing = previewPlayer.isPlaying,
                            durationMs = previewPlayer.duration.coerceAtLeast(0L),
                            message = when {
                                ended -> "התצוגה המקדימה הסתיימה"
                                ready -> "התצוגה המקדימה מוכנה"
                                else -> _state.value.message
                            },
                            errorMessage = null
                        )
                        if (ready) startProgressPolling()
                    }

                    override fun onIsPlayingChanged(isPlaying: Boolean) {
                        _state.value = _state.value.copy(playing = isPlaying)
                        if (isPlaying) startProgressPolling()
                    }

                    override fun onPlayerError(error: PlaybackException) {
                        stopProgressPolling()
                        _state.value = _state.value.copy(
                            preparing = false,
                            ready = false,
                            playing = false,
                            errorMessage = error.message ?: "תצוגת Composition נכשלה"
                        )
                    }
                })
                previewPlayer.setComposition(prepared.composition)
                previewPlayer.prepare()
            }
        }.onSuccess { created ->
            player = created
        }.onFailure { error ->
            _state.value = _state.value.copy(
                preparing = false,
                ready = false,
                playing = false,
                errorMessage = error.message ?: "לא ניתן להכין תצוגה מקדימה"
            )
        }
    }

    fun togglePlayback() {
        val current = player ?: return
        if (current.isPlaying) current.pause() else {
            if (current.playbackState == Player.STATE_ENDED) current.seekTo(0L)
            current.play()
        }
    }

    fun seekTo(positionMs: Long) {
        player?.seekTo(positionMs.coerceAtLeast(0L))
    }

    fun invalidate() {
        releasePlayer(resetState = true)
    }

    fun release() {
        releasePlayer(resetState = true)
    }

    private val progressRunnable = object : Runnable {
        override fun run() {
            val current = player ?: return
            _state.value = _state.value.copy(
                positionMs = current.currentPosition.coerceAtLeast(0L),
                durationMs = current.duration.coerceAtLeast(0L),
                playing = current.isPlaying
            )
            if (current.playbackState != Player.STATE_IDLE) handler.postDelayed(this, 250L)
        }
    }

    private fun startProgressPolling() {
        stopProgressPolling()
        handler.post(progressRunnable)
    }

    private fun stopProgressPolling() {
        handler.removeCallbacks(progressRunnable)
    }

    private fun releasePlayer(resetState: Boolean) {
        stopProgressPolling()
        runCatching { player?.release() }
        player = null
        if (resetState) _state.value = CompositionPreviewState()
    }
}
