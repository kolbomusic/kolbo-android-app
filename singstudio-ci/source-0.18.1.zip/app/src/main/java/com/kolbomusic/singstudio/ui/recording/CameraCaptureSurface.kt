package com.kolbomusic.singstudio.ui.recording

import androidx.camera.view.PreviewView
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.kolbomusic.singstudio.core.camera.CameraCaptureEngine
import com.kolbomusic.singstudio.core.model.CameraFacing
import kotlinx.coroutines.flow.first

@Composable
fun CameraCaptureSurface(
    facing: CameraFacing,
    preferConcurrentVideoCompatibility: Boolean = false,
    modifier: Modifier = Modifier,
    onEngineReady: (CameraCaptureEngine) -> Unit,
    onError: (String) -> Unit = {}
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val engine = remember { CameraCaptureEngine(context.applicationContext) }
    val previewView = remember {
        PreviewView(context).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
    }

    LaunchedEffect(facing, preferConcurrentVideoCompatibility, lifecycleOwner, previewView) {
        engine.rebind(
            lifecycleOwner,
            previewView,
            facing,
            preferConcurrentVideoCompatibility,
            onError
        )
        val ready = engine.state.first { it.bound || it.errorMessage != null }
        if (ready.bound) onEngineReady(engine)
    }

    DisposableEffect(engine) {
        onDispose { engine.release() }
    }

    AndroidView(
        factory = { previewView },
        modifier = modifier
    )
}
