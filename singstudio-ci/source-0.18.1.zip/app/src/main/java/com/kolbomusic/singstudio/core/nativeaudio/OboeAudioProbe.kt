package com.kolbomusic.singstudio.core.nativeaudio

data class LowLatencyAudioCapability(
    val available: Boolean,
    val api: String? = null,
    val sampleRate: Int? = null,
    val framesPerBurst: Int? = null,
    val bufferCapacityFrames: Int? = null,
    val rawReport: String
)

object OboeAudioProbe {
    private val nativeLoaded: Boolean = runCatching {
        System.loadLibrary("kolbo_audio")
        true
    }.getOrDefault(false)

    fun probe(): LowLatencyAudioCapability {
        if (!nativeLoaded) {
            return LowLatencyAudioCapability(false, rawReport = "FAIL|native-library-unavailable")
        }
        val report = runCatching { nativeProbe() }.getOrElse {
            return LowLatencyAudioCapability(false, rawReport = "FAIL|${it.message ?: "native-probe-error"}")
        }
        val fields = report.split('|')
        if (fields.firstOrNull() != "PASS") {
            return LowLatencyAudioCapability(false, rawReport = report)
        }
        val map = fields.drop(1).mapNotNull { token ->
            val index = token.indexOf('=')
            if (index <= 0) null else token.substring(0, index) to token.substring(index + 1)
        }.toMap()
        return LowLatencyAudioCapability(
            available = true,
            api = map["api"],
            sampleRate = map["sampleRate"]?.toIntOrNull(),
            framesPerBurst = map["framesPerBurst"]?.toIntOrNull(),
            bufferCapacityFrames = map["bufferCapacityFrames"]?.toIntOrNull(),
            rawReport = report
        )
    }

    private external fun nativeProbe(): String
}
