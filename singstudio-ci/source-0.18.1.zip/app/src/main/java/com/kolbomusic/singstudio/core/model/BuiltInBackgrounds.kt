package com.kolbomusic.singstudio.core.model

enum class BackgroundVisualStyle {
    MediterraneanStage,
    JerusalemNight,
    NeonCity,
    WeddingVelvet,
    DesertSunset,
    KaraokeClub,
    BlueWhiteStage,
    HennaGold,
    BeachSunset,
    PianoLounge,
    MoroccanArch,
    EventHall,
    NeonWave,
    FestivalLights
}

data class BuiltInBackgroundPreset(
    val id: String,
    val title: String,
    val category: String,
    val topColorHex: Long,
    val bottomColorHex: Long,
    val accentColorHex: Long,
    val visualStyle: BackgroundVisualStyle
)

object BuiltInBackgrounds {
    val presets = listOf(
        BuiltInBackgroundPreset("med_stage_gold", "במה ים־תיכונית זהב", "מזרחי", 0xFF160C22, 0xFF050507, 0xFFFFB020, BackgroundVisualStyle.MediterraneanStage),
        BuiltInBackgroundPreset("henna_gold", "חינה זהב וחום", "מזרחי", 0xFF4A1C0A, 0xFF100704, 0xFFFFD27A, BackgroundVisualStyle.HennaGold),
        BuiltInBackgroundPreset("moroccan_arch", "קשתות מרוקאיות", "מזרחי", 0xFF32102E, 0xFF080408, 0xFFFFC66D, BackgroundVisualStyle.MoroccanArch),
        BuiltInBackgroundPreset("jerusalem_night", "ירושלים בלילה", "ישראלי", 0xFF17213A, 0xFF080B13, 0xFFE8C27A, BackgroundVisualStyle.JerusalemNight),
        BuiltInBackgroundPreset("blue_white_stage", "במה כחול־לבן", "ישראלי", 0xFF102A56, 0xFF030812, 0xFFFFFFFF, BackgroundVisualStyle.BlueWhiteStage),
        BuiltInBackgroundPreset("desert_sunset", "שקיעה מדברית", "ישראלי", 0xFF5F214C, 0xFF2A150A, 0xFFFFA34E, BackgroundVisualStyle.DesertSunset),
        BuiltInBackgroundPreset("beach_sunset", "שקיעה ים־תיכונית", "ישראלי", 0xFF50306F, 0xFF08213A, 0xFFFFB35C, BackgroundVisualStyle.BeachSunset),
        BuiltInBackgroundPreset("wedding_velvet", "אולם קטיפה יוקרתי", "אירועים", 0xFF40121C, 0xFF090607, 0xFFFFD38A, BackgroundVisualStyle.WeddingVelvet),
        BuiltInBackgroundPreset("event_hall", "אולם אירועים מודרני", "אירועים", 0xFF202435, 0xFF06070A, 0xFFFFD998, BackgroundVisualStyle.EventHall),
        BuiltInBackgroundPreset("festival_lights", "חפלה ואורות", "אירועים", 0xFF36113B, 0xFF080409, 0xFFFF6B9A, BackgroundVisualStyle.FestivalLights),
        BuiltInBackgroundPreset("club_purple", "מועדון קריוקי סגול", "קריוקי", 0xFF3A1366, 0xFF08060D, 0xFFC26CFF, BackgroundVisualStyle.KaraokeClub),
        BuiltInBackgroundPreset("piano_lounge", "לאונג׳ פסנתר", "קריוקי", 0xFF17202B, 0xFF050608, 0xFFE6C982, BackgroundVisualStyle.PianoLounge),
        BuiltInBackgroundPreset("telaviv_neon", "לילה אורבני ניאון", "מודרני", 0xFF34105C, 0xFF07111C, 0xFF55D6FF, BackgroundVisualStyle.NeonCity),
        BuiltInBackgroundPreset("neon_wave", "גלי ניאון", "מודרני", 0xFF11164B, 0xFF070510, 0xFF41F5D5, BackgroundVisualStyle.NeonWave)
    )

    val categories: List<String> = presets.map { it.category }.distinct()

    fun byId(id: String?): BuiltInBackgroundPreset? = presets.firstOrNull { it.id == id }
    fun inCategory(category: String?): List<BuiltInBackgroundPreset> =
        if (category.isNullOrBlank() || category == "הכול") presets else presets.filter { it.category == category }
}
