package com.kolbomusic.singstudio.core.dsp

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sqrt

internal class SpectralNoiseReducer(
    private val fftSize: Int = 1024,
    private val hopSize: Int = 512
) {
    private val window = DoubleArray(fftSize) { i -> sqrt(0.5 - 0.5 * cos(2.0 * PI * i / fftSize)) }

    fun process(samples: FloatArray, sampleRate: Int, strength: Double): FloatArray {
        if (samples.size < fftSize || strength <= 0.01) return samples.copyOf()
        val noise = estimateNoiseSpectrum(samples, sampleRate)
        val out = FloatArray(samples.size)
        val real = DoubleArray(fftSize)
        val imag = DoubleArray(fftSize)
        val previousGain = DoubleArray(fftSize / 2 + 1) { 1.0 }
        val oversubtraction = 1.15 + strength * 1.85
        val minGain = (0.26 - strength * 0.18).coerceIn(0.06, 0.24)

        var start = -hopSize
        while (start < samples.size) {
            java.util.Arrays.fill(real, 0.0)
            java.util.Arrays.fill(imag, 0.0)
            for (i in 0 until fftSize) {
                val index = start + i
                if (index in samples.indices) real[i] = samples[index] * window[i]
            }
            Radix2Fft.transform(real, imag)
            for (bin in 0..fftSize / 2) {
                val mag = hypot(real[bin], imag[bin]).coerceAtLeast(1e-12)
                val estimatedNoise = noise[bin] * oversubtraction
                val rawGain = ((mag - estimatedNoise) / mag).coerceIn(minGain, 1.0)
                val smoothed = if (rawGain < previousGain[bin]) {
                    0.72 * previousGain[bin] + 0.28 * rawGain
                } else {
                    0.42 * previousGain[bin] + 0.58 * rawGain
                }
                previousGain[bin] = smoothed
                real[bin] *= smoothed
                imag[bin] *= smoothed
                if (bin > 0 && bin < fftSize / 2) {
                    val mirror = fftSize - bin
                    real[mirror] *= smoothed
                    imag[mirror] *= smoothed
                }
            }
            Radix2Fft.transform(real, imag, inverse = true)
            for (i in 0 until fftSize) {
                val index = start + i
                if (index in out.indices) {
                    out[index] += (real[i] * window[i]).toFloat()
                }
            }
            start += hopSize
        }

        for (i in out.indices) out[i] = out[i].coerceIn(-1.25f, 1.25f)
        return out
    }

    private fun estimateNoiseSpectrum(samples: FloatArray, sampleRate: Int): DoubleArray {
        val profileSamples = minOf(samples.size, (sampleRate * 1.25).toInt())
        val frameCount = ((profileSamples - fftSize).coerceAtLeast(0) / hopSize + 1).coerceAtLeast(1)
        data class NoiseFrame(val rms: Double, val magnitudes: DoubleArray)
        val frames = ArrayList<NoiseFrame>(frameCount)
        val real = DoubleArray(fftSize)
        val imag = DoubleArray(fftSize)
        for (frame in 0 until frameCount) {
            val frameStart = frame * hopSize
            if (frameStart + fftSize > samples.size) break
            var energy = 0.0
            for (i in 0 until fftSize) {
                val value = samples[frameStart + i].toDouble()
                energy += value * value
                real[i] = value * window[i]
                imag[i] = 0.0
            }
            Radix2Fft.transform(real, imag)
            val magnitudes = DoubleArray(fftSize / 2 + 1) { bin ->
                hypot(real[bin], imag[bin])
            }
            frames += NoiseFrame(kotlin.math.sqrt(energy / fftSize), magnitudes)
        }
        if (frames.isEmpty()) return DoubleArray(fftSize / 2 + 1) { 1e-10 }
        frames.sortBy { it.rms }
        val quietCount = (frames.size * 0.30).toInt().coerceIn(1, frames.size)
        val accum = DoubleArray(fftSize / 2 + 1)
        for (i in 0 until quietCount) {
            val frame = frames[i]
            for (bin in accum.indices) accum[bin] += frame.magnitudes[bin]
        }
        for (bin in accum.indices) accum[bin] = accum[bin] / quietCount + 1e-10
        return accum
    }
}
