package com.kolbomusic.singstudio.core.recording

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.kolbomusic.singstudio.core.model.RecordingPhase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class RecordingForegroundService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startCapture()
            ACTION_STOP -> stopCapture()
            else -> stopServiceCleanly()
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        serviceScope.cancel()
        super.onDestroy()
    }

    private fun startCapture() {
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("קולבו סטודיו")
            .setContentText("טייק בהקלטה")
            .setOngoing(true)
            .setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()

        val foregroundType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        } else {
            0
        }
        ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, foregroundType)

        serviceScope.launch {
            val recorder = RecordingRuntime.recorder(this@RecordingForegroundService)
            val startResult = recorder.start()
            if (startResult.isFailure) {
                stopServiceCleanly()
                return@launch
            }

            // If the capture loop itself fails, never leave a stale foreground
            // notification/service running after the audio engine has died.
            recorder.state
                .filter { it.phase == RecordingPhase.Error }
                .first()
            runCatching { recorder.stop() }
            stopServiceCleanly()
        }
    }

    private fun stopCapture() {
        serviceScope.launch {
            RecordingRuntime.recorder(this@RecordingForegroundService).stop()
            stopServiceCleanly()
        }
    }

    private fun stopServiceCleanly() {
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL_ID,
            "הקלטת טייק",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "מוצג בזמן שהמיקרופון מקליט טייק"
            setSound(null, null)
        }
        manager.createNotificationChannel(channel)
    }

    companion object {
        const val ACTION_START = "com.kolbomusic.singstudio.action.START_RECORDING"
        const val ACTION_STOP = "com.kolbomusic.singstudio.action.STOP_RECORDING"
        private const val CHANNEL_ID = "kolbo_recording"
        private const val NOTIFICATION_ID = 2102
    }
}
