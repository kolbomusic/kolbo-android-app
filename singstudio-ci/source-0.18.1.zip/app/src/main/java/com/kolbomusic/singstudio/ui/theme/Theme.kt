package com.kolbomusic.singstudio.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val KolboColorScheme = darkColorScheme(
    primary = ElectricVioletBright,
    onPrimary = Night,
    primaryContainer = GraphiteElevated,
    onPrimaryContainer = TextPrimary,
    secondary = WarmGold,
    onSecondary = Night,
    tertiary = Mint,
    background = Night,
    onBackground = TextPrimary,
    surface = Graphite,
    onSurface = TextPrimary,
    surfaceVariant = GraphiteElevated,
    onSurfaceVariant = TextSecondary,
    outline = Hairline,
    error = RecordRose
)

@Composable
fun KolboSingTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = KolboColorScheme,
        typography = KolboTypography,
        content = content
    )
}
