package com.kolbomusic.singstudio.core.model

enum class PlaybackSourceType {
    LocalAudio,
    LocalVideo,
    YouTube
}

data class PlaybackSource(
    val id: String,
    val type: PlaybackSourceType,
    val title: String,
    val uriString: String? = null,
    val mimeType: String? = null,
    val youtubeVideoId: String? = null
) {
    val isVideo: Boolean
        get() = type == PlaybackSourceType.LocalVideo || type == PlaybackSourceType.YouTube
}

data class PlaybackState(
    val prepared: Boolean = false,
    val playing: Boolean = false,
    val buffering: Boolean = false,
    val ended: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val startedElapsedRealtimeNs: Long? = null,
    val errorMessage: String? = null
)

data class PlaybackSyncMarker(
    val sourceId: String,
    val sourceType: String,
    val sourceTitle: String,
    val playbackPositionMs: Long,
    val startedElapsedRealtimeNs: Long
)
