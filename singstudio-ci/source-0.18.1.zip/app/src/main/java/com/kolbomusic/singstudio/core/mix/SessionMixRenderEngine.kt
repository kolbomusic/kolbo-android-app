package com.kolbomusic.singstudio.core.mix

import com.kolbomusic.singstudio.core.audio.WavFileTools
import com.kolbomusic.singstudio.core.dsp.PreviewSource
import com.kolbomusic.singstudio.core.dsp.RealtimeVocalFxProcessor
import com.kolbomusic.singstudio.core.dsp.VocalFxSettings
import org.json.JSONObject
import java.io.File
import kotlin.math.floor

class SessionMixRenderEngine {
    fun render(
        backingFile: File,
        rawVocalFile: File,
        processedVocalFile: File,
        playbackStartOffsetMs: Long,
        mixSettings: SessionMixSettings,
        fxSettings: VocalFxSettings,
        outputDirectory: File,
        onProgress: (Float) -> Unit = {}
    ): SessionMixRenderResult {
        val backingShaBefore = WavFileTools.sha256(backingFile)
        val rawShaBefore = WavFileTools.sha256(rawVocalFile)
        val processedShaBefore = WavFileTools.sha256(processedVocalFile)
        val safeMix = mixSettings.sanitized()
        val safeFx = fxSettings.sanitized()
        outputDirectory.mkdirs()
        val output = File(outputDirectory, "session-mix.wav")

        Pcm16InterleavedWavReader(backingFile).use { backing ->
            Pcm16InterleavedWavReader(rawVocalFile).use { raw ->
                Pcm16InterleavedWavReader(processedVocalFile).use { processed ->
                    val targetRate = backing.sampleRate
                    val rawStart = SessionMixMath.vocalStartFrame(playbackStartOffsetMs, raw.sampleRate)
                    val processedStart = SessionMixMath.vocalStartFrame(playbackStartOffsetMs, processed.sampleRate)
                    val fxProcessor = RealtimeVocalFxProcessor(targetRate)
                    val adaptiveBalance = AdaptiveVocalBalanceProcessor(targetRate)
                    val framesPerBlock = 1024
                    val backingBlock = FloatArray(framesPerBlock * backing.channels)
                    val vocalBlock = FloatArray(framesPerBlock)
                    val stereoOut = FloatArray(framesPerBlock * 2)
                    val selectedReader = if (safeMix.previewSource == PreviewSource.Raw) raw else processed
                    val selectedStart = if (safeMix.previewSource == PreviewSource.Raw) rawStart else processedStart
                    val playbackGain = safeMix.playbackGain
                    val vocalGain = safeMix.vocalGain
                    val masterGain = safeMix.masterGain
                    var frame = 0L
                    var activeAdaptiveBlocks = 0L
                    var minVocalRideDb = 0.0
                    var maxVocalRideDb = 0.0
                    var maxBackingDuckDb = 0.0

                    Pcm16InterleavedWavWriter(output, targetRate, 2).use { writer ->
                        while (frame < backing.frameCount) {
                            val count = minOf(framesPerBlock.toLong(), backing.frameCount - frame).toInt()
                            val read = backing.readFrames(frame, backingBlock, 0, count)
                            check(read > 0) { "קריאת הפלייבק נקטעה בזמן Render" }
                            readResampledMono(selectedReader, frame, targetRate, selectedStart, vocalBlock, read)
                            if (safeMix.previewSource == PreviewSource.Processed) {
                                fxProcessor.processInPlace(vocalBlock, 0, read, safeFx)
                            }
                            val adaptive = adaptiveBalance.balance(
                                backingInterleaved = backingBlock,
                                backingChannels = backing.channels,
                                vocalMono = vocalBlock,
                                frames = read,
                                basePlaybackGain = playbackGain,
                                baseVocalGain = vocalGain
                            )
                            if (adaptive.vocalActive) activeAdaptiveBlocks++
                            minVocalRideDb = minOf(minVocalRideDb, adaptive.vocalRideDb)
                            maxVocalRideDb = maxOf(maxVocalRideDb, adaptive.vocalRideDb)
                            maxBackingDuckDb = minOf(maxBackingDuckDb, adaptive.playbackDuckDb)
                            val adaptivePlaybackGain = playbackGain * adaptive.playbackGainMultiplier
                            val adaptiveVocalGain = vocalGain * adaptive.vocalGainMultiplier
                            var outIndex = 0
                            repeat(read) { i ->
                                val left: Float
                                val right: Float
                                if (backing.channels == 1) {
                                    left = backingBlock[i]
                                    right = backingBlock[i]
                                } else {
                                    left = backingBlock[i * 2]
                                    right = backingBlock[i * 2 + 1]
                                }
                                stereoOut[outIndex++] = SessionMixMath.mixChannel(
                                    left, vocalBlock[i], adaptivePlaybackGain, adaptiveVocalGain, masterGain
                                )
                                stereoOut[outIndex++] = SessionMixMath.mixChannel(
                                    right, vocalBlock[i], adaptivePlaybackGain, adaptiveVocalGain, masterGain
                                )
                            }
                            writer.writeInterleaved(stereoOut, 0, read * 2)
                            frame += read
                            if ((frame / framesPerBlock) % 16L == 0L || frame == backing.frameCount) {
                                onProgress(frame.toFloat() / backing.frameCount.toFloat())
                            }
                        }
                        writer.commit()
                    }

                    Pcm16InterleavedWavReader(output).use { mixed ->
                        check(mixed.channels == 2 && mixed.sampleRate == targetRate && mixed.frameCount > 0L)
                    }
                    check(backingShaBefore == WavFileTools.sha256(backingFile)) { "Backing integrity failed" }
                    check(rawShaBefore == WavFileTools.sha256(rawVocalFile)) { "RAW integrity failed" }
                    check(processedShaBefore == WavFileTools.sha256(processedVocalFile)) { "Processed integrity failed" }
                    val outputSha = WavFileTools.sha256(output)
                    val durationMs = backing.frameCount * 1000L / targetRate
                    File(outputDirectory, "session-mix.json").writeText(
                        JSONObject()
                            .put("schema", 1)
                            .put("engine", "KolboSessionMix")
                            .put("engineVersion", "0.17.0")
                            .put("sampleRate", targetRate)
                            .put("channels", 2)
                            .put("durationMs", durationMs)
                            .put("playbackStartOffsetMs", playbackStartOffsetMs)
                            .put("vocalGainDb", safeMix.vocalGainDb)
                            .put("playbackGainDb", safeMix.playbackGainDb)
                            .put("masterHeadroomDb", safeMix.masterHeadroomDb)
                            .put("previewSource", safeMix.previewSource.name)
                            .put("adaptiveBalance", true)
                            .put("adaptiveActiveBlocks", activeAdaptiveBlocks)
                            .put("adaptiveMinVocalRideDb", minVocalRideDb)
                            .put("adaptiveMaxVocalRideDb", maxVocalRideDb)
                            .put("adaptiveMaxBackingDuckDb", maxBackingDuckDb)
                            .put("outputFile", output.name)
                            .put("outputSha256", outputSha)
                            .toString(2),
                        Charsets.UTF_8
                    )
                    onProgress(1f)
                    return SessionMixRenderResult(output.absolutePath, outputSha, targetRate, durationMs)
                }
            }
        }
    }

    private fun readResampledMono(
        reader: Pcm16InterleavedWavReader,
        targetStartFrame: Long,
        targetSampleRate: Int,
        sourceStartFrame: Long,
        output: FloatArray,
        count: Int
    ) {
        output.fill(0f, 0, count)
        val range = SessionMixMath.requiredSourceWindow(
            targetStartFrame,
            count,
            targetSampleRate,
            reader.sampleRate,
            sourceStartFrame
        )
        if (range.isEmpty() || range.first >= reader.frameCount) return
        val first = range.first.coerceAtLeast(0L)
        val last = minOf(range.last, reader.frameCount - 1L)
        val framesNeeded = (last - first + 1L).toInt()
        val sourceSamples = FloatArray(framesNeeded * reader.channels)
        val framesRead = reader.readFrames(first, sourceSamples, 0, framesNeeded)
        if (framesRead <= 0) return
        fun monoAt(frameIndex: Int): Float {
            val safe = frameIndex.coerceIn(0, framesRead - 1)
            return if (reader.channels == 1) sourceSamples[safe]
            else (sourceSamples[safe * 2] + sourceSamples[safe * 2 + 1]) * 0.5f
        }
        repeat(count) { i ->
            val sourcePosition = SessionMixMath.sourcePositionForTargetFrame(
                targetStartFrame + i, targetSampleRate, reader.sampleRate, sourceStartFrame
            )
            if (sourcePosition < first || sourcePosition > last) return@repeat
            val local = sourcePosition - first
            val i0 = floor(local).toInt().coerceIn(0, framesRead - 1)
            val i1 = (i0 + 1).coerceIn(0, framesRead - 1)
            val frac = (local - i0).toFloat()
            output[i] = monoAt(i0) * (1f - frac) + monoAt(i1) * frac
        }
    }
}
