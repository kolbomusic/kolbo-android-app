package com.kolbomusic.singstudio.core.device

enum class ThermalLevel(val labelHe: String) {
    Unknown("לא ידוע"),
    Normal("תקין"),
    Warm("חם"),
    Severe("חם מאוד")
}

data class RuntimeHealthState(
    val batteryPercent: Int? = null,
    val powerSaveMode: Boolean = false,
    val thermalLevel: ThermalLevel = ThermalLevel.Unknown,
    val freeStorageBytes: Long = 0L,
    val checkedAtEpochMs: Long = 0L
) {
    val exportWarning: String?
        get() = when {
            thermalLevel == ThermalLevel.Severe -> "המכשיר חם מאוד. מומלץ לתת לו להתקרר לפני ייצוא ארוך כדי למנוע האטה או עצירה של המקודד."
            freeStorageBytes in 1 until 1_000_000_000L -> "נשאר פחות מ־1GB פנוי. ייצוא וידאו עלול להיכשל בגלל מקום אחסון."
            powerSaveMode -> "מצב חיסכון בסוללה פעיל; במכשירים מסוימים הייצוא עשוי להיות איטי יותר."
            batteryPercent != null && batteryPercent < 15 -> "הסוללה נמוכה. מומלץ לחבר מטען לפני ייצוא ארוך."
            else -> null
        }
}
