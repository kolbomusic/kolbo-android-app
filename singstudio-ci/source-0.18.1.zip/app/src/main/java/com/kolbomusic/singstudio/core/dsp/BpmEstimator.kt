package com.kolbomusic.singstudio.core.dsp

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Lightweight offline tempo estimator for decoded mono PCM.
 * It uses an onset-energy envelope followed by normalized autocorrelation.
 * The result is intentionally bounded to a karaoke-friendly 60..190 BPM range.
 */
object BpmEstimator {
    fun estimate(
        samples: FloatArray,
        sampleRate: Int,
        minBpm: Double = 60.0,
        maxBpm: Double = 190.0
    ): BpmEstimate? {
        if (samples.size < sampleRate * 4 || sampleRate <= 0) return null
        val hop = max(128, sampleRate / 200) // ~200 envelope points/sec
        val frames = samples.size / hop
        if (frames < 400) return null

        val energy = DoubleArray(frames)
        var si = 0
        for (frame in 0 until frames) {
            var sum = 0.0
            val end = minOf(samples.size, si + hop)
            var count = 0
            while (si < end) {
                val x = samples[si].toDouble()
                sum += x * x
                si++
                count++
            }
            energy[frame] = if (count > 0) sqrt(sum / count) else 0.0
        }

        // Positive spectral-energy change approximates onsets and suppresses sustained notes.
        val onset = DoubleArray(frames)
        var running = 0.0
        val smoothWindow = max(4, (200.0 * 0.12).toInt())
        for (i in energy.indices) {
            val previous = if (i == 0) 0.0 else energy[i - 1]
            val diff = max(0.0, energy[i] - previous)
            running += diff
            if (i >= smoothWindow) {
                val oldIndex = i - smoothWindow
                val oldPrevious = if (oldIndex == 0) 0.0 else energy[oldIndex - 1]
                running -= max(0.0, energy[oldIndex] - oldPrevious)
            }
            val baseline = running / minOf(i + 1, smoothWindow).coerceAtLeast(1)
            onset[i] = max(0.0, diff - baseline * 0.35)
        }

        val envelopeRate = sampleRate.toDouble() / hop
        val minLag = (envelopeRate * 60.0 / maxBpm).toInt().coerceAtLeast(1)
        val maxLag = (envelopeRate * 60.0 / minBpm).toInt().coerceAtMost(frames / 2)
        if (maxLag <= minLag) return null

        var bestLag = -1
        var bestScore = Double.NEGATIVE_INFINITY
        var secondScore = Double.NEGATIVE_INFINITY
        val start = frames / 10
        val end = frames - maxLag - 1
        if (end <= start) return null

        for (lag in minLag..maxLag) {
            var xy = 0.0
            var xx = 0.0
            var yy = 0.0
            var i = start
            while (i < end) {
                val a = onset[i]
                val b = onset[i + lag]
                xy += a * b
                xx += a * a
                yy += b * b
                i++
            }
            var score = if (xx > 1e-12 && yy > 1e-12) xy / sqrt(xx * yy) else 0.0

            // Gentle harmonic reinforcement prevents common half/double-tempo errors.
            val half = lag / 2
            if (half >= minLag) score += 0.08 * correlation(onset, half, start, end)
            val twice = lag * 2
            if (twice <= maxLag) score += 0.10 * correlation(onset, twice, start, end)

            if (score > bestScore) {
                secondScore = bestScore
                bestScore = score
                bestLag = lag
            } else if (score > secondScore) {
                secondScore = score
            }
        }
        if (bestLag <= 0 || bestScore <= 0.02) return null

        var bpm = 60.0 * envelopeRate / bestLag
        while (bpm < minBpm) bpm *= 2.0
        while (bpm > maxBpm) bpm /= 2.0
        if (bpm !in minBpm..maxBpm) return null

        val separation = if (bestScore > 0.0) ((bestScore - secondScore) / abs(bestScore)).coerceIn(0.0, 1.0) else 0.0
        val confidence = (bestScore.coerceIn(0.0, 1.0) * 0.75 + separation * 0.25).coerceIn(0.0, 1.0)
        return BpmEstimate(bpm, confidence)
    }

    private fun correlation(values: DoubleArray, lag: Int, start: Int, end: Int): Double {
        var xy = 0.0
        var xx = 0.0
        var yy = 0.0
        var i = start
        val safeEnd = minOf(end, values.size - lag)
        while (i < safeEnd) {
            val a = values[i]
            val b = values[i + lag]
            xy += a * b
            xx += a * a
            yy += b * b
            i++
        }
        return if (xx > 1e-12 && yy > 1e-12) xy / sqrt(xx * yy) else 0.0
    }
}
