package com.kolbomusic.singstudio.core.playback

import com.kolbomusic.singstudio.core.model.PlaybackState
import kotlinx.coroutines.flow.StateFlow

interface PlaybackControl {
    val state: StateFlow<PlaybackState>
    fun playFromStart()
    fun pause()
    fun seekTo(positionMs: Long)
    fun release()
}
