package com.kolbomusic.singstudio.core.export

import org.json.JSONObject
import java.io.File

object ExportMetadataStore {
    fun write(
        outputFile: File,
        plan: ExportPlan,
        verification: ExportVerification,
        requestedCodec: ExportVideoCodec,
        effectiveCodec: ExportVideoCodec,
        fallbackApplied: Boolean
    ): File {
        val sidecar = File(outputFile.parentFile, "${outputFile.name}.json")
        val payload = JSONObject()
            .put("schema", 1)
            .put("engineVersion", "0.10.0")
            .put("takeId", plan.takeId)
            .put("outputFile", outputFile.name)
            .put("requestedCodec", requestedCodec.name)
            .put("effectiveCodec", effectiveCodec.name)
            .put("codecFallbackApplied", fallbackApplied)
            .put("width", verification.width)
            .put("height", verification.height)
            .put("rotationDegrees", verification.rotationDegrees)
            .put("durationMs", verification.durationMs)
            .put("fileSizeBytes", verification.fileSizeBytes)
            .put("sha256", verification.sha256)
            .put("trimStartMs", plan.trimStartMs)
            .put("trimEndMs", plan.trimEndMs)
            .put("createdAtEpochMs", System.currentTimeMillis())
        val temp = File(sidecar.parentFile, "${sidecar.name}.partial")
        temp.writeText(payload.toString(2), Charsets.UTF_8)
        if (!temp.renameTo(sidecar)) {
            temp.copyTo(sidecar, overwrite = true)
            temp.delete()
        }
        return sidecar
    }
}
