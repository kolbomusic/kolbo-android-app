@file:androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)

package com.kolbomusic.singstudio.core.export

import androidx.media3.common.OverlaySettings
import androidx.media3.common.VideoCompositorSettings
import androidx.media3.common.util.Size
import androidx.media3.effect.StaticOverlaySettings

class KolboVideoCompositorSettings(
    private val outputWidth: Int,
    private val outputHeight: Int,
    private val cameraInputId: Int,
    private val cameraScale: Float,
    private val cameraOffsetX: Float,
    private val cameraOffsetY: Float
) : VideoCompositorSettings {
    override fun getOutputSize(inputSizes: MutableList<Size>): Size = Size(outputWidth, outputHeight)

    override fun getOverlaySettings(inputId: Int, presentationTimeUs: Long): OverlaySettings {
        return if (inputId == cameraInputId) {
            val scale = cameraScale.coerceIn(0.22f, 0.48f)
            StaticOverlaySettings.Builder()
                .setScale(scale, scale)
                .setOverlayFrameAnchor(0f, 0f)
                .setBackgroundFrameAnchor(
                    (0.66f + cameraOffsetX * 0.45f).coerceIn(0.38f, 0.82f),
                    (0.60f - cameraOffsetY * 0.45f).coerceIn(0.34f, 0.80f)
                )
                .build()
        } else {
            StaticOverlaySettings.Builder().build()
        }
    }
}
