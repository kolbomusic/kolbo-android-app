package com.kolbomusic.singstudio.core.audio

import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.OutputStream
import java.io.RandomAccessFile
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.security.MessageDigest

object WavFileTools {

    fun finalizePcm16Mono(
        pcmFile: File,
        destination: File,
        sampleRate: Int
    ) {
        val temp = File(destination.parentFile, destination.name + ".tmp")
        if (temp.exists()) temp.delete()

        val pcmBytes = pcmFile.length()
        val fileOutput = FileOutputStream(temp)
        val output = BufferedOutputStream(fileOutput)
        try {
            writeHeader(
                output = output,
                sampleRate = sampleRate,
                channels = 1,
                bitsPerSample = 16,
                pcmDataSize = pcmBytes
            )
            BufferedInputStream(FileInputStream(pcmFile)).use { input ->
                input.copyTo(output, bufferSize = 64 * 1024)
            }
            output.flush()
            fileOutput.fd.sync()
        } finally {
            output.close()
        }

        if (destination.exists()) destination.delete()
        val moved = runCatching {
            Files.move(
                temp.toPath(),
                destination.toPath(),
                StandardCopyOption.ATOMIC_MOVE,
                StandardCopyOption.REPLACE_EXISTING
            )
        }.recoverCatching {
            Files.move(
                temp.toPath(),
                destination.toPath(),
                StandardCopyOption.REPLACE_EXISTING
            )
        }
        check(moved.isSuccess && destination.exists()) { "Unable to finalize WAV file" }
    }

    fun validatePcm16Mono(file: File): Boolean {
        if (!file.exists() || file.length() < 44L) return false
        return runCatching {
            RandomAccessFile(file, "r").use { raf ->
                val riff = ByteArray(4).also { raf.readFully(it) }.toString(Charsets.US_ASCII)
                val riffSize = raf.readUInt32LE()
                val wave = ByteArray(4).also { raf.readFully(it) }.toString(Charsets.US_ASCII)
                raf.seek(36)
                val data = ByteArray(4).also { raf.readFully(it) }.toString(Charsets.US_ASCII)
                val dataSize = raf.readUInt32LE()
                riff == "RIFF" &&
                    wave == "WAVE" &&
                    data == "data" &&
                    riffSize + 8L == file.length() &&
                    dataSize + 44L == file.length() &&
                    dataSize % 2L == 0L
            }
        }.getOrDefault(false)
    }

    fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        BufferedInputStream(FileInputStream(file)).use { input ->
            val buffer = ByteArray(64 * 1024)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                if (count > 0) digest.update(buffer, 0, count)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun writeHeader(
        output: OutputStream,
        sampleRate: Int,
        channels: Int,
        bitsPerSample: Int,
        pcmDataSize: Long
    ) {
        val byteRate = sampleRate * channels * bitsPerSample / 8
        val blockAlign = channels * bitsPerSample / 8
        val riffSize = 36L + pcmDataSize

        output.write("RIFF".toByteArray(Charsets.US_ASCII))
        output.writeLittleEndianInt(riffSize)
        output.write("WAVE".toByteArray(Charsets.US_ASCII))
        output.write("fmt ".toByteArray(Charsets.US_ASCII))
        output.writeLittleEndianInt(16)
        output.writeLittleEndianShort(1)
        output.writeLittleEndianShort(channels)
        output.writeLittleEndianInt(sampleRate.toLong())
        output.writeLittleEndianInt(byteRate.toLong())
        output.writeLittleEndianShort(blockAlign)
        output.writeLittleEndianShort(bitsPerSample)
        output.write("data".toByteArray(Charsets.US_ASCII))
        output.writeLittleEndianInt(pcmDataSize)
    }

    private fun RandomAccessFile.readUInt32LE(): Long {
        val b0 = readUnsignedByte().toLong()
        val b1 = readUnsignedByte().toLong()
        val b2 = readUnsignedByte().toLong()
        val b3 = readUnsignedByte().toLong()
        return b0 or (b1 shl 8) or (b2 shl 16) or (b3 shl 24)
    }

    private fun OutputStream.writeLittleEndianShort(value: Int) {
        write(value and 0xFF)
        write((value ushr 8) and 0xFF)
    }

    private fun OutputStream.writeLittleEndianInt(value: Long) {
        write((value and 0xFF).toInt())
        write(((value ushr 8) and 0xFF).toInt())
        write(((value ushr 16) and 0xFF).toInt())
        write(((value ushr 24) and 0xFF).toInt())
    }
}
