package com.kolbomusic.singstudio.core.dsp

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Process
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.Closeable
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference
import kotlin.concurrent.thread
import kotlin.math.max

/**
 * Disk-streamed low-latency A/B preview of vocal WAV files.
 * A and B share one frame cursor, so switching is sample aligned without loading songs into RAM.
 * FX parameters are sampled per block and can change while playback is running.
 */
class LiveVocalPreviewPlayer(
    rawFile: File,
    processedFile: File,
    initialSettings: VocalFxSettings
) : Closeable {
    private val raw = Pcm16WavRandomAccessReader(rawFile)
    private val processed = try {
        Pcm16WavRandomAccessReader(processedFile)
    } catch (error: Throwable) {
        raw.close()
        throw error
    }
    private val frameCount = minOf(raw.frameCount, processed.frameCount)
    private val source = AtomicReference(PreviewSource.Processed)
    private val settings = AtomicReference(initialSettings.sanitized())
    private val cursor = AtomicLong(0L)
    private val playing = AtomicBoolean(false)
    private val released = AtomicBoolean(false)
    private val processor = RealtimeVocalFxProcessor(raw.sampleRate)
    private val _state: MutableStateFlow<VocalEditorState>
    val state: StateFlow<VocalEditorState> get() = _state.asStateFlow()
    private val worker: Thread

    init {
        if (raw.sampleRate != processed.sampleRate) {
            closeReaders()
            error("A/B sample-rate mismatch")
        }
        if (frameCount <= 0L) {
            closeReaders()
            error("קובץ Preview ריק")
        }
        _state = MutableStateFlow(
            VocalEditorState(
                prepared = true,
                previewSource = source.get(),
                durationMs = frameCount * 1000L / raw.sampleRate,
                settings = settings.get()
            )
        )
        worker = thread(name = "KolboVocalPreview", isDaemon = true, start = true) { audioLoop() }
    }

    fun play() {
        if (released.get()) return
        playing.set(true)
        _state.value = _state.value.copy(playing = true, errorMessage = null)
    }

    fun pause() {
        playing.set(false)
        _state.value = _state.value.copy(playing = false)
    }

    fun toggle() {
        if (playing.get()) pause() else play()
    }

    fun selectSource(value: PreviewSource) {
        source.set(value)
        processor.reset()
        _state.value = _state.value.copy(previewSource = value)
    }

    fun updateSettings(value: VocalFxSettings) {
        val safe = value.sanitized()
        settings.set(safe)
        _state.value = _state.value.copy(settings = safe)
    }

    fun seekTo(positionMs: Long) {
        val frame = (positionMs * raw.sampleRate / 1000L).coerceIn(0L, frameCount - 1L)
        cursor.set(frame)
        processor.reset()
        _state.value = _state.value.copy(positionMs = frame * 1000L / raw.sampleRate)
    }

    override fun close() {
        if (!released.compareAndSet(false, true)) return
        playing.set(false)
        worker.interrupt()
    }

    private fun audioLoop() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
        val channelMask = AudioFormat.CHANNEL_OUT_MONO
        val encoding = AudioFormat.ENCODING_PCM_FLOAT
        val minBuffer = AudioTrack.getMinBufferSize(raw.sampleRate, channelMask, encoding)
        val bufferBytes = max(minBuffer, 512 * 4 * 4)
        val track = try {
            AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setSampleRate(raw.sampleRate)
                        .setEncoding(encoding)
                        .setChannelMask(channelMask)
                        .build()
                )
                .setTransferMode(AudioTrack.MODE_STREAM)
                .setBufferSizeInBytes(bufferBytes)
                .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
                .build()
        } catch (error: Throwable) {
            _state.value = _state.value.copy(
                prepared = false,
                playing = false,
                errorMessage = error.message ?: "לא ניתן לפתוח נתיב Preview"
            )
            closeReaders()
            return
        }

        val block = FloatArray(512)
        var trackStarted = false
        try {
            while (!released.get()) {
                if (!playing.get()) {
                    if (trackStarted) {
                        runCatching { track.pause() }
                        runCatching { track.flush() }
                        trackStarted = false
                    }
                    Thread.sleep(12L)
                    continue
                }
                if (!trackStarted) {
                    track.play()
                    trackStarted = true
                }

                var start = cursor.get()
                if (start >= frameCount) {
                    cursor.set(0L)
                    processor.reset()
                    playing.set(false)
                    _state.value = _state.value.copy(playing = false, positionMs = 0L)
                    continue
                }
                val requested = minOf(block.size.toLong(), frameCount - start).toInt()
                val selected = source.get()
                val reader = if (selected == PreviewSource.Raw) raw else processed
                val count = reader.readFrames(start, block, 0, requested)
                if (count <= 0) {
                    playing.set(false)
                    _state.value = _state.value.copy(playing = false)
                    continue
                }

                if (selected == PreviewSource.Processed) {
                    processor.processInPlace(block, 0, count, settings.get())
                }

                val written = track.write(block, 0, count, AudioTrack.WRITE_BLOCKING)
                if (written < 0) {
                    _state.value = _state.value.copy(
                        playing = false,
                        errorMessage = "AudioTrack write failed: $written"
                    )
                    playing.set(false)
                    continue
                }
                start += written.toLong()
                cursor.set(start)
                if ((start / block.size) % 8L == 0L) {
                    _state.value = _state.value.copy(
                        playing = true,
                        previewSource = selected,
                        positionMs = start * 1000L / raw.sampleRate,
                        settings = settings.get()
                    )
                }
            }
        } catch (_: InterruptedException) {
            // Normal shutdown.
        } catch (error: Throwable) {
            _state.value = _state.value.copy(
                playing = false,
                errorMessage = error.message ?: "Preview audio failed"
            )
        } finally {
            runCatching { track.pause() }
            runCatching { track.flush() }
            runCatching { track.release() }
            closeReaders()
        }
    }

    private fun closeReaders() {
        runCatching { raw.close() }
        runCatching { processed.close() }
    }
}
