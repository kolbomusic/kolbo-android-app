package com.kolbomusic.singstudio.core.dsp

import org.json.JSONObject
import java.io.File
import java.nio.file.Files
import java.nio.file.StandardCopyOption

object VocalFxMetadataStore {
    fun save(processedFilePath: String, state: VocalEditorState) {
        val processed = File(processedFilePath)
        if (!processed.exists()) return
        val destination = File(processed.parentFile, processed.nameWithoutExtension + ".fx.json")
        val temp = File(destination.parentFile, destination.name + ".partial")
        val s = state.settings.sanitized()
        val json = JSONObject()
            .put("schema", 1)
            .put("engine", "KolboLiveVocalFx")
            .put("engineVersion", "0.6.0")
            .put("processedVocalFile", processed.name)
            .put("previewSource", state.previewSource.name)
            .put("bpm", state.bpm ?: JSONObject.NULL)
            .put("bpmConfidence", state.bpmConfidence)
            .put("tempoSource", state.tempoSource.name)
            .put("manuallyEdited", state.manuallyEdited)
            .put("enabled", s.enabled)
            .put("reverbMix", s.reverbMix)
            .put("reverbRoom", s.reverbRoom)
            .put("delayMix", s.delayMix)
            .put("delayFeedback", s.delayFeedback)
            .put("delayMs", s.delayMs)
            .put("delayDivision", s.delayDivision.name)
            .put("outputGainDb", s.outputGainDb)
            .put("renderedFile", state.renderedFilePath?.let { File(it).name } ?: JSONObject.NULL)
            .put("renderedSha256", state.renderedSha256 ?: JSONObject.NULL)
        temp.writeText(json.toString(2), Charsets.UTF_8)
        runCatching {
            Files.move(
                temp.toPath(),
                destination.toPath(),
                StandardCopyOption.ATOMIC_MOVE,
                StandardCopyOption.REPLACE_EXISTING
            )
        }.getOrElse {
            Files.move(temp.toPath(), destination.toPath(), StandardCopyOption.REPLACE_EXISTING)
        }
    }
}
