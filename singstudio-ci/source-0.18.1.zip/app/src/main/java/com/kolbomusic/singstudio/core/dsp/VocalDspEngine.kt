package com.kolbomusic.singstudio.core.dsp

import com.kolbomusic.singstudio.core.audio.WavFileTools
import org.json.JSONObject
import java.io.File
import kotlin.math.abs

class VocalDspEngine {
    fun render(
        inputFile: File,
        requestedPreset: VocalPresetId,
        onProgress: (DspStage, Float) -> Unit = { _, _ -> }
    ): DspRenderResult {
        require(WavFileTools.validatePcm16Mono(inputFile)) { "קובץ ה־RAW אינו WAV תקין" }
        val sourceShaBefore = WavFileTools.sha256(inputFile)
        onProgress(DspStage.Loading, 0.05f)
        val wav = WavPcm16.readMono(inputFile)
        onProgress(DspStage.Analysing, 0.16f)
        val analysis = VocalAnalyser.analyse(wav.samples, wav.sampleRate)
        val preset = VocalPresets.resolve(requestedPreset, analysis)
        val resolvedId = if (requestedPreset == VocalPresetId.Auto) analysis.recommendedPreset else requestedPreset

        onProgress(DspStage.NoiseReduction, 0.30f)
        var samples = SpectralNoiseReducer().process(
            wav.samples,
            wav.sampleRate,
            preset.noiseReductionStrength
        )

        onProgress(DspStage.Tone, 0.55f)
        applyTone(samples, wav.sampleRate, preset)
        VocalDynamics.noiseGate(samples, wav.sampleRate, preset.gateThresholdDb, preset.gateFloorDb)

        onProgress(DspStage.Dynamics, 0.73f)
        VocalDynamics.deEsser(
            samples,
            wav.sampleRate,
            preset.deEsserThresholdDb,
            preset.deEsserMaxReductionDb
        )
        VocalDynamics.compressor(
            samples,
            wav.sampleRate,
            preset.compressorThresholdDb,
            preset.compressorRatio,
            preset.compressorAttackMs,
            preset.compressorReleaseMs
        )
        VocalDynamics.applyGain(samples, preset.outputGainDb)
        removeDc(samples)
        VocalDynamics.limiter(samples, preset.limiterCeilingDb)

        onProgress(DspStage.Finalising, 0.90f)
        val processedDir = File(inputFile.parentFile, "processed").also { it.mkdirs() }
        val safePreset = resolvedId.name.lowercase()
        val output = File(processedDir, inputFile.nameWithoutExtension + "-$safePreset-vocal.wav")
        WavPcm16.writeMonoAtomic(output, wav.sampleRate, samples)
        check(WavFileTools.validatePcm16Mono(output)) { "קובץ העיבוד הסופי נכשל באימות WAV" }
        val sha = WavFileTools.sha256(output)
        val sourceShaAfter = WavFileTools.sha256(inputFile)
        check(sourceShaBefore == sourceShaAfter) { "RAW integrity check failed" }
        writeMetadata(inputFile, output, requestedPreset, resolvedId, preset, analysis, sourceShaBefore, sha)
        onProgress(DspStage.Completed, 1f)
        return DspRenderResult(output.absolutePath, sha, analysis, resolvedId)
    }

    private fun applyTone(samples: FloatArray, sampleRate: Int, preset: VocalPreset) {
        val hp = Biquad.highPass(sampleRate, preset.highPassHz)
        val warmth = Biquad.lowShelf(sampleRate, 190.0, preset.warmthDb)
        val presence = Biquad.peaking(sampleRate, 3_200.0, 0.85, preset.presenceDb)
        for (i in samples.indices) {
            var x = hp.process(samples[i].toDouble())
            x = warmth.process(x)
            x = presence.process(x)
            samples[i] = x.coerceIn(-1.5, 1.5).toFloat()
        }
    }

    private fun removeDc(samples: FloatArray) {
        if (samples.isEmpty()) return
        var mean = 0.0
        for (sample in samples) mean += sample
        mean /= samples.size
        if (abs(mean) < 1e-7) return
        for (i in samples.indices) samples[i] = (samples[i] - mean).toFloat()
    }

    private fun writeMetadata(
        input: File,
        output: File,
        requestedPreset: VocalPresetId,
        resolvedPreset: VocalPresetId,
        preset: VocalPreset,
        analysis: VocalAnalysis,
        sourceSha: String,
        sha: String
    ) {
        val json = JSONObject()
            .put("schema", 1)
            .put("engine", "KolboVocalDSP")
            .put("engineVersion", "0.5.0")
            .put("sourceFile", input.name)
            .put("sourceSha256", sourceSha)
            .put("outputFile", output.name)
            .put("outputSha256", sha)
            .put("requestedPreset", requestedPreset.name)
            .put("resolvedPreset", resolvedPreset.name)
            .put("sampleRate", analysis.sampleRate)
            .put("durationMs", analysis.durationMs)
            .put("inputPeakDbfs", analysis.peakDbfs)
            .put("inputRmsDbfs", analysis.rmsDbfs)
            .put("estimatedNoiseFloorDbfs", analysis.estimatedNoiseFloorDbfs)
            .put("clippingSamples", analysis.clippingSamples)
            .put("dynamicRangeEstimateDb", analysis.dynamicRangeEstimateDb)
            .put("noiseReductionStrength", preset.noiseReductionStrength)
            .put("highPassHz", preset.highPassHz)
            .put("compressorRatio", preset.compressorRatio)
            .put("limiterCeilingDb", preset.limiterCeilingDb)
        File(output.parentFile, output.nameWithoutExtension + ".dsp.json").writeText(json.toString(2), Charsets.UTF_8)
    }
}
