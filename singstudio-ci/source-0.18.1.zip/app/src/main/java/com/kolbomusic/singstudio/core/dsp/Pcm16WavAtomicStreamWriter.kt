package com.kolbomusic.singstudio.core.dsp

import java.io.BufferedOutputStream
import java.io.Closeable
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import kotlin.math.roundToInt

/** Constant-memory PCM16 mono WAV writer with temp-file + atomic finalize semantics. */
internal class Pcm16WavAtomicStreamWriter(
    private val destination: File,
    private val sampleRate: Int
) : Closeable {
    private val temp = File(destination.parentFile, destination.name + ".partial")
    private val fos: FileOutputStream
    private val out: BufferedOutputStream
    private val bytes = ByteArray(8192)
    private var dataBytes: Long = 0L
    private var completed = false

    init {
        require(sampleRate in 8_000..192_000)
        destination.parentFile?.mkdirs()
        if (temp.exists()) temp.delete()
        fos = FileOutputStream(temp)
        out = BufferedOutputStream(fos, 64 * 1024)
        writePlaceholderHeader()
    }

    fun write(samples: FloatArray, offset: Int, count: Int) {
        check(!completed) { "WAV writer already finalized" }
        var i = offset
        val end = (offset + count).coerceAtMost(samples.size)
        var bi = 0
        while (i < end) {
            val pcm = (samples[i].coerceIn(-1f, 0.999969f) * 32768f)
                .roundToInt()
                .coerceIn(-32768, 32767)
            bytes[bi++] = (pcm and 0xFF).toByte()
            bytes[bi++] = ((pcm ushr 8) and 0xFF).toByte()
            if (bi >= bytes.size - 1) {
                out.write(bytes, 0, bi)
                dataBytes += bi
                bi = 0
            }
            i++
        }
        if (bi > 0) {
            out.write(bytes, 0, bi)
            dataBytes += bi
        }
    }

    fun commit(): File {
        check(!completed) { "WAV writer already finalized" }
        return try {
            out.flush()
            fos.fd.sync()
            out.close()

            RandomAccessFile(temp, "rw").use { raf ->
                raf.seek(4L)
                raf.writeUInt32LE(36L + dataBytes)
                raf.seek(40L)
                raf.writeUInt32LE(dataBytes)
                raf.fd.sync()
            }

            if (destination.exists()) destination.delete()
            runCatching {
                Files.move(temp.toPath(), destination.toPath(), StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING)
            }.getOrElse {
                Files.move(temp.toPath(), destination.toPath(), StandardCopyOption.REPLACE_EXISTING)
            }
            completed = true
            destination
        } catch (error: Throwable) {
            completed = true
            runCatching { out.close() }
            temp.delete()
            throw error
        }
    }

    fun abort() {
        if (completed) return
        completed = true
        runCatching { out.close() }
        temp.delete()
    }

    override fun close() {
        if (!completed) abort()
    }

    private fun writePlaceholderHeader() {
        out.write("RIFF".toByteArray(Charsets.US_ASCII))
        out.writeUInt32LE(0L)
        out.write("WAVE".toByteArray(Charsets.US_ASCII))
        out.write("fmt ".toByteArray(Charsets.US_ASCII))
        out.writeUInt32LE(16L)
        out.writeUInt16LE(1)
        out.writeUInt16LE(1)
        out.writeUInt32LE(sampleRate.toLong())
        out.writeUInt32LE(sampleRate.toLong() * 2L)
        out.writeUInt16LE(2)
        out.writeUInt16LE(16)
        out.write("data".toByteArray(Charsets.US_ASCII))
        out.writeUInt32LE(0L)
    }

    private fun BufferedOutputStream.writeUInt16LE(value: Int) {
        write(value and 0xFF)
        write((value ushr 8) and 0xFF)
    }

    private fun BufferedOutputStream.writeUInt32LE(value: Long) {
        write((value and 0xFF).toInt())
        write(((value ushr 8) and 0xFF).toInt())
        write(((value ushr 16) and 0xFF).toInt())
        write(((value ushr 24) and 0xFF).toInt())
    }

    private fun RandomAccessFile.writeUInt32LE(value: Long) {
        write((value and 0xFF).toInt())
        write(((value ushr 8) and 0xFF).toInt())
        write(((value ushr 16) and 0xFF).toInt())
        write(((value ushr 24) and 0xFF).toInt())
    }
}
