package com.kolbomusic.singstudio.core.editor

import com.kolbomusic.singstudio.core.export.ExportSettings
import com.kolbomusic.singstudio.core.model.OutputAspectRatio


enum class TextFontPreset(val labelHe: String) {
    Clean("נקי"),
    Bold("מודגש"),
    Elegant("אלגנטי"),
    Handwritten("כתב יד")
}

enum class TextAnimationPreset(val labelHe: String) {
    None("ללא"),
    Fade("Fade"),
    Pop("Pop"),
    Slide("Slide")
}

data class TitleOverlay(
    val text: String = "",
    val fontPreset: TextFontPreset = TextFontPreset.Bold,
    val fontSizeSp: Float = 40f,
    val colorArgb: Long = 0xFFFFFFFF,
    val outline: Boolean = true,
    val shadow: Boolean = true,
    val xNormalized: Float = 0.5f,
    val yNormalized: Float = 0.16f,
    val animation: TextAnimationPreset = TextAnimationPreset.Fade,
    val startMs: Long = 0L,
    val endMs: Long = 6_000L
) {
    fun sanitized(): TitleOverlay {
        val safeStart = startMs.coerceAtLeast(0L)
        return copy(
            text = text.take(120),
            fontSizeSp = fontSizeSp.coerceIn(18f, 96f),
            xNormalized = xNormalized.coerceIn(0.05f, 0.95f),
            yNormalized = yNormalized.coerceIn(0.05f, 0.95f),
            startMs = safeStart,
            endMs = endMs.coerceAtLeast(safeStart + 250L)
        )
    }
}

data class VideoProjectState(
    val aspectRatio: OutputAspectRatio = OutputAspectRatio.Portrait9x16,
    val zoom: Float = 1f,
    val visualOffsetX: Float = 0f,
    val visualOffsetY: Float = 0f,
    val title: TitleOverlay = TitleOverlay(),
    val exportSettings: ExportSettings = ExportSettings(),
    val savedProjectPath: String? = null,
    val errorMessage: String? = null
) {
    fun sanitized(durationMs: Long = Long.MAX_VALUE): VideoProjectState = copy(
        zoom = zoom.coerceIn(0.5f, 3f),
        visualOffsetX = visualOffsetX.coerceIn(-0.35f, 0.35f),
        visualOffsetY = visualOffsetY.coerceIn(-0.35f, 0.35f),
        title = title.sanitized(),
        exportSettings = if (durationMs == Long.MAX_VALUE) exportSettings else exportSettings.sanitized(durationMs)
    )
}
