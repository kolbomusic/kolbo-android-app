package com.kolbomusic.singstudio.core.playback

import com.kolbomusic.singstudio.core.model.PlaybackSource
import com.kolbomusic.singstudio.core.model.PlaybackSourceType

/**
 * Separates the live performance player from the media source used by offline
 * post-production. Local media can serve both roles. YouTube is intentionally
 * live-playback only; a local backing is optional for capture and required for
 * a complete instrumental mix. Without one the captured voice is still exportable.
 */
object ProductionSourcePolicy {
    fun automaticFor(playback: PlaybackSource): PlaybackSource? =
        playback.takeIf { it.type != PlaybackSourceType.YouTube }

    fun isValidProductionSource(source: PlaybackSource?): Boolean =
        source != null && source.type != PlaybackSourceType.YouTube && !source.uriString.isNullOrBlank()

    fun resolve(playback: PlaybackSource, latchedProductionSource: PlaybackSource?): PlaybackSource? =
        latchedProductionSource?.takeIf(::isValidProductionSource) ?: automaticFor(playback)

    /** A performance must never be blocked solely because YouTube audio cannot be exported. */
    fun canStartPerformance(playback: PlaybackSource): Boolean =
        playback.id.isNotBlank() && (playback.type == PlaybackSourceType.YouTube || isValidProductionSource(playback))

    /** The saved result excludes YouTube audio unless an independently authorized backing exists. */
    fun isVoiceOnlyPerformance(playback: PlaybackSource, latchedProductionSource: PlaybackSource?): Boolean =
        playback.type == PlaybackSourceType.YouTube && !isValidProductionSource(latchedProductionSource)

    fun isGeneratedVoiceOnlyBacking(source: PlaybackSource): Boolean =
        source.id.startsWith("kolbo-voice-only:") && isValidProductionSource(source)

    fun canStartFullProduction(playback: PlaybackSource, latchedProductionSource: PlaybackSource?): Boolean =
        playback.type != PlaybackSourceType.YouTube || isValidProductionSource(latchedProductionSource)
}
