@file:androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)

package com.kolbomusic.singstudio.ui.recording

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.view.LayoutInflater
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.IosShare
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.TextButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.Player
import androidx.media3.ui.PlayerView
import com.kolbomusic.singstudio.R
import com.kolbomusic.singstudio.core.camera.CameraCaptureEngine
import com.kolbomusic.singstudio.core.dsp.DspStage
import com.kolbomusic.singstudio.core.dsp.BeatDivision
import com.kolbomusic.singstudio.core.dsp.DspUiState
import com.kolbomusic.singstudio.core.dsp.PreviewSource
import com.kolbomusic.singstudio.core.dsp.TempoSync
import com.kolbomusic.singstudio.core.dsp.VocalEditorState
import com.kolbomusic.singstudio.core.dsp.VocalPresetId
import com.kolbomusic.singstudio.core.device.RuntimeHealthState
import com.kolbomusic.singstudio.core.editor.RestoredVideoProject
import com.kolbomusic.singstudio.core.editor.TextAnimationPreset
import com.kolbomusic.singstudio.core.editor.TextFontPreset
import com.kolbomusic.singstudio.core.editor.VideoProjectState
import com.kolbomusic.singstudio.core.export.CompositionPreviewState
import com.kolbomusic.singstudio.core.export.ExportPhase
import com.kolbomusic.singstudio.core.export.ExportResolution
import com.kolbomusic.singstudio.core.export.ExportState
import com.kolbomusic.singstudio.core.export.ExportVideoCodec
import com.kolbomusic.singstudio.core.delivery.DeliveryState
import com.kolbomusic.singstudio.core.delivery.PlatformExportPreset
import com.kolbomusic.singstudio.core.delivery.ShareIntentFactory
import com.kolbomusic.singstudio.core.mix.SessionMixState
import com.kolbomusic.singstudio.core.model.PlaybackSource
import com.kolbomusic.singstudio.core.model.PlaybackSourceType
import com.kolbomusic.singstudio.core.model.PlaybackState
import com.kolbomusic.singstudio.core.model.ProductionMode
import com.kolbomusic.singstudio.core.model.VisualScene
import com.kolbomusic.singstudio.core.model.RecordingPhase
import com.kolbomusic.singstudio.core.nativeaudio.LowLatencyAudioCapability
import com.kolbomusic.singstudio.core.playback.Media3PlaybackEngine
import com.kolbomusic.singstudio.core.playback.PlaybackControl
import com.kolbomusic.singstudio.core.playback.ProductionSourcePolicy
import com.kolbomusic.singstudio.ui.playback.YouTubePlaybackHandle
import com.kolbomusic.singstudio.ui.playback.YouTubePlayerSurface
import com.kolbomusic.singstudio.ui.setup.BackgroundPreviewSurface
import com.kolbomusic.singstudio.ui.theme.ElectricViolet
import com.kolbomusic.singstudio.ui.theme.GraphiteElevated
import com.kolbomusic.singstudio.ui.theme.RecordRose
import com.kolbomusic.singstudio.ui.theme.WarmGold
import kotlinx.coroutines.delay
import java.util.Locale

@Composable
fun RecordingStudioScreen(
    scene: VisualScene,
    playbackSource: PlaybackSource,
    onBack: () -> Unit,
    restoredProject: RestoredVideoProject? = null,
    viewModel: RecordingViewModel = viewModel()
) {
    val context = LocalContext.current
    val mode = scene.mode
    val state by viewModel.recordingState.collectAsStateWithLifecycle()
    val playbackState by viewModel.playbackState.collectAsStateWithLifecycle()
    val productionBackingSource by viewModel.productionBackingSource.collectAsStateWithLifecycle()
    val countdown by viewModel.countdown.collectAsStateWithLifecycle()
    val sessionMessage by viewModel.sessionMessage.collectAsStateWithLifecycle()
    val postTakeState by viewModel.postTakeState.collectAsStateWithLifecycle()
    val dspState by viewModel.dspState.collectAsStateWithLifecycle()
    val editorState by viewModel.editorState.collectAsStateWithLifecycle()
    val sessionMixState by viewModel.sessionMixState.collectAsStateWithLifecycle()
    val videoProjectState by viewModel.videoProjectState.collectAsStateWithLifecycle()
    val compositionPreviewState by viewModel.compositionPreviewState.collectAsStateWithLifecycle()
    val exportState by viewModel.exportState.collectAsStateWithLifecycle()
    val deliveryState by viewModel.deliveryState.collectAsStateWithLifecycle()
    val runtimeHealth by viewModel.runtimeHealth.collectAsStateWithLifecycle()
    val capabilities = viewModel.capabilities
    val lowLatencyCapability by viewModel.lowLatencyCapability.collectAsStateWithLifecycle()
    val hostView = LocalView.current
    val contentScrollState = rememberScrollState()
    var advancedToolsVisible by rememberSaveable(playbackSource.id) { mutableStateOf(false) }
    var automaticRecoveryAttempted by rememberSaveable(playbackSource.id) { mutableStateOf(false) }
    LaunchedEffect(scene, playbackSource.id, restoredProject?.projectFilePath) {
        if (restoredProject != null) {
            viewModel.restoreProject(restoredProject)
        } else {
            viewModel.beginFreshSession(playbackSource, scene)
        }
    }

    LaunchedEffect(state.phase) {
        when (state.phase) {
            RecordingPhase.Starting -> {
                automaticRecoveryAttempted = false
                contentScrollState.scrollTo(0)
            }
            RecordingPhase.Recording -> contentScrollState.scrollTo(0)
            RecordingPhase.Saved -> {
                advancedToolsVisible = false
                contentScrollState.scrollTo(0)
            }
            else -> Unit
        }
    }

    LaunchedEffect(postTakeState.stage, state.savedFilePath) {
        if (
            postTakeState.stage == PostTakeStage.Error &&
            state.savedFilePath != null &&
            !automaticRecoveryAttempted
        ) {
            automaticRecoveryAttempted = true
            delay(900L)
            viewModel.retryPostTakePreparation()
        }
    }

    val keepScreenAwake = state.phase == RecordingPhase.Starting ||
        state.phase == RecordingPhase.Recording ||
        state.phase == RecordingPhase.Stopping ||
        countdown != null ||
        compositionPreviewState.playing ||
        exportState.running

    val localEngine = if (playbackSource.type != PlaybackSourceType.YouTube) {
        remember(playbackSource.id) {
            Media3PlaybackEngine(
                context = context,
                uri = Uri.parse(requireNotNull(playbackSource.uriString))
            )
        }
    } else null
    val youtubeHandle = if (playbackSource.type == PlaybackSourceType.YouTube) {
        remember(playbackSource.id) { YouTubePlaybackHandle() }
    } else null
    val playbackControl: PlaybackControl = localEngine ?: requireNotNull(youtubeHandle)

    DisposableEffect(playbackSource.id, playbackControl) {
        viewModel.attachPlayback(playbackSource, playbackControl, preserveEditorSettings = restoredProject != null)
        onDispose {
            viewModel.detachPlayback(playbackControl)
            playbackControl.release()
        }
    }

    LaunchedEffect(keepScreenAwake) {
        hostView.keepScreenOn = keepScreenAwake
    }
    DisposableEffect(Unit) {
        onDispose { hostView.keepScreenOn = false }
    }

    var cameraError by remember { mutableStateOf<String?>(null) }
    var cameraEngine by remember { mutableStateOf<CameraCaptureEngine?>(null) }

    DisposableEffect(cameraEngine) {
        val engine = cameraEngine
        if (engine != null) viewModel.attachCamera(engine)
        onDispose { if (engine != null) viewModel.detachCamera(engine) }
    }

    fun requiredPermissions(): Array<String> {
        val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (mode.usesCamera) permissions += Manifest.permission.CAMERA
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions += Manifest.permission.POST_NOTIFICATIONS
        }
        return permissions.toTypedArray()
    }

    fun allRequiredGranted(): Boolean = requiredPermissions()
        .filterNot { it == Manifest.permission.POST_NOTIFICATIONS }
        .all { ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED }

    var permissionsGranted by remember { mutableStateOf(allRequiredGranted()) }
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        permissionsGranted = requiredPermissions()
            .filterNot { it == Manifest.permission.POST_NOTIFICATIONS }
            .all { permission ->
                permissions[permission] == true ||
                    ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
            }
    }

    LaunchedEffect(Unit) {
        if (!permissionsGranted) permissionLauncher.launch(requiredPermissions())
    }

    val legacyGalleryPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) viewModel.publishLatestExportToGallery()
    }

    fun saveLatestExportToGallery() {
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            legacyGalleryPermissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        } else {
            viewModel.publishLatestExportToGallery()
        }
    }


    val productionBackingPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            viewModel.attachProductionBacking(uri)
        }
    }

    val takeActive = state.phase == RecordingPhase.Starting ||
        state.phase == RecordingPhase.Recording ||
        state.phase == RecordingPhase.Stopping

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(if (takeActive) Color.Black else MaterialTheme.colorScheme.background)
            .then(
                if (takeActive) Modifier
                else Modifier
                    .windowInsetsPadding(WindowInsets.statusBars)
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .padding(horizontal = 18.dp, vertical = 12.dp)
            ),
        verticalArrangement = if (takeActive) Arrangement.Top else Arrangement.spacedBy(14.dp)
    ) {
        if (!takeActive) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "חזרה")
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(playbackSource.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 1)
                    Text(
                        modeTitle(mode),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }

        if (state.phase != RecordingPhase.Saved) {
            PerformanceTakeStage(
                source = playbackSource,
                localEngine = localEngine,
                youtubeHandle = youtubeHandle,
                scene = scene,
                permissionsGranted = permissionsGranted,
                hasCamera = capabilities.hasCamera,
                takeActive = takeActive,
                phase = state.phase,
                countdown = countdown,
                elapsedMs = state.telemetry.elapsedMs,
                onEngineReady = { cameraEngine = it },
                onCameraError = { cameraError = it },
                onStop = viewModel::stopSyncedTake,
                modifier = if (takeActive) {
                    Modifier.weight(1f).fillMaxWidth()
                } else {
                    Modifier.fillMaxWidth().aspectRatio(16f / 9f)
                }
            )
        }

        if (!takeActive) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(contentScrollState),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                if (!permissionsGranted) {
                    PermissionCard(onRequest = { permissionLauncher.launch(requiredPermissions()) })
                } else {
                    if (state.phase != RecordingPhase.Saved) {
                        if (playbackSource.type == PlaybackSourceType.YouTube) {
                            YouTubeProductionSourceCard(
                                source = productionBackingSource,
                                onChoose = { productionBackingPicker.launch(arrayOf("video/*", "audio/*")) }
                            )
                        }
                        SimpleStudioStatusCard(
                            playbackReady = playbackState.prepared,
                            cameraRequired = mode.usesCamera,
                            cameraReady = !mode.usesCamera || cameraEngine != null,
                            sourceType = playbackSource.type,
                            playbackState = playbackState,
                            playbackControl = playbackControl,
                            controlsEnabled = countdown == null
                        )
                    }

                    if (state.phase != RecordingPhase.Saved) {
                        sessionMessage?.let { InfoCard(it, error = true) }
                        playbackState.errorMessage?.let { InfoCard(it, error = true) }
                        cameraError?.let { InfoCard(it, error = true) }
                        state.errorMessage?.let { InfoCard(it, error = true) }
                    }

                    if (state.phase == RecordingPhase.Saved && state.savedFilePath != null) {
                        PostTakeExportCard(
                            postTake = postTakeState,
                            dspState = dspState,
                            mixState = sessionMixState,
                            exportState = exportState,
                            deliveryState = deliveryState,
                            onRetryPreparation = viewModel::retryPostTakePreparation,
                            onCancelExport = viewModel::cancelVideoExport,
                            onSaveGallery = ::saveLatestExportToGallery,
                            onShare = {
                                exportState.outputPath?.let { path ->
                                    val file = java.io.File(path)
                                    if (file.isFile) {
                                        runCatching {
                                            context.startActivity(
                                                ShareIntentFactory.createVideoChooser(
                                                    context,
                                                    file,
                                                    videoProjectState.title.text.ifBlank { playbackSource.title }
                                                )
                                            )
                                        }
                                    }
                                }
                            },
                            advancedVisible = advancedToolsVisible,
                            onToggleAdvanced = { advancedToolsVisible = !advancedToolsVisible }
                        )

                        if (advancedToolsVisible && postTakeState.stage == PostTakeStage.Error) {
                            state.playbackStartOffsetMs?.let { InfoCard("סנכרון פלייבק: ${it}ms") }
                            state.cameraStartOffsetMs?.let { InfoCard("סנכרון מצלמה: ${it}ms") }
                            VocalDspCard(
                                state = dspState,
                                onSelectPreset = viewModel::selectVocalPreset,
                                onProcess = viewModel::processSavedVocal
                            )
                            if (dspState.outputFilePath != null) {
                                LiveVocalEditorCard(
                                    state = editorState,
                                    lowLatencyCapability = lowLatencyCapability,
                                    onTogglePlayback = viewModel::toggleVocalPreview,
                                    onSelectSource = viewModel::selectPreviewSource,
                                    onSeek = viewModel::seekVocalPreview,
                                    onReverbMix = viewModel::setReverbMix,
                                    onReverbRoom = viewModel::setReverbRoom,
                                    onDelayMix = viewModel::setDelayMix,
                                    onDelayFeedback = viewModel::setDelayFeedback,
                                    onOutputGain = viewModel::setOutputGain,
                                    onDelayDivision = viewModel::setDelayDivision,
                                    onTapTempo = viewModel::tapTempo,
                                    onAdvanced = viewModel::setEditorAdvanced,
                                    onSmartReset = viewModel::restoreSmartEffects,
                                    onRenderFinal = viewModel::renderFinalVocalFx
                                )
                                SessionMixEditorCard(
                                    state = sessionMixState,
                                    onToggle = viewModel::toggleSessionMix,
                                    onSeek = viewModel::seekSessionMix,
                                    onSelectSource = viewModel::setSessionMixPreviewSource,
                                    onVocalGain = viewModel::setSessionMixVocalGain,
                                    onPlaybackGain = viewModel::setSessionMixPlaybackGain,
                                    onHeadroom = viewModel::setSessionMixHeadroom,
                                    onRender = viewModel::renderSessionMix
                                )
                                VideoProjectEditorCard(
                                    state = videoProjectState,
                                    scene = scene,
                                    isYouTubeSource = playbackSource.type == PlaybackSourceType.YouTube,
                                    onTitle = viewModel::setVideoTitle,
                                    onTitleSize = viewModel::setVideoTitleSize,
                                    onTitleColor = viewModel::setVideoTitleColor,
                                    onFont = viewModel::setVideoTitleFont,
                                    onAnimation = viewModel::setVideoTitleAnimation,
                                    onOutline = viewModel::setVideoTitleOutline,
                                    onShadow = viewModel::setVideoTitleShadow,
                                    onX = viewModel::setVideoTitleX,
                                    onY = viewModel::setVideoTitleY,
                                    onZoom = viewModel::setVideoZoom,
                                    onVisualOffsetX = viewModel::setVideoOffsetX,
                                    onVisualOffsetY = viewModel::setVideoOffsetY,
                                    onSave = viewModel::saveVideoProject
                                )
                                val fullPreviewReady =
                                    postTakeState.stage == PostTakeStage.ReadyToSave &&
                                        (sessionMixState.masteredMixPath != null || sessionMixState.renderedMixPath != null)
                                if (fullPreviewReady) {
                                    CompositionPreviewCard(
                                        state = compositionPreviewState,
                                        player = viewModel.compositionPreviewPlayer,
                                        aspectRatio = scene.aspectRatio.ratio,
                                        canPrepare = true,
                                        onPrepare = viewModel::prepareVideoPreview,
                                        onToggle = viewModel::toggleVideoPreview,
                                        onSeek = viewModel::seekVideoPreview
                                    )
                                }
                            }
                        }
                    }
                }
            }

            if (permissionsGranted) {
                RecordControls(
                    phase = state.phase,
                    readyToRecord = playbackState.prepared &&
                        (!mode.usesCamera || cameraEngine != null) &&
                        ProductionSourcePolicy.canStartPerformance(playbackSource),
                    waitingLabel = when {
                        !playbackState.prepared -> "מכין פלייבק…"
                        mode.usesCamera && cameraEngine == null -> "מכין מצלמה…"
                        else -> "מכין…"
                    },
                    countdown = countdown,
                    onStart = viewModel::startSyncedTake,
                    onStop = viewModel::stopSyncedTake,
                    onNewTake = viewModel::reset
                )
            }
        }
    }
}

@Composable
private fun PerformanceTakeStage(
    source: PlaybackSource,
    localEngine: Media3PlaybackEngine?,
    youtubeHandle: YouTubePlaybackHandle?,
    scene: VisualScene,
    permissionsGranted: Boolean,
    hasCamera: Boolean,
    takeActive: Boolean,
    phase: RecordingPhase,
    countdown: Int?,
    elapsedMs: Long,
    onEngineReady: (CameraCaptureEngine) -> Unit,
    onCameraError: (String) -> Unit,
    onStop: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .then(if (takeActive) Modifier else Modifier.clip(RoundedCornerShape(24.dp)))
            .background(Color.Black),
        contentAlignment = Alignment.Center
    ) {
        KaraokePlaybackStage(
            source = source,
            localEngine = localEngine,
            youtubeHandle = youtubeHandle,
            takeActive = takeActive,
            modifier = Modifier.fillMaxSize()
        )

        if (scene.mode.usesCamera && permissionsGranted && hasCamera) {
            Card(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(if (takeActive) 12.dp else 9.dp)
                    .fillMaxWidth(if (takeActive) 0.28f else 0.25f)
                    .aspectRatio(3f / 4f),
                shape = RoundedCornerShape(if (takeActive) 18.dp else 14.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Black)
            ) {
                CameraCaptureSurface(
                    facing = scene.cameraFacing,
                    preferConcurrentVideoCompatibility = source.type == PlaybackSourceType.YouTube,
                    modifier = Modifier.fillMaxSize(),
                    onEngineReady = onEngineReady,
                    onError = onCameraError
                )
            }
        }

        if (countdown != null) {
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.72f))
                    .padding(horizontal = 28.dp, vertical = 16.dp)
            ) {
                Text(
                    text = if (countdown == 0) "שיר!" else countdown.toString(),
                    color = WarmGold,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = if (countdown == 0) 30.sp else 48.sp
                )
            }
        }

        if (takeActive) {
            Row(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .windowInsetsPadding(WindowInsets.statusBars)
                    .padding(12.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color.Black.copy(alpha = 0.66f))
                    .padding(horizontal = 10.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                Box(Modifier.width(10.dp).height(10.dp).clip(CircleShape).background(RecordRose))
                Text("REC · ${formatDuration(elapsedMs)}", color = Color.White, fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = onStop,
                enabled = phase != RecordingPhase.Stopping,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .padding(bottom = 12.dp)
                    .heightIn(min = 68.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(containerColor = RecordRose)
            ) {
                Icon(Icons.Default.Stop, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(if (phase == RecordingPhase.Stopping) "מסיים ושומר…" else "סיים ביצוע", fontWeight = FontWeight.ExtraBold)
            }
        }
    }
}

@Composable
private fun KaraokePlaybackStage(
    source: PlaybackSource,
    localEngine: Media3PlaybackEngine?,
    youtubeHandle: YouTubePlaybackHandle?,
    takeActive: Boolean,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier.background(Color.Black),
        contentAlignment = Alignment.Center
    ) {
        when (source.type) {
            PlaybackSourceType.LocalVideo -> {
                val engine = requireNotNull(localEngine)
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { context ->
                        (LayoutInflater.from(context).inflate(
                            R.layout.view_karaoke_player,
                            null,
                            false
                        ) as PlayerView).apply {
                            player = engine.player
                            useController = !takeActive
                        }
                    },
                    update = { view ->
                        view.player = engine.player
                        view.useController = !takeActive
                    }
                )
            }

            PlaybackSourceType.YouTube -> {
                YouTubePlayerSurface(
                    videoId = requireNotNull(source.youtubeVideoId),
                    handle = requireNotNull(youtubeHandle),
                    modifier = Modifier.fillMaxSize()
                )
            }

            PlaybackSourceType.LocalAudio -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.linearGradient(
                                listOf(
                                    ElectricViolet.copy(alpha = 0.45f),
                                    Color(0xFF111827),
                                    WarmGold.copy(alpha = 0.22f)
                                )
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Default.GraphicEq,
                            contentDescription = null,
                            tint = WarmGold,
                            modifier = Modifier.heightIn(min = 58.dp)
                        )
                        Spacer(Modifier.height(10.dp))
                        Text(source.title, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                        Text("פלייבק אודיו", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
private fun CountdownBanner(countdown: Int?) {
    AnimatedVisibility(visible = countdown != null) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ElectricViolet.copy(alpha = 0.18f)),
            shape = RoundedCornerShape(20.dp)
        ) {
            Text(
                text = when (countdown) {
                    3 -> "3"
                    2 -> "2"
                    1 -> "1"
                    0 -> "שיר!"
                    else -> ""
                },
                modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.displayMedium,
                color = WarmGold,
                fontWeight = FontWeight.ExtraBold
            )
        }
    }
}

@Composable
private fun SimpleStudioStatusCard(
    playbackReady: Boolean,
    cameraRequired: Boolean,
    cameraReady: Boolean,
    sourceType: PlaybackSourceType,
    playbackState: PlaybackState,
    playbackControl: PlaybackControl,
    controlsEnabled: Boolean
) {
    val ready = playbackReady && (!cameraRequired || cameraReady)
    Card(
        colors = CardDefaults.cardColors(containerColor = GraphiteElevated),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = if (ready) Color(0xFF22C55E) else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.width(8.dp))
                    Column {
                        Text(
                            if (ready) "מוכן לביצוע" else "מכין את האולפן…",
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            when {
                                !playbackReady -> "מכין את הקריוקי"
                                cameraRequired && !cameraReady -> "מכין את המצלמה"
                                else -> "הכול מוכן — אפשר להתחיל"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                if (sourceType == PlaybackSourceType.LocalAudio && playbackReady) {
                    Row {
                        IconButton(onClick = { playbackControl.seekTo(0L) }, enabled = controlsEnabled) {
                            Icon(Icons.Default.Replay, contentDescription = "חזור להתחלה")
                        }
                        IconButton(
                            onClick = {
                                if (playbackState.playing) playbackControl.pause() else playbackControl.playFromStart()
                            },
                            enabled = controlsEnabled
                        ) {
                            Icon(
                                if (playbackState.playing) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (playbackState.playing) "השהה" else "נגן"
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PlaybackStatusCard(
    playbackState: PlaybackState,
    control: PlaybackControl,
    enabled: Boolean
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = GraphiteElevated),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("פלייבק", fontWeight = FontWeight.Bold)
                    Text(
                        when {
                            playbackState.errorMessage != null -> "שגיאה"
                            playbackState.buffering -> "טוען…"
                            playbackState.playing -> "מתנגן"
                            playbackState.prepared -> "מוכן"
                            else -> "מכין…"
                        },
                        color = if (playbackState.prepared) WarmGold else MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                Row {
                    IconButton(onClick = { control.seekTo(0L) }, enabled = enabled && playbackState.prepared) {
                        Icon(Icons.Default.Replay, contentDescription = "חזור להתחלה")
                    }
                    IconButton(
                        onClick = { if (playbackState.playing) control.pause() else control.playFromStart() },
                        enabled = enabled && playbackState.prepared
                    ) {
                        Icon(
                            if (playbackState.playing) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (playbackState.playing) "השהה" else "נגן"
                        )
                    }
                }
            }
            val progress = if (playbackState.durationMs > 0L) {
                (playbackState.positionMs.toFloat() / playbackState.durationMs.toFloat()).coerceIn(0f, 1f)
            } else 0f
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape)
            )
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(formatDuration(playbackState.positionMs), style = MaterialTheme.typography.bodySmall)
                Text(formatDuration(playbackState.durationMs), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun CameraReadinessPreview(
    scene: VisualScene,
    onEngineReady: (CameraCaptureEngine) -> Unit,
    onCameraError: (String) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = GraphiteElevated),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("מצלמה", fontWeight = FontWeight.Bold)
                Text(
                    "${if (scene.cameraFacing.name == "Front") "קדמית" else "אחורית"} · ${scene.aspectRatio.label}",
                    color = WarmGold,
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(scene.aspectRatio.ratio)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color.Black)
            ) {
                CameraCaptureSurface(
                    facing = scene.cameraFacing,
                    modifier = Modifier.fillMaxSize(),
                    onEngineReady = onEngineReady,
                    onError = onCameraError
                )
            }
            Text(
                "הווידאו נשמר ללא אודיו. הקול נשמר כהקלטת מקור איכותית בנפרד ומסונכרן לפי שעון מונוטוני.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun BackgroundReadinessCard(scene: VisualScene) {
    val background = scene.background
    Card(
        colors = CardDefaults.cardColors(containerColor = GraphiteElevated),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("רקע", fontWeight = FontWeight.Bold)
                Text(background.title ?: "ללא", color = WarmGold, style = MaterialTheme.typography.bodySmall)
            }
            BackgroundPreviewSurface(
                background = background,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(scene.aspectRatio.ratio)
                    .clip(RoundedCornerShape(14.dp))
            )
            Text(
                if (scene.mode == ProductionMode.CameraWithBackground)
                    "הרקע אינו נצרב בצילום המקורי; הוא נשמר כשכבת קומפוזיציה לעריכה וייצוא."
                else
                    "הרקע נשמר כחלק מהפרויקט וייכנס ל־render הסופי.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun MeterCard(level: Float, peakDbfs: Float, clipping: Boolean, elapsedMs: Long) {
    Card(
        colors = CardDefaults.cardColors(containerColor = GraphiteElevated),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("מיקרופון", fontWeight = FontWeight.Bold)
                Text(formatDuration(elapsedMs), fontWeight = FontWeight.Bold, color = if (clipping) RecordRose else WarmGold)
            }
            LinearProgressIndicator(
                progress = { level.coerceIn(0f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(12.dp)
                    .clip(CircleShape)
            )
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(String.format(Locale.US, "Peak %.1f dBFS", peakDbfs), style = MaterialTheme.typography.bodySmall)
                AnimatedVisibility(visible = clipping) {
                    Text("חזק מדי — CLIP", color = RecordRose, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun DeviceReadinessCard(
    sampleRate: Int,
    lowLatency: Boolean,
    rawInput: Boolean,
    cameraReady: Boolean,
    playbackReady: Boolean
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = GraphiteElevated),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("מוכנות אולפן", fontWeight = FontWeight.Bold)
            ReadinessLine("מיקרופון", true)
            ReadinessLine("פלייבק", playbackReady)
            ReadinessLine("קצב דגימה ${sampleRate / 1000} kHz", true)
            ReadinessLine("מסלול Low Latency", lowLatency)
            ReadinessLine(if (rawInput) "קלט PCM מקצועי · UNPROCESSED" else "קלט PCM מקצועי · מצב תאימות", true)
            ReadinessLine("מצלמה", cameraReady)
        }
    }
}

@Composable
private fun ReadinessLine(label: String, ready: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
            Icons.Default.CheckCircle,
            contentDescription = null,
            tint = if (ready) Color(0xFF22C55E) else MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.width(8.dp))
        Text(label, color = if (ready) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun PermissionCard(onRequest: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = GraphiteElevated),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(Icons.Default.Mic, contentDescription = null, tint = ElectricViolet)
            Text("כדי להתחיל טייק צריך לאשר גישה למיקרופון ולמצלמה לפי מצב ההפקה.", textAlign = TextAlign.Center)
            Button(onClick = onRequest) { Text("אשר הרשאות") }
        }
    }
}

@Composable
private fun RecordControls(
    phase: RecordingPhase,
    readyToRecord: Boolean,
    waitingLabel: String,
    countdown: Int?,
    onStart: () -> Unit,
    onStop: () -> Unit,
    onNewTake: () -> Unit
) {
    when (phase) {
        RecordingPhase.Recording, RecordingPhase.Starting -> {
            Button(
                onClick = onStop,
                enabled = phase == RecordingPhase.Recording,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .semantics { contentDescription = "עצור ושמור את הטייק" },
                shape = RoundedCornerShape(20.dp),
                colors = ButtonDefaults.buttonColors(containerColor = RecordRose)
            ) {
                Icon(Icons.Default.Stop, contentDescription = null)
                Spacer(Modifier.width(10.dp))
                Text(
                    when {
                        phase == RecordingPhase.Starting -> "מכין הקלטה…"
                        countdown != null -> "בטל טייק"
                        else -> "עצור ושמור"
                    },
                    style = MaterialTheme.typography.titleLarge
                )
            }
        }

        RecordingPhase.Stopping -> {
            Button(
                onClick = {},
                enabled = false,
                modifier = Modifier.fillMaxWidth().height(64.dp),
                shape = RoundedCornerShape(20.dp)
            ) { Text("שומר טייק…") }
        }

        RecordingPhase.Saved -> {
            OutlinedButton(
                onClick = onNewTake,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 56.dp)
                    .semantics { contentDescription = "ביצוע חדש" },
                shape = RoundedCornerShape(18.dp)
            ) {
                Icon(Icons.Default.Replay, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("ביצוע חדש", fontWeight = FontWeight.Bold)
            }
        }

        else -> {
            Button(
                onClick = onStart,
                enabled = readyToRecord,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(72.dp)
                    .semantics { contentDescription = "התחל ביצוע" },
                shape = RoundedCornerShape(20.dp),
                colors = ButtonDefaults.buttonColors(containerColor = RecordRose)
            ) {
                Icon(Icons.Default.Mic, contentDescription = null)
                Spacer(Modifier.width(10.dp))
                Text(if (readyToRecord) "התחל ביצוע" else waitingLabel, style = MaterialTheme.typography.titleLarge)
            }
        }
    }
}

@Composable
private fun VocalDspCard(
    state: DspUiState,
    onSelectPreset: (VocalPresetId) -> Unit,
    onProcess: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = GraphiteElevated),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("עיבוד קול", fontWeight = FontWeight.Bold)
                    Text(
                        "הקלטת המקור נשארת ללא שינוי",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Text("DSP 0.6", color = WarmGold, fontWeight = FontWeight.Bold)
            }

            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                VocalPresetId.entries.forEach { preset ->
                    FilterChip(
                        selected = state.selectedPreset == preset,
                        onClick = { onSelectPreset(preset) },
                        enabled = !state.processing,
                        label = { Text(preset.labelHe) }
                    )
                }
            }

            if (state.processing || state.stage == DspStage.Completed) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    LinearProgressIndicator(
                        progress = { state.progress.coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().height(7.dp).clip(CircleShape)
                    )
                    Text(
                        "${state.stage.labelHe} · ${(state.progress * 100).toInt()}%",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            state.analysis?.let { analysis ->
                Text(
                    "ניתוח: רעש ${String.format(Locale.US, "%.1f", analysis.estimatedNoiseFloorDbfs)} dBFS · " +
                        "RMS ${String.format(Locale.US, "%.1f", analysis.rmsDbfs)} dBFS · " +
                        "Peak ${String.format(Locale.US, "%.1f", analysis.peakDbfs)} dBFS",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            state.outputFilePath?.let { path ->
                InfoCard(
                    "הקול המעובד מוכן · ${path.substringAfterLast('/')}" +
                        (state.resolvedPreset?.let { " · ${it.labelHe}" } ?: "")
                )
            }
            state.errorMessage?.let { InfoCard(it, error = true) }

            Button(
                onClick = onProcess,
                enabled = !state.processing,
                modifier = Modifier.fillMaxWidth().heightIn(min = 54.dp),
                shape = RoundedCornerShape(17.dp),
                colors = ButtonDefaults.buttonColors(containerColor = ElectricViolet)
            ) {
                Text(
                    when {
                        state.processing -> "מעבד…"
                        state.outputFilePath != null -> "עבד מחדש"
                        state.selectedPreset == VocalPresetId.Auto -> "✨ שפר לי את הקול"
                        else -> "החל עיבוד ${state.selectedPreset.labelHe}"
                    },
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun LiveVocalEditorCard(
    state: VocalEditorState,
    lowLatencyCapability: LowLatencyAudioCapability,
    onTogglePlayback: () -> Unit,
    onSelectSource: (PreviewSource) -> Unit,
    onSeek: (Long) -> Unit,
    onReverbMix: (Float) -> Unit,
    onReverbRoom: (Float) -> Unit,
    onDelayMix: (Float) -> Unit,
    onDelayFeedback: (Float) -> Unit,
    onOutputGain: (Float) -> Unit,
    onDelayDivision: (BeatDivision) -> Unit,
    onTapTempo: () -> Unit,
    onAdvanced: (Boolean) -> Unit,
    onSmartReset: () -> Unit,
    onRenderFinal: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = GraphiteElevated),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("עורך קול חי", fontWeight = FontWeight.Bold)
                    Text(
                        "A/B מסונכרן לדגימה · שינויי FX נשמעים בזמן הנגינה",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Text("FX 0.6", color = WarmGold, fontWeight = FontWeight.Bold)
            }

            if (lowLatencyCapability.rawReport == "PENDING") {
                Text(
                    "בודק נתיב Low‑latency…",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else if (lowLatencyCapability.available) {
                Text(
                    "Low‑latency: ${lowLatencyCapability.api ?: "Oboe"} · " +
                        "${lowLatencyCapability.sampleRate ?: 0}Hz · " +
                        "${lowLatencyCapability.framesPerBurst ?: 0} frames/burst",
                    style = MaterialTheme.typography.bodySmall,
                    color = WarmGold
                )
            } else {
                Text(
                    "Oboe low‑latency ייבדק סופית על המכשיר בזמן ההתקנה.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                PreviewSource.entries.forEach { source ->
                    FilterChip(
                        selected = state.previewSource == source,
                        onClick = { onSelectSource(source) },
                        enabled = state.prepared,
                        label = { Text(source.labelHe) }
                    )
                }
                IconButton(
                    onClick = onTogglePlayback,
                    enabled = state.prepared,
                    modifier = Modifier.semantics {
                        contentDescription = if (state.playing) "השהה האזנת A B" else "נגן האזנת A B"
                    }
                ) {
                    Icon(
                        if (state.playing) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = ElectricViolet
                    )
                }
            }

            if (state.durationMs > 0L) {
                Slider(
                    value = state.positionMs.toFloat().coerceIn(0f, state.durationMs.toFloat()),
                    onValueChange = { onSeek(it.toLong()) },
                    valueRange = 0f..state.durationMs.toFloat(),
                    modifier = Modifier.semantics { contentDescription = "מיקום בהאזנת הקול" }
                )
                Text(
                    "${formatDuration(state.positionMs)} / ${formatDuration(state.durationMs)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (state.tempoAnalysing) {
                Text("מנתח את קצב הפלייבק…", color = WarmGold)
            } else {
                val tempoText = state.bpm?.let {
                    "${it.toInt()} BPM · ${state.tempoSource.labelHe}" +
                        if (state.tempoSource.name == "Automatic") " · ${(state.bpmConfidence * 100).toInt()}%" else ""
                } ?: "הקצב עדיין לא זוהה"
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(tempoText, style = MaterialTheme.typography.bodyMedium)
                    OutlinedButton(onClick = onTapTempo) { Text("Tap Tempo") }
                }
            }

            FxSlider(
                label = "רברב",
                value = state.settings.reverbMix,
                valueRange = 0f..0.65f,
                valueText = "${(state.settings.reverbMix * 100).toInt()}%",
                onValueChange = onReverbMix
            )
            FxSlider(
                label = "אקו / דיליי",
                value = state.settings.delayMix,
                valueRange = 0f..0.55f,
                valueText = "${(state.settings.delayMix * 100).toInt()}%",
                onValueChange = onDelayMix
            )

            Text("קצב הדיליי", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                BeatDivision.entries.forEach { division ->
                    FilterChip(
                        selected = state.settings.delayDivision == division,
                        onClick = { onDelayDivision(division) },
                        label = { Text(division.labelHe) }
                    )
                }
            }
            Text(
                TempoSync.label(state.bpm, state.settings.delayDivision, state.settings.delayMs),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            TextButton(onClick = { onAdvanced(!state.advancedOpen) }) {
                Text(if (state.advancedOpen) "הסתר עריכה מתקדמת" else "עריכה מתקדמת")
            }

            if (state.advancedOpen) {
                FxSlider(
                    label = "גודל חלל",
                    value = state.settings.reverbRoom,
                    valueRange = 0.15f..0.92f,
                    valueText = "${(state.settings.reverbRoom * 100).toInt()}%",
                    onValueChange = onReverbRoom
                )
                FxSlider(
                    label = "חזרות Delay",
                    value = state.settings.delayFeedback,
                    valueRange = 0f..0.72f,
                    valueText = "${(state.settings.delayFeedback * 100).toInt()}%",
                    onValueChange = onDelayFeedback
                )
                FxSlider(
                    label = "עוצמת יציאה",
                    value = state.settings.outputGainDb,
                    valueRange = -12f..6f,
                    valueText = String.format(Locale.US, "%+.1f dB", state.settings.outputGainDb),
                    onValueChange = onOutputGain
                )
            }

            OutlinedButton(
                onClick = onSmartReset,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("✨ החזר התאמה חכמה")
            }

            Button(
                onClick = onRenderFinal,
                enabled = state.prepared && !state.rendering,
                modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = ElectricViolet)
            ) {
                Text(if (state.rendering) "מקבע אפקטים…" else "שמור גרסת קול עם האפקטים", fontWeight = FontWeight.Bold)
            }
            if (state.rendering) {
                LinearProgressIndicator(
                    progress = { state.renderProgress.coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth().height(7.dp).clip(CircleShape)
                )
            }
            state.renderedFilePath?.let {
                InfoCard("גרסת FX נשמרה ואומתה · ${it.substringAfterLast('/')}")
            }

            state.errorMessage?.let { InfoCard(it, error = true) }
        }
    }
}

@Composable
private fun SessionMixEditorCard(
    state: SessionMixState,
    onToggle: () -> Unit,
    onSeek: (Long) -> Unit,
    onSelectSource: (PreviewSource) -> Unit,
    onVocalGain: (Float) -> Unit,
    onPlaybackGain: (Float) -> Unit,
    onHeadroom: (Float) -> Unit,
    onRender: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = GraphiteElevated),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("מיקס השיר", fontWeight = FontWeight.Bold)
                    Text(
                        "פלייבק + קול · שעון אחד · ללא drift",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Text("MIX 0.7", color = WarmGold, fontWeight = FontWeight.Bold)
            }

            if (state.preparing) {
                Text("מכין Session Mix…", color = WarmGold)
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth().height(7.dp).clip(CircleShape))
            } else if (!state.available) {
                state.errorMessage?.let { InfoCard(it) }
            } else if (state.prepared) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    PreviewSource.entries.forEach { source ->
                        FilterChip(
                            selected = state.settings.previewSource == source,
                            onClick = { onSelectSource(source) },
                            label = { Text(source.labelHe) }
                        )
                    }
                    IconButton(onClick = onToggle) {
                        Icon(
                            if (state.playing) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (state.playing) "השהה מיקס" else "נגן מיקס",
                            tint = ElectricViolet
                        )
                    }
                }
                if (state.durationMs > 0L) {
                    Slider(
                        value = state.positionMs.toFloat().coerceIn(0f, state.durationMs.toFloat()),
                        onValueChange = { onSeek(it.toLong()) },
                        valueRange = 0f..state.durationMs.toFloat(),
                        modifier = Modifier.semantics { contentDescription = "מיקום במיקס השיר" }
                    )
                    Text(
                        "${formatDuration(state.positionMs)} / ${formatDuration(state.durationMs)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                FxSlider(
                    label = "עוצמת זמר",
                    value = state.settings.vocalGainDb,
                    valueRange = -24f..12f,
                    valueText = String.format(Locale.US, "%+.1f dB", state.settings.vocalGainDb),
                    onValueChange = onVocalGain
                )
                FxSlider(
                    label = "עוצמת פלייבק",
                    value = state.settings.playbackGainDb,
                    valueRange = -24f..6f,
                    valueText = String.format(Locale.US, "%+.1f dB", state.settings.playbackGainDb),
                    onValueChange = onPlaybackGain
                )
                FxSlider(
                    label = "Headroom מאסטר",
                    value = state.settings.masterHeadroomDb,
                    valueRange = -12f..0f,
                    valueText = String.format(Locale.US, "%+.1f dB", state.settings.masterHeadroomDb),
                    onValueChange = onHeadroom
                )
                Button(
                    onClick = onRender,
                    enabled = !state.rendering,
                    modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricViolet)
                ) {
                    Text(if (state.rendering) "שומר מיקס…" else "שמור מיקס אודיו", fontWeight = FontWeight.Bold)
                }
                if (state.rendering) {
                    LinearProgressIndicator(
                        progress = { state.renderProgress.coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().height(7.dp).clip(CircleShape)
                    )
                }
                state.renderedMixPath?.let { InfoCard("מיקס נשמר ואומת · ${it.substringAfterLast('/')}") }
                state.errorMessage?.let { InfoCard(it, error = true) }
            } else {
                Text(
                    "Session Mix עדיין לא מוכן",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun VideoProjectEditorCard(
    state: VideoProjectState,
    scene: VisualScene,
    isYouTubeSource: Boolean,
    onTitle: (String) -> Unit,
    onTitleSize: (Float) -> Unit,
    onTitleColor: (Long) -> Unit,
    onFont: (TextFontPreset) -> Unit,
    onAnimation: (TextAnimationPreset) -> Unit,
    onOutline: (Boolean) -> Unit,
    onShadow: (Boolean) -> Unit,
    onX: (Float) -> Unit,
    onY: (Float) -> Unit,
    onZoom: (Float) -> Unit,
    onVisualOffsetX: (Float) -> Unit,
    onVisualOffsetY: (Float) -> Unit,
    onSave: () -> Unit
) {
    val title = state.title
    val colors = listOf(
        0xFFFFFFFF to "לבן",
        0xFFFFD54FL to "זהב",
        0xFFE040F7L to "סגול",
        0xFFFF4D6DL to "ורוד",
        0xFF4DD0E1L to "טורקיז"
    )
    Card(
        colors = CardDefaults.cardColors(containerColor = GraphiteElevated),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("עיצוב הסרטון", fontWeight = FontWeight.Bold)
                    Text(
                        "הכול נשמר כשכבות הפיכות לפרויקט",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Text(scene.aspectRatio.label, color = WarmGold, fontWeight = FontWeight.Bold)
            }

            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(scene.aspectRatio.ratio)
                    .clip(RoundedCornerShape(18.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(Color(0xFF111827), ElectricViolet.copy(alpha = 0.35f), Color.Black)
                        )
                    )
            ) {
                if (scene.mode.usesBackground) {
                    BackgroundPreviewSurface(background = scene.background, modifier = Modifier.fillMaxSize())
                } else {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Mic, contentDescription = null, tint = WarmGold, modifier = Modifier.height(56.dp))
                    }
                }
                if (title.text.isNotBlank()) {
                    val boxWidth = 180.dp
                    val boxHeight = 90.dp
                    val x = (maxWidth - boxWidth) * title.xNormalized
                    val y = (maxHeight - boxHeight) * title.yNormalized
                    val titleModifier = Modifier.width(boxWidth).offset(x = x, y = y)
                    val titleWeight = when (title.fontPreset) {
                        TextFontPreset.Clean -> FontWeight.Medium
                        TextFontPreset.Bold -> FontWeight.ExtraBold
                        TextFontPreset.Elegant -> FontWeight.Light
                        TextFontPreset.Handwritten -> FontWeight.SemiBold
                    }
                    val titleStyle = TextStyle(
                        fontStyle = if (title.fontPreset == TextFontPreset.Handwritten) FontStyle.Italic else FontStyle.Normal,
                        shadow = if (title.shadow) Shadow(
                            color = Color.Black.copy(alpha = 0.72f),
                            offset = Offset(3f, 4f),
                            blurRadius = 5f
                        ) else null
                    )
                    if (title.outline) {
                        Text(
                            text = title.text,
                            modifier = titleModifier,
                            color = Color.Black.copy(alpha = 0.90f),
                            fontSize = title.fontSizeSp.coerceIn(18f, 72f).sp,
                            fontWeight = titleWeight,
                            fontStyle = titleStyle.fontStyle,
                            style = titleStyle.copy(drawStyle = Stroke(width = 5f), shadow = null),
                            textAlign = TextAlign.Center,
                            maxLines = 3
                        )
                    }
                    Text(
                        text = title.text,
                        modifier = titleModifier,
                        color = Color(title.colorArgb),
                        fontSize = title.fontSizeSp.coerceIn(18f, 72f).sp,
                        fontWeight = titleWeight,
                        fontStyle = titleStyle.fontStyle,
                        style = titleStyle,
                        textAlign = TextAlign.Center,
                        maxLines = 3
                    )
                }
            }

            OutlinedTextField(
                value = title.text,
                onValueChange = onTitle,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("כותרת / שם הזמר") },
                supportingText = { Text("עברית ואנגלית · עד 120 תווים") },
                singleLine = false,
                maxLines = 3
            )
            FxSlider(
                label = "גודל כותרת",
                value = title.fontSizeSp,
                valueRange = 18f..96f,
                valueText = "${title.fontSizeSp.toInt()}sp",
                onValueChange = onTitleSize
            )
            Text("פונט", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TextFontPreset.entries.forEach { font ->
                    FilterChip(selected = title.fontPreset == font, onClick = { onFont(font) }, label = { Text(font.labelHe) })
                }
            }
            Text("צבע", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                colors.forEach { (argb, label) ->
                    FilterChip(
                        selected = title.colorArgb == argb,
                        onClick = { onTitleColor(argb) },
                        label = { Text(label) }
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = title.outline, onClick = { onOutline(!title.outline) }, label = { Text("Outline") })
                FilterChip(selected = title.shadow, onClick = { onShadow(!title.shadow) }, label = { Text("צל") })
            }
            Text("אנימציה", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TextAnimationPreset.entries.forEach { animation ->
                    FilterChip(
                        selected = title.animation == animation,
                        onClick = { onAnimation(animation) },
                        label = { Text(animation.labelHe) }
                    )
                }
            }
            FxSlider("מיקום אופקי", title.xNormalized, 0.05f..0.95f, "${(title.xNormalized * 100).toInt()}%", onX)
            FxSlider("מיקום אנכי", title.yNormalized, 0.05f..0.95f, "${(title.yNormalized * 100).toInt()}%", onY)
            FxSlider("Zoom", state.zoom, 0.5f..3f, String.format(Locale.US, "%.2fx", state.zoom), onZoom)
            FxSlider("מיקום התמונה לרוחב", state.visualOffsetX, -0.35f..0.35f, String.format(Locale.US, "%+.0f%%", state.visualOffsetX * 100f), onVisualOffsetX)
            FxSlider("מיקום התמונה לגובה", state.visualOffsetY, -0.35f..0.35f, String.format(Locale.US, "%+.0f%%", state.visualOffsetY * 100f), onVisualOffsetY)

            if (isYouTubeSource) {
            }
            Button(
                onClick = onSave,
                modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = WarmGold, contentColor = Color.Black)
            ) {
                Text("שמור פרויקט עריכה", fontWeight = FontWeight.ExtraBold)
            }
            state.savedProjectPath?.let { InfoCard("פרויקט נשמר · ${it.substringAfterLast('/')}") }
            state.errorMessage?.let { InfoCard(it, error = true) }
        }
    }
}

@Composable
private fun CompositionPreviewCard(
    state: CompositionPreviewState,
    player: Player?,
    aspectRatio: Float,
    canPrepare: Boolean,
    onPrepare: () -> Unit,
    onToggle: () -> Unit,
    onSeek: (Long) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = GraphiteElevated),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("תצוגה מקדימה של ההפקה", fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleLarge)
            Text(
                "אותה Composition משמשת לתצוגה ולייצוא, כדי לצמצם פער בין מה שרואים לבין הסרטון הסופי.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (state.ready && player != null) {
                AndroidView(
                    factory = { context ->
                        PlayerView(context).apply {
                            useController = false
                            this.player = player
                        }
                    },
                    update = { view -> view.player = player },
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(aspectRatio)
                        .clip(RoundedCornerShape(16.dp))
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = onToggle,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricViolet)
                    ) {
                        Icon(if (state.playing) Icons.Default.Pause else Icons.Default.PlayArrow, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text(if (state.playing) "השהה" else "נגן")
                    }
                    OutlinedButton(onClick = onPrepare, modifier = Modifier.weight(1f)) { Text("רענן Preview") }
                }
                val duration = state.durationMs.coerceAtLeast(1L)
                Slider(
                    value = state.positionMs.coerceIn(0L, duration).toFloat(),
                    onValueChange = { onSeek(it.toLong()) },
                    valueRange = 0f..duration.toFloat().coerceAtLeast(1f),
                    modifier = Modifier.semantics { contentDescription = "מיקום בתצוגה המקדימה" }
                )
                Text(
                    "${formatDuration(state.positionMs)} / ${formatDuration(state.durationMs)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = WarmGold
                )
            } else {
                Button(
                    onClick = onPrepare,
                    enabled = canPrepare && !state.preparing,
                    modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricViolet)
                ) {
                    Text(if (state.preparing) "מכין Preview…" else "פתח תצוגה מקדימה", fontWeight = FontWeight.Bold)
                }
            }

            if (state.multipleVideoInputs) {
                Text(
                    "מצב מצלמה + רקע משתמש ב־multi-input preview של Media3. אם המכשיר לא תומך בו היטב, הייצוא עצמו נשאר מסלול נפרד ואינו נפגע.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            state.message?.let { if (!state.preparing) Text(it, color = WarmGold, style = MaterialTheme.typography.bodySmall) }
            state.errorMessage?.let { InfoCard(it, error = true) }
        }
    }
}

@Composable
private fun YouTubeProductionSourceCard(
    source: PlaybackSource?,
    onChoose: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = GraphiteElevated),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            Text(
                if (source == null) "אפשר להתחיל להקליט" else "מוכן למיקס עם מוזיקה",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                if (source == null) {
                    "השירה והמצלמה יישמרו, אך מוזיקת YouTube לא תיכלל בסרטון."
                } else {
                    "המוזיקה בקובץ המקומי תשולב אוטומטית אחרי ההקלטה."
                },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            TextButton(
                onClick = onChoose,
                modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
            ) {
                Text(if (source == null) "הוסף פלייבק מקומי (לא חובה)" else "החלף פלייבק מקומי")
            }
        }
    }
}

@Composable
private fun PostTakeExportCard(
    postTake: PostTakeState,
    dspState: DspUiState,
    mixState: SessionMixState,
    exportState: ExportState,
    deliveryState: DeliveryState,
    onRetryPreparation: () -> Unit,
    onCancelExport: () -> Unit,
    onSaveGallery: () -> Unit,
    onShare: () -> Unit,
    advancedVisible: Boolean,
    onToggleAdvanced: () -> Unit
) {
    val preparationProgress = when (postTake.stage) {
        PostTakeStage.PreparingVocal -> (0.05f + dspState.progress.coerceIn(0f, 1f) * 0.38f).coerceIn(0.05f, 0.43f)
        PostTakeStage.PreparingMix -> {
            val mixProgress = when {
                mixState.rendering -> mixState.renderProgress.coerceIn(0f, 1f)
                mixState.preparing -> 0.25f
                else -> 0.10f
            }
            (0.48f + mixProgress * 0.28f).coerceIn(0.48f, 0.76f)
        }
        PostTakeStage.Mastering -> (0.77f + mixState.masteringProgress.coerceIn(0f, 1f) * 0.12f).coerceIn(0.77f, 0.89f)
        PostTakeStage.RenderingVideo -> postTake.progress.coerceIn(0.90f, 0.97f)
        PostTakeStage.VerifyingVideo -> 0.99f
        PostTakeStage.ReadyToSave -> 1f
        else -> postTake.progress.coerceIn(0f, 1f)
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = GraphiteElevated),
        shape = RoundedCornerShape(22.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
                .semantics {
                    contentDescription = if (postTake.stage == PostTakeStage.ReadyToSave) "הסרטון מוכן לשמירה" else "מעבד את הביצוע אוטומטית"
                    liveRegion = LiveRegionMode.Polite
                },
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = WarmGold)
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        if (postTake.stage == PostTakeStage.ReadyToSave) "הביצוע מוכן" else "מסיים את ההפקה אוטומטית",
                        fontWeight = FontWeight.ExtraBold,
                        style = MaterialTheme.typography.titleLarge
                    )
                    Text(
                        if (postTake.stage == PostTakeStage.ReadyToSave) {
                            "הסרטון מוכן לשמירה."
                        } else {
                            "האפליקציה מעבדת ומאזנת את הביצוע אוטומטית."
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (exportState.phase == ExportPhase.Completed && exportState.outputPath != null && postTake.stage == PostTakeStage.ReadyToSave) {
                Button(
                    onClick = onSaveGallery,
                    enabled = !deliveryState.running && deliveryState.galleryUri == null,
                    modifier = Modifier.fillMaxWidth().heightIn(min = 72.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricViolet)
                ) {
                    Icon(Icons.Default.PhotoLibrary, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        when {
                            deliveryState.running -> "שומר לגלריה…"
                            deliveryState.galleryUri != null -> "נשמר לגלריה ✓"
                            else -> "שמור סרטון"
                        },
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 18.sp
                    )
                }
                if (deliveryState.galleryUri != null) {
                    OutlinedButton(
                        onClick = onShare,
                        modifier = Modifier.fillMaxWidth().heightIn(min = 54.dp)
                    ) {
                        Icon(Icons.Default.IosShare, contentDescription = null)
                        Spacer(Modifier.width(7.dp))
                        Text("שתף")
                    }
                }
            } else if (postTake.stage == PostTakeStage.Error) {
                InfoCard(postTake.errorMessage ?: exportState.errorMessage ?: "הפקת הביצוע נכשלה", error = true)
                Button(
                    onClick = onRetryPreparation,
                    modifier = Modifier.fillMaxWidth().heightIn(min = 58.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricViolet)
                ) {
                    Text("נסה שוב", fontWeight = FontWeight.ExtraBold)
                }
            } else {
                LinearProgressIndicator(
                    progress = { preparationProgress.coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape)
                )
                Text(
                    postTake.message ?: exportState.message ?: "מעבד את הביצוע…",
                    fontWeight = FontWeight.Bold,
                    color = WarmGold
                )
                Text(
                    "מכין את התוצאה הסופית עבורך…",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            exportState.errorMessage?.let {
                if (postTake.stage != PostTakeStage.Error) InfoCard(it, error = true)
            }
            deliveryState.errorMessage?.let { InfoCard(it, error = true) }

        }
    }
}

@Composable
private fun VideoExportCard(
    state: ExportState,
    deliveryState: DeliveryState,
    runtimeHealth: RuntimeHealthState,
    project: VideoProjectState,
    sessionDurationMs: Long,
    hasFreshMix: Boolean,
    isYouTubeSource: Boolean,
    onPreset: (PlatformExportPreset) -> Unit,
    onResolution: (ExportResolution) -> Unit,
    onCodec: (ExportVideoCodec) -> Unit,
    onTrimStart: (Long) -> Unit,
    onTrimEnd: (Long) -> Unit,
    onStart: () -> Unit,
    onCancel: () -> Unit,
    onSaveGallery: () -> Unit,
    onShare: () -> Unit
) {
    val duration = sessionDurationMs.coerceAtLeast(0L)
    val settings = project.exportSettings
    val safeEnd = if (settings.trimEndMs <= 0L) duration else settings.trimEndMs.coerceAtMost(duration)
    Card(
        colors = CardDefaults.cardColors(containerColor = GraphiteElevated),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("ייצוא הסרטון", fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleLarge)
            Text(
                "הקובץ מקבל סטטוס מוכן רק אחרי אימות וידאו + אודיו + משך + מידות + SHA‑256.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            runtimeHealth.exportWarning?.let { InfoCard(it, error = runtimeHealth.thermalLevel.name == "Severe") }

            Text("Preset מהיר", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                PlatformExportPreset.entries.forEach { preset ->
                    FilterChip(
                        selected = false,
                        onClick = { if (!state.running) onPreset(preset) },
                        label = { Text(preset.labelHe) }
                    )
                }
            }
            Text(
                "Presets מגדירים codec / איכות / FPS. יחס המסך נקבע בשלב ההפקה כדי לא לחתוך את הקומפוזיציה בלי אישור.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Text("איכות", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ExportResolution.entries.forEach { resolution ->
                    FilterChip(
                        selected = settings.resolution == resolution,
                        onClick = { if (!state.running) onResolution(resolution) },
                        label = { Text(resolution.labelHe) }
                    )
                }
            }

            Text("קידוד", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ExportVideoCodec.entries.forEach { codec ->
                    FilterChip(
                        selected = settings.codec == codec,
                        onClick = { if (!state.running) onCodec(codec) },
                        label = { Text(codec.labelHe) }
                    )
                }
            }

            if (duration > 1_000L) {
                val maxStart = (safeEnd - 500L).coerceAtLeast(0L)
                FxSlider(
                    label = "תחילת הסרטון",
                    value = settings.trimStartMs.coerceAtMost(maxStart).toFloat(),
                    valueRange = 0f..maxStart.toFloat().coerceAtLeast(1f),
                    valueText = formatDuration(settings.trimStartMs),
                    onValueChange = { if (!state.running) onTrimStart(it.toLong()) }
                )
                val minEnd = (settings.trimStartMs + 500L).coerceAtMost(duration)
                FxSlider(
                    label = "סיום הסרטון",
                    value = safeEnd.coerceAtLeast(minEnd).toFloat(),
                    valueRange = minEnd.toFloat()..duration.toFloat().coerceAtLeast(minEnd.toFloat() + 1f),
                    valueText = formatDuration(safeEnd),
                    onValueChange = { if (!state.running) onTrimEnd(it.toLong()) }
                )
            }

            if (!hasFreshMix || isYouTubeSource) {
                InfoCard("ההפקה האוטומטית עדיין משלימה את ההכנות. אין צורך לבצע פעולה ידנית נוספת כאן.")
            }

            if (state.running) {
                LinearProgressIndicator(
                    progress = { state.progressPercent / 100f },
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    state.message ?: "מעבד…",
                    color = WarmGold,
                    style = MaterialTheme.typography.bodyMedium
                )
                OutlinedButton(onClick = onCancel, modifier = Modifier.fillMaxWidth()) {
                    Text("בטל ייצוא בבטחה")
                }
            } else {
                Button(
                    onClick = onStart,
                    enabled = hasFreshMix && !isYouTubeSource && duration > 0L,
                    modifier = Modifier.fillMaxWidth().heightIn(min = 54.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricViolet)
                ) {
                    Text(if (state.phase == ExportPhase.Failed || state.phase == ExportPhase.Cancelled) "נסה ייצוא מחדש" else "הפק MP4", fontWeight = FontWeight.ExtraBold)
                }
            }

            if (state.codecFallbackApplied) InfoCard("בוצעה התאמת codec אוטומטית למכשיר כדי להשלים את הייצוא.")
            state.outputPath?.let { path ->
                val verification = state.verification
                InfoCard(
                    buildString {
                        append("הסרטון מוכן ✓ · ")
                        append(path.substringAfterLast('/'))
                        verification?.let { append(" · ${it.width}×${it.height} · ${formatDuration(it.durationMs)}") }
                    }
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onSaveGallery,
                        enabled = !deliveryState.running && deliveryState.galleryUri == null,
                        modifier = Modifier.weight(1f).heightIn(min = 50.dp)
                    ) {
                        Icon(Icons.Default.PhotoLibrary, contentDescription = null)
                        Spacer(Modifier.width(5.dp))
                        Text(when { deliveryState.running -> "שומר…"; deliveryState.galleryUri != null -> "נשמר ✓"; else -> "לגלריה" })
                    }
                    Button(
                        onClick = onShare,
                        modifier = Modifier.weight(1f).heightIn(min = 50.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = WarmGold, contentColor = Color.Black)
                    ) {
                        Icon(Icons.Default.IosShare, contentDescription = null)
                        Spacer(Modifier.width(5.dp))
                        Text("שתף", fontWeight = FontWeight.Bold)
                    }
                }
                deliveryState.message?.let { InfoCard(it) }
                deliveryState.errorMessage?.let { InfoCard(it, error = true) }
            }
            state.errorMessage?.let { InfoCard(it, error = true) }
        }
    }
}

@Composable
private fun FxSlider(
    label: String,
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    valueText: String,
    onValueChange: (Float) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, fontWeight = FontWeight.Medium)
            Text(valueText, color = WarmGold, style = MaterialTheme.typography.bodySmall)
        }
        Slider(
            value = value.coerceIn(valueRange.start, valueRange.endInclusive),
            onValueChange = onValueChange,
            valueRange = valueRange,
            modifier = Modifier.semantics { contentDescription = label }
        )
    }
}

@Composable
private fun InfoCard(text: String, error: Boolean = false) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .semantics { if (error) liveRegion = LiveRegionMode.Assertive },
        colors = CardDefaults.cardColors(
            containerColor = if (error) RecordRose.copy(alpha = 0.14f) else ElectricViolet.copy(alpha = 0.12f)
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Text(
            text,
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            color = if (error) RecordRose else MaterialTheme.colorScheme.onSurface
        )
    }
}

private fun modeTitle(mode: ProductionMode): String = when (mode) {
    ProductionMode.Camera -> "פלייבק + מצלמה + הקלטת קול איכותית"
    ProductionMode.Background -> "פלייבק + רקע + הקלטת קול איכותית"
    ProductionMode.CameraWithBackground -> "פלייבק + צילום + רקע + הקלטת קול איכותית"
}

private fun formatDuration(ms: Long): String {
    if (ms <= 0L) return "00:00"
    val totalSeconds = ms / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return String.format(Locale.US, "%02d:%02d", minutes, seconds)
}
