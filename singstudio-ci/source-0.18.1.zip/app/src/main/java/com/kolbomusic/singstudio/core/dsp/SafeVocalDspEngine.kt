package com.kolbomusic.singstudio.core.dsp

import com.kolbomusic.singstudio.core.audio.WavFileTools
import java.io.File
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.sqrt

/**
 * Conservative constant-memory fallback used only when the normal studio DSP path
 * cannot finish on a device. It intentionally has very few moving parts: streaming
 * analysis, high-pass filtering, gentle compression, level trim and a hard safety
 * ceiling. The later adaptive mix + mastering stages still perform the musical
 * balance work, so a device-level DSP failure never has to stop finalization.
 */
class SafeVocalDspEngine {
    fun render(
        inputFile: File,
        requestedPreset: VocalPresetId,
        onProgress: (DspStage, Float) -> Unit = { _, _ -> }
    ): DspRenderResult {
        require(WavFileTools.validatePcm16Mono(inputFile)) { "קובץ ההקלטה אינו WAV תקין" }
        val sourceShaBefore = WavFileTools.sha256(inputFile)

        onProgress(DspStage.Loading, 0.04f)
        val analysis = analyse(inputFile) { fraction ->
            onProgress(DspStage.Analysing, 0.05f + fraction * 0.25f)
        }
        val resolved = if (requestedPreset == VocalPresetId.Auto) analysis.recommendedPreset else requestedPreset
        val preset = VocalPresets.resolve(requestedPreset, analysis)

        val processedDir = File(inputFile.parentFile, "processed").also { it.mkdirs() }
        val output = File(processedDir, inputFile.nameWithoutExtension + "-${resolved.name.lowercase()}-safe-vocal.wav")

        Pcm16WavRandomAccessReader(inputFile).use { reader ->
            val hp = Biquad.highPass(reader.sampleRate, preset.highPassHz.coerceIn(55.0, 110.0))
            val block = FloatArray(4096)
            val targetRmsDb = -20.0
            val staticTrimDb = (targetRmsDb - analysis.rmsDbfs).coerceIn(-4.0, 4.0)
            val staticTrim = 10.0.pow(staticTrimDb / 20.0)
            val ceiling = 10.0.pow(-1.2 / 20.0)
            var envelope = 0.0
            val attack = 0.985
            val release = 0.9995
            var frame = 0L

            Pcm16WavAtomicStreamWriter(output, reader.sampleRate).use { writer ->
                while (frame < reader.frameCount) {
                    val wanted = minOf(block.size.toLong(), reader.frameCount - frame).toInt()
                    val read = reader.readFrames(frame, block, 0, wanted)
                    check(read > 0) { "קריאת ההקלטה נקטעה בזמן fallback" }
                    for (i in 0 until read) {
                        var x = hp.process(block[i].toDouble()) * staticTrim
                        val level = abs(x)
                        val coeff = if (level > envelope) attack else release
                        envelope = level + coeff * (envelope - level)
                        val envDb = linearToDb(envelope.coerceAtLeast(1e-9))
                        if (envDb > -16.0) {
                            val over = envDb + 16.0
                            val reductionDb = -(over - over / 2.2)
                            x *= 10.0.pow(reductionDb / 20.0)
                        }
                        block[i] = x.coerceIn(-ceiling, ceiling).toFloat()
                    }
                    writer.write(block, 0, read)
                    frame += read
                    val fraction = frame.toFloat() / reader.frameCount.toFloat()
                    val stage = if (fraction < 0.65f) DspStage.Dynamics else DspStage.Finalising
                    onProgress(stage, 0.30f + fraction * 0.64f)
                }
                writer.commit()
            }
        }

        check(WavFileTools.validatePcm16Mono(output)) { "קובץ fallback vocal נכשל באימות WAV" }
        check(sourceShaBefore == WavFileTools.sha256(inputFile)) { "RAW integrity check failed" }
        val outputSha = WavFileTools.sha256(output)
        onProgress(DspStage.Completed, 1f)
        return DspRenderResult(output.absolutePath, outputSha, analysis, resolved)
    }

    private fun analyse(inputFile: File, onProgress: (Float) -> Unit): VocalAnalysis {
        Pcm16WavRandomAccessReader(inputFile).use { reader ->
            val block = FloatArray(4096)
            val quietWindows = ArrayList<Double>(64)
            val windowFrames = (reader.sampleRate / 20).coerceAtLeast(64)
            var windowEnergy = 0.0
            var windowCount = 0
            var frame = 0L
            var sumSquares = 0.0
            var samplesSeen = 0L
            var peak = 0.0
            var clipping = 0L
            while (frame < reader.frameCount) {
                val wanted = minOf(block.size.toLong(), reader.frameCount - frame).toInt()
                val read = reader.readFrames(frame, block, 0, wanted)
                check(read > 0) { "קריאת ההקלטה נקטעה בזמן ניתוח fallback" }
                for (i in 0 until read) {
                    val x = block[i].toDouble()
                    val a = abs(x)
                    peak = maxOf(peak, a)
                    sumSquares += x * x
                    if (a >= 0.985) clipping++
                    windowEnergy += x * x
                    windowCount++
                    if (windowCount >= windowFrames) {
                        quietWindows += sqrt(windowEnergy / windowCount)
                        if (quietWindows.size > 96) quietWindows.removeAt(quietWindows.lastIndex)
                        windowEnergy = 0.0
                        windowCount = 0
                    }
                }
                frame += read
                samplesSeen += read
                if ((frame / block.size) % 32L == 0L || frame == reader.frameCount) {
                    onProgress(frame.toFloat() / reader.frameCount.toFloat())
                }
            }
            if (windowCount > 0) quietWindows += sqrt(windowEnergy / windowCount)
            val rms = if (samplesSeen > 0L) sqrt(sumSquares / samplesSeen) else 0.0
            val rmsDb = linearToDb(rms)
            val peakDb = linearToDb(peak)
            val sorted = quietWindows.sorted()
            val noise = if (sorted.isEmpty()) -70.0 else linearToDb(sorted[(sorted.size * 0.20).toInt().coerceIn(0, sorted.lastIndex)])
            val dynamic = (peakDb - rmsDb).coerceIn(0.0, 40.0)
            val recommended = when {
                clipping > samplesSeen / 1000L -> VocalPresetId.Natural
                noise > -43.0 -> VocalPresetId.Studio
                rmsDb < -30.0 -> VocalPresetId.Studio
                dynamic > 17.0 -> VocalPresetId.Ballad
                else -> VocalPresetId.Mizrahi
            }
            return VocalAnalysis(
                durationMs = reader.frameCount * 1000L / reader.sampleRate,
                sampleRate = reader.sampleRate,
                peakDbfs = peakDb,
                rmsDbfs = rmsDb,
                estimatedNoiseFloorDbfs = noise,
                clippingSamples = clipping,
                dynamicRangeEstimateDb = dynamic,
                recommendedPreset = recommended
            )
        }
    }

    private fun linearToDb(value: Double): Double =
        if (value <= 1e-12) -120.0 else 20.0 * log10(value)
}
