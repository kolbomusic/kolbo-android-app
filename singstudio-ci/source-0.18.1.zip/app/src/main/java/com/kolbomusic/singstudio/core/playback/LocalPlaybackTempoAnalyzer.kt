package com.kolbomusic.singstudio.core.playback

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import com.kolbomusic.singstudio.core.dsp.BpmEstimate
import com.kolbomusic.singstudio.core.dsp.BpmEstimator
import com.kolbomusic.singstudio.core.model.PlaybackSource
import com.kolbomusic.singstudio.core.model.PlaybackSourceType
import java.nio.ByteOrder
import kotlin.math.max

/**
 * Decodes a bounded portion of a local playback source to mono PCM solely for tempo analysis.
 * It never modifies or exports the source file.
 */
class LocalPlaybackTempoAnalyzer(private val context: Context) {
    fun analyse(
        source: PlaybackSource,
        maxSeconds: Int = 45,
        shouldCancel: () -> Boolean = { false }
    ): BpmEstimate? {
        require(source.type != PlaybackSourceType.YouTube) { "YouTube tempo extraction is intentionally disabled" }
        val uri = source.uriString?.let(Uri::parse) ?: return null
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            extractor.setDataSource(context, uri, null)
            val trackIndex = (0 until extractor.trackCount).firstOrNull { index ->
                extractor.getTrackFormat(index).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true
            } ?: return null
            extractor.selectTrack(trackIndex)
            val inputFormat = extractor.getTrackFormat(trackIndex)
            val mime = inputFormat.getString(MediaFormat.KEY_MIME) ?: return null
            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(inputFormat, null, null, 0)
            codec.start()

            val builder = FloatSampleBuilder()
            val info = MediaCodec.BufferInfo()
            var inputEnded = false
            var outputEnded = false
            var outputSampleRate = inputFormat.intOrNull(MediaFormat.KEY_SAMPLE_RATE) ?: 48_000
            var channels = inputFormat.intOrNull(MediaFormat.KEY_CHANNEL_COUNT) ?: 2
            var pcmEncoding = AudioFormat.ENCODING_PCM_16BIT
            val maxSamples = max(1, outputSampleRate * maxSeconds)

            while (!outputEnded && builder.size < maxSamples && !shouldCancel()) {
                if (!inputEnded) {
                    val inputIndex = codec.dequeueInputBuffer(10_000L)
                    if (inputIndex >= 0) {
                        val inputBuffer = codec.getInputBuffer(inputIndex) ?: break
                        inputBuffer.clear()
                        val size = extractor.readSampleData(inputBuffer, 0)
                        if (size < 0) {
                            codec.queueInputBuffer(
                                inputIndex,
                                0,
                                0,
                                0L,
                                MediaCodec.BUFFER_FLAG_END_OF_STREAM
                            )
                            inputEnded = true
                        } else {
                            codec.queueInputBuffer(inputIndex, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }

                when (val outputIndex = codec.dequeueOutputBuffer(info, 10_000L)) {
                    MediaCodec.INFO_TRY_AGAIN_LATER -> Unit
                    MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val format = codec.outputFormat
                        outputSampleRate = format.intOrNull(MediaFormat.KEY_SAMPLE_RATE) ?: outputSampleRate
                        channels = format.intOrNull(MediaFormat.KEY_CHANNEL_COUNT) ?: channels
                        pcmEncoding = format.intOrNull(MediaFormat.KEY_PCM_ENCODING) ?: AudioFormat.ENCODING_PCM_16BIT
                    }
                    else -> if (outputIndex >= 0) {
                        val output = codec.getOutputBuffer(outputIndex)
                        if (output != null && info.size > 0) {
                            val slice = output.duplicate().apply {
                                position(info.offset)
                                limit(info.offset + info.size)
                                order(ByteOrder.LITTLE_ENDIAN)
                            }.slice().order(ByteOrder.LITTLE_ENDIAN)
                            when (pcmEncoding) {
                                AudioFormat.ENCODING_PCM_FLOAT -> {
                                    val floats = slice.asFloatBuffer()
                                    val frames = floats.remaining() / channels.coerceAtLeast(1)
                                    repeat(frames) {
                                        var sum = 0f
                                        repeat(channels.coerceAtLeast(1)) { sum += floats.get() }
                                        builder.add(sum / channels.coerceAtLeast(1))
                                    }
                                }
                                else -> {
                                    val shorts = slice.asShortBuffer()
                                    val frames = shorts.remaining() / channels.coerceAtLeast(1)
                                    repeat(frames) {
                                        var sum = 0f
                                        repeat(channels.coerceAtLeast(1)) { sum += shorts.get() / 32768f }
                                        builder.add(sum / channels.coerceAtLeast(1))
                                    }
                                }
                            }
                        }
                        outputEnded = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                        codec.releaseOutputBuffer(outputIndex, false)
                    }
                }
            }

            if (shouldCancel()) return null
            val pcm = builder.toArray(maxSamples)
            return BpmEstimator.estimate(pcm, outputSampleRate)
        } finally {
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            runCatching { extractor.release() }
        }
    }

    private fun MediaFormat.intOrNull(key: String): Int? =
        if (containsKey(key)) runCatching { getInteger(key) }.getOrNull() else null

    private class FloatSampleBuilder(initialCapacity: Int = 256 * 1024) {
        private var data = FloatArray(initialCapacity)
        var size: Int = 0
            private set

        fun add(value: Float) {
            if (size >= data.size) data = data.copyOf(data.size * 2)
            data[size++] = value.coerceIn(-1f, 1f)
        }

        fun toArray(max: Int): FloatArray = data.copyOf(minOf(size, max))
    }
}
