package com.kolbomusic.singstudio.core.dsp

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin

internal class Biquad private constructor(
    private val b0: Double,
    private val b1: Double,
    private val b2: Double,
    private val a1: Double,
    private val a2: Double
) {
    private var z1 = 0.0
    private var z2 = 0.0

    fun process(x: Double): Double {
        val y = b0 * x + z1
        z1 = b1 * x - a1 * y + z2
        z2 = b2 * x - a2 * y
        return y
    }

    companion object {
        fun highPass(sampleRate: Int, frequency: Double, q: Double = 0.707): Biquad {
            val w0 = 2.0 * PI * frequency / sampleRate
            val c = cos(w0)
            val s = sin(w0)
            val alpha = s / (2.0 * q)
            val a0 = 1.0 + alpha
            return Biquad(
                ((1.0 + c) / 2.0) / a0,
                (-(1.0 + c)) / a0,
                ((1.0 + c) / 2.0) / a0,
                (-2.0 * c) / a0,
                (1.0 - alpha) / a0
            )
        }

        fun lowPass(sampleRate: Int, frequency: Double, q: Double = 0.707): Biquad {
            val w0 = 2.0 * PI * frequency / sampleRate
            val c = cos(w0)
            val s = sin(w0)
            val alpha = s / (2.0 * q)
            val a0 = 1.0 + alpha
            return Biquad(
                ((1.0 - c) / 2.0) / a0,
                (1.0 - c) / a0,
                ((1.0 - c) / 2.0) / a0,
                (-2.0 * c) / a0,
                (1.0 - alpha) / a0
            )
        }

        fun peaking(sampleRate: Int, frequency: Double, q: Double, gainDb: Double): Biquad {
            val a = 10.0.pow(gainDb / 40.0)
            val w0 = 2.0 * PI * frequency / sampleRate
            val alpha = sin(w0) / (2.0 * q)
            val c = cos(w0)
            val a0 = 1.0 + alpha / a
            return Biquad(
                (1.0 + alpha * a) / a0,
                (-2.0 * c) / a0,
                (1.0 - alpha * a) / a0,
                (-2.0 * c) / a0,
                (1.0 - alpha / a) / a0
            )
        }

        fun lowShelf(sampleRate: Int, frequency: Double, gainDb: Double): Biquad {
            val a = 10.0.pow(gainDb / 40.0)
            val w0 = 2.0 * PI * frequency / sampleRate
            val c = cos(w0)
            val s = sin(w0)
            val sqrtA = kotlin.math.sqrt(a)
            val alpha = s / 2.0 * kotlin.math.sqrt(2.0)
            val beta = 2.0 * sqrtA * alpha
            val a0 = (a + 1.0) + (a - 1.0) * c + beta
            return Biquad(
                a * ((a + 1.0) - (a - 1.0) * c + beta) / a0,
                2.0 * a * ((a - 1.0) - (a + 1.0) * c) / a0,
                a * ((a + 1.0) - (a - 1.0) * c - beta) / a0,
                -2.0 * ((a - 1.0) + (a + 1.0) * c) / a0,
                ((a + 1.0) + (a - 1.0) * c - beta) / a0
            )
        }
    }
}
