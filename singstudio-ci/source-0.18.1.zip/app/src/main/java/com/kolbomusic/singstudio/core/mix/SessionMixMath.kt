package com.kolbomusic.singstudio.core.mix

import kotlin.math.floor

object SessionMixMath {
    fun vocalStartFrame(playbackStartOffsetMs: Long, vocalSampleRate: Int): Long =
        ((playbackStartOffsetMs.coerceAtLeast(0L) * vocalSampleRate.toLong()) / 1000L)

    fun sourcePositionForTargetFrame(
        targetFrame: Long,
        targetSampleRate: Int,
        sourceSampleRate: Int,
        sourceStartFrame: Long = 0L
    ): Double = sourceStartFrame + targetFrame.toDouble() * sourceSampleRate.toDouble() / targetSampleRate.toDouble()

    fun requiredSourceWindow(
        targetStartFrame: Long,
        targetFrameCount: Int,
        targetSampleRate: Int,
        sourceSampleRate: Int,
        sourceStartFrame: Long
    ): LongRange {
        if (targetFrameCount <= 0) return 0L..-1L
        val first = sourcePositionForTargetFrame(targetStartFrame, targetSampleRate, sourceSampleRate, sourceStartFrame)
        val last = sourcePositionForTargetFrame(
            targetStartFrame + targetFrameCount - 1L,
            targetSampleRate,
            sourceSampleRate,
            sourceStartFrame
        )
        return floor(first).toLong().coerceAtLeast(0L)..(floor(last).toLong() + 1L).coerceAtLeast(0L)
    }

    fun mixStereo(
        backingLeft: Float,
        backingRight: Float,
        vocal: Float,
        settings: SessionMixSettings
    ): Pair<Float, Float> {
        val safe = settings.sanitized()
        val playbackGain = safe.playbackGain
        val vocalGain = safe.vocalGain
        val masterGain = safe.masterGain
        return mixChannel(backingLeft, vocal, playbackGain, vocalGain, masterGain) to
            mixChannel(backingRight, vocal, playbackGain, vocalGain, masterGain)
    }

    fun mixChannel(
        backing: Float,
        vocal: Float,
        playbackGain: Float,
        vocalGain: Float,
        masterGain: Float
    ): Float = softLimit((backing * playbackGain + vocal * vocalGain) * masterGain)

    fun softLimit(value: Float): Float {
        val x = value.coerceIn(-3f, 3f)
        val absolute = kotlin.math.abs(x)
        if (absolute <= 0.95f) return x
        val sign = if (x < 0f) -1f else 1f
        val knee = kotlin.math.tanh(((absolute - 0.95f) / 0.05f).toDouble()).toFloat()
        return sign * (0.95f + 0.045f * knee)
    }
}
