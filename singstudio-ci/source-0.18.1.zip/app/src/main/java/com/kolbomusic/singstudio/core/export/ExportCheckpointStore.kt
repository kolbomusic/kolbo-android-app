package com.kolbomusic.singstudio.core.export

import org.json.JSONObject
import java.io.File

object ExportCheckpointStore {
    fun write(file: File, plan: ExportPlan, partialOutput: File, codec: ExportVideoCodec, phase: ExportPhase) {
        file.parentFile?.mkdirs()
        file.writeText(
            JSONObject()
                .put("schema", 1)
                .put("engineVersion", "0.10.0")
                .put("takeId", plan.takeId)
                .put("phase", phase.name)
                .put("codec", codec.name)
                .put("partialOutput", partialOutput.absolutePath)
                .put("trimStartMs", plan.trimStartMs)
                .put("trimEndMs", plan.trimEndMs)
                .put("outputDurationMs", plan.outputDurationMs)
                .put("width", plan.dimensions.width)
                .put("height", plan.dimensions.height)
                .put("updatedAtEpochMs", System.currentTimeMillis())
                .toString(2),
            Charsets.UTF_8
        )
    }

    fun clear(file: File) {
        if (file.exists()) file.delete()
    }

    fun stalePartialPath(file: File): String? = runCatching {
        if (!file.exists()) return null
        JSONObject(file.readText(Charsets.UTF_8)).optString("partialOutput").takeIf { it.isNotBlank() }
    }.getOrNull()
}
