package com.kolbomusic.singstudio.core.dsp

import kotlin.math.abs
import kotlin.math.sqrt

internal object VocalAnalyser {
    fun analyse(samples: FloatArray, sampleRate: Int): VocalAnalysis {
        if (samples.isEmpty()) {
            return VocalAnalysis(0L, sampleRate, -96.0, -96.0, -96.0, 0, 0.0, VocalPresetId.Natural)
        }
        var sumSquares = 0.0
        var peak = 0.0
        var clipping = 0L
        for (sample in samples) {
            val a = abs(sample.toDouble())
            sumSquares += sample.toDouble() * sample.toDouble()
            if (a > peak) peak = a
            if (a >= 0.985) clipping++
        }
        val rms = sqrt(sumSquares / samples.size)
        val rmsDb = VocalDynamics.linearToDb(rms)
        val peakDb = VocalDynamics.linearToDb(peak)

        val windowSize = (sampleRate / 20).coerceAtLeast(64)
        val noiseWindowLimit = minOf(samples.size, sampleRate * 2)
        val windowRms = ArrayList<Double>()
        var offset = 0
        while (offset + windowSize <= noiseWindowLimit) {
            var e = 0.0
            for (i in offset until offset + windowSize) {
                val s = samples[i].toDouble(); e += s * s
            }
            windowRms += sqrt(e / windowSize)
            offset += windowSize
        }
        val sorted = windowRms.sorted()
        val noiseLinear = if (sorted.isEmpty()) 1e-6 else sorted[(sorted.size * 0.25).toInt().coerceIn(0, sorted.lastIndex)]
        val noiseDb = VocalDynamics.linearToDb(noiseLinear)
        val dynamic = (peakDb - rmsDb).coerceIn(0.0, 40.0)

        val recommended = when {
            clipping > samples.size / 1000L -> VocalPresetId.Natural
            noiseDb > -43.0 -> VocalPresetId.Studio
            rmsDb < -30.0 -> VocalPresetId.Studio
            dynamic > 17.0 -> VocalPresetId.Ballad
            else -> VocalPresetId.Mizrahi
        }

        return VocalAnalysis(
            durationMs = samples.size.toLong() * 1000L / sampleRate,
            sampleRate = sampleRate,
            peakDbfs = peakDb,
            rmsDbfs = rmsDb,
            estimatedNoiseFloorDbfs = noiseDb,
            clippingSamples = clipping,
            dynamicRangeEstimateDb = dynamic,
            recommendedPreset = recommended
        )
    }
}
