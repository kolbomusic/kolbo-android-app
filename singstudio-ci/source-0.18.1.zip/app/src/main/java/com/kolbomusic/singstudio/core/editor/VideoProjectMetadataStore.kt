package com.kolbomusic.singstudio.core.editor

import com.kolbomusic.singstudio.core.model.PlaybackSource
import com.kolbomusic.singstudio.core.mix.SessionMixSettings
import com.kolbomusic.singstudio.core.dsp.VocalFxSettings
import com.kolbomusic.singstudio.core.model.VisualScene
import org.json.JSONObject
import java.io.File

object VideoProjectMetadataStore {
    fun save(
        directory: File,
        takeId: String,
        scene: VisualScene,
        state: VideoProjectState,
        playbackSource: PlaybackSource?,
        productionBackingSource: PlaybackSource?,
        rawVocalPath: String,
        processedVocalPath: String?,
        sessionMixPath: String?,
        sessionMixSettings: SessionMixSettings,
        vocalFxSettings: VocalFxSettings,
        cameraFilePath: String?,
        playbackStartOffsetMs: Long?,
        cameraStartOffsetMs: Long?
    ): File {
        directory.mkdirs()
        val safe = state.sanitized()
        val file = File(directory, "$takeId.video-project.json")
        val title = safe.title
        val export = safe.exportSettings
        val json = JSONObject()
            .put("schema", ProjectMigrationPolicy.CURRENT_SCHEMA)
            .put("engineVersion", "0.10.0")
            .put("savedAtEpochMs", System.currentTimeMillis())
            .put("takeId", takeId)
            .put("aspectRatio", safe.aspectRatio.name)
            .put("zoom", safe.zoom)
            .put("visualOffsetX", safe.visualOffsetX)
            .put("visualOffsetY", safe.visualOffsetY)
            .put("visualMode", scene.mode.name)
            .put("cameraFacing", scene.cameraFacing.name)
            .put("backgroundType", scene.background.type.name)
            .put("backgroundId", scene.background.id)
            .put("backgroundTitle", scene.background.title)
            .put("backgroundUri", scene.background.uriString)
            .put("rawVocalPath", rawVocalPath)
            .put("processedVocalPath", processedVocalPath)
            .put("sessionMixPath", sessionMixPath)
            .put("mix", JSONObject()
                .put("vocalGainDb", sessionMixSettings.vocalGainDb)
                .put("playbackGainDb", sessionMixSettings.playbackGainDb)
                .put("masterHeadroomDb", sessionMixSettings.masterHeadroomDb)
                .put("previewSource", sessionMixSettings.previewSource.name)
            )
            .put("vocalFx", JSONObject()
                .put("enabled", vocalFxSettings.enabled)
                .put("reverbMix", vocalFxSettings.reverbMix)
                .put("reverbRoom", vocalFxSettings.reverbRoom)
                .put("delayMix", vocalFxSettings.delayMix)
                .put("delayFeedback", vocalFxSettings.delayFeedback)
                .put("delayMs", vocalFxSettings.delayMs)
                .put("delayDivision", vocalFxSettings.delayDivision.name)
                .put("outputGainDb", vocalFxSettings.outputGainDb)
            )
            .put("export", JSONObject()
                .put("resolution", export.resolution.name)
                .put("codec", export.codec.name)
                .put("frameRate", export.frameRate)
                .put("allowCodecFallback", export.allowCodecFallback)
                .put("trimStartMs", export.trimStartMs)
                .put("trimEndMs", export.trimEndMs)
            )
            .put("cameraFilePath", cameraFilePath)
            .put("playbackStartOffsetMs", playbackStartOffsetMs)
            .put("cameraStartOffsetMs", cameraStartOffsetMs)
            .put("playbackSource", playbackSource?.let { source ->
                JSONObject()
                    .put("id", source.id)
                    .put("type", source.type.name)
                    .put("title", source.title)
                    .put("uriString", source.uriString)
                    .put("mimeType", source.mimeType)
                    .put("youtubeVideoId", source.youtubeVideoId)
            })
            .put("productionBackingSource", productionBackingSource?.let { source ->
                JSONObject()
                    .put("id", source.id)
                    .put("type", source.type.name)
                    .put("title", source.title)
                    .put("uriString", source.uriString)
                    .put("mimeType", source.mimeType)
                    .put("youtubeVideoId", source.youtubeVideoId)
            })
            .put("title", JSONObject()
                .put("text", title.text)
                .put("fontPreset", title.fontPreset.name)
                .put("fontSizeSp", title.fontSizeSp)
                .put("colorArgb", title.colorArgb)
                .put("outline", title.outline)
                .put("shadow", title.shadow)
                .put("xNormalized", title.xNormalized)
                .put("yNormalized", title.yNormalized)
                .put("animation", title.animation.name)
                .put("startMs", title.startMs)
                .put("endMs", title.endMs)
            )
        val partial = File(directory, "$takeId.video-project.json.partial")
        val backup = File(directory, "$takeId.video-project.json.bak")
        java.io.FileOutputStream(partial, false).use { output ->
            output.write(json.toString(2).toByteArray(Charsets.UTF_8))
            output.flush()
            output.fd.sync()
        }
        check(partial.length() > 0L) { "Project metadata write produced an empty file" }
        if (backup.exists()) backup.delete()
        if (file.exists()) check(file.renameTo(backup)) { "Unable to protect previous project metadata" }
        if (!partial.renameTo(file)) {
            if (backup.exists()) backup.renameTo(file)
            throw IllegalStateException("Unable to commit project metadata")
        }
        backup.delete()
        return file
    }
}
