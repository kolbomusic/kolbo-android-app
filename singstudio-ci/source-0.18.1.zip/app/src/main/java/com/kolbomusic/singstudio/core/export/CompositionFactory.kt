@file:androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)

package com.kolbomusic.singstudio.core.export

import android.content.Context
import android.util.TypedValue
import android.net.Uri
import android.media.MediaMetadataRetriever
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import com.kolbomusic.singstudio.core.editor.VideoProjectState
import com.kolbomusic.singstudio.core.model.BuiltInBackgrounds
import com.kolbomusic.singstudio.core.model.ProductionMode
import com.kolbomusic.singstudio.core.model.PlaybackSource
import com.kolbomusic.singstudio.core.model.PlaybackSourceType
import com.kolbomusic.singstudio.core.model.VisualBackgroundType
import com.kolbomusic.singstudio.core.model.VisualScene
import java.io.File

class CompositionFactory(private val context: Context) {
    data class PreparedComposition(
        val composition: Composition,
        val generatedFiles: List<File>,
        val containsMultipleVideoInputs: Boolean
    )

    fun build(
        plan: ExportPlan,
        scene: VisualScene,
        project: VideoProjectState,
        playbackSource: PlaybackSource?,
        sessionMixFile: File,
        cameraFile: File?,
        workingDirectory: File
    ): PreparedComposition {
        require(sessionMixFile.isFile && sessionMixFile.length() > 44L) { "Session Mix file is missing" }
        val generated = mutableListOf<File>()
        val sequences = mutableListOf<EditedMediaItemSequence>()
        val visualSequences = mutableListOf<EditedMediaItemSequence>()

        val karaokeVideo = playbackSource?.takeIf { it.type == PlaybackSourceType.LocalVideo && !it.uriString.isNullOrBlank() }
        if (karaokeVideo != null) {
            // Final-performance layout: the karaoke video (including its embedded lyrics) is the
            // full-frame base. Camera is composed as a PiP layer when the selected mode uses it.
            visualSequences += buildPlaybackVideoSequence(plan, karaokeVideo, project)
            if (scene.mode.usesCamera) {
                visualSequences += buildCameraSequence(plan, project, requireNotNull(cameraFile), framed = true)
            }
        } else {
            when (scene.mode) {
                ProductionMode.Camera -> {
                    visualSequences += buildCameraSequence(plan, project, requireNotNull(cameraFile))
                }
                ProductionMode.Background -> {
                    visualSequences += buildBackgroundSequence(plan, scene, project, workingDirectory, generated, applyProjectTransform = true)
                }
                ProductionMode.CameraWithBackground -> {
                    visualSequences += buildBackgroundSequence(plan, scene, project, workingDirectory, generated, applyProjectTransform = false)
                    visualSequences += buildCameraSequence(plan, project, requireNotNull(cameraFile), framed = true)
                }
            }
        }
        sequences += visualSequences
        sequences += buildAudioSequence(plan, sessionMixFile)

        val compositionEffects = mutableListOf<androidx.media3.common.Effect>()
        if (plan.titleVisible) {
            compositionEffects += OverlayEffect(
                listOf(
                    KolboTitleCanvasOverlay(
                        title = project.title,
                        density = TypedValue.applyDimension(
                            TypedValue.COMPLEX_UNIT_SP,
                            1f,
                            context.resources.displayMetrics
                        ),
                        startMs = plan.adjustedTitleStartMs,
                        endMs = plan.adjustedTitleEndMs
                    )
                )
            )
        }

        val builder = Composition.Builder(sequences)
            .setTransmuxAudio(false)
            .setTransmuxVideo(false)
            .setEffects(Effects(emptyList(), compositionEffects))

        if (visualSequences.size > 1) {
            builder.setVideoCompositorSettings(
                KolboVideoCompositorSettings(
                    outputWidth = plan.dimensions.width,
                    outputHeight = plan.dimensions.height,
                    cameraInputId = 1,
                    cameraScale = (0.32f * project.zoom.coerceIn(0.85f, 1.15f)).coerceIn(0.26f, 0.40f),
                    cameraOffsetX = project.visualOffsetX,
                    cameraOffsetY = project.visualOffsetY
                )
            )
        }

        return PreparedComposition(
            composition = builder.build(),
            generatedFiles = generated,
            containsMultipleVideoInputs = visualSequences.size > 1
        )
    }


    private fun buildPlaybackVideoSequence(
        plan: ExportPlan,
        source: PlaybackSource,
        project: VideoProjectState
    ): EditedMediaItemSequence {
        val uri = Uri.parse(requireNotNull(source.uriString) { "Karaoke video URI is missing" })
        val media = MediaItem.Builder()
            .setUri(uri)
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(plan.trimStartMs)
                    .setEndPositionMs(plan.trimEndMs)
                    .build()
            )
            .build()
        val effects = mutableListOf<androidx.media3.common.Effect>()
        effects += Presentation.createForWidthAndHeight(
            plan.dimensions.width,
            plan.dimensions.height,
            // Karaoke lyrics are part of the source video. Preserve every source pixel
            // instead of cropping top/bottom or left/right when aspect ratios differ.
            Presentation.LAYOUT_SCALE_TO_FIT
        )
        effects += PositionZoomTransformation(project.zoom, project.visualOffsetX, project.visualOffsetY)
        val item = EditedMediaItem.Builder(media)
            .setRemoveAudio(true)
            .setDurationUs(readDurationUs(uri))
            .setFrameRate(plan.settings.frameRate)
            .setEffects(Effects(emptyList(), effects))
            .build()
        return EditedMediaItemSequence.withVideoFrom(listOf(item))
    }

    private fun buildAudioSequence(plan: ExportPlan, sessionMixFile: File): EditedMediaItemSequence {
        val media = MediaItem.Builder()
            .setUri(Uri.fromFile(sessionMixFile))
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(plan.trimStartMs)
                    .setEndPositionMs(plan.trimEndMs)
                    .build()
            )
            .build()
        val edited = EditedMediaItem.Builder(media)
            .setRemoveVideo(true)
            .setDurationUs(plan.sourceDurationMs * 1000L)
            .build()
        return EditedMediaItemSequence.withAudioFrom(listOf(edited))
    }

    private fun buildCameraSequence(
        plan: ExportPlan,
        project: VideoProjectState,
        cameraFile: File,
        framed: Boolean = false
    ): EditedMediaItemSequence {
        require(cameraFile.isFile && cameraFile.length() > 0L) { "Camera video file is missing" }
        val camera = requireNotNull(plan.camera)
        val media = MediaItem.Builder()
            .setUri(Uri.fromFile(cameraFile))
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(camera.clipStartMs)
                    .setEndPositionMs(camera.clipEndMs)
                    .build()
            )
            .build()
        val effects = mutableListOf<androidx.media3.common.Effect>()
        effects += Presentation.createForWidthAndHeight(
            plan.dimensions.width,
            plan.dimensions.height,
            Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP
        )
        if (!framed) {
            effects += PositionZoomTransformation(project.zoom, project.visualOffsetX, project.visualOffsetY)
        }
        val item = EditedMediaItem.Builder(media)
            .setRemoveAudio(true)
            .setDurationUs(readDurationUs(Uri.fromFile(cameraFile)).coerceAtLeast(camera.clipEndMs * 1000L))
            .setFrameRate(plan.settings.frameRate)
            .setEffects(Effects(emptyList(), effects))
            .build()
        val builder = EditedMediaItemSequence.Builder(setOf(C.TRACK_TYPE_VIDEO))
        if (camera.gapBeforeMs > 0L) builder.addGap(camera.gapBeforeMs * 1000L)
        builder.addItem(item)
        return builder.build()
    }

    private fun buildBackgroundSequence(
        plan: ExportPlan,
        scene: VisualScene,
        project: VideoProjectState,
        workingDirectory: File,
        generated: MutableList<File>,
        applyProjectTransform: Boolean
    ): EditedMediaItemSequence {
        val background = scene.background
        val videoEffects = mutableListOf<androidx.media3.common.Effect>()
        videoEffects += Presentation.createForWidthAndHeight(
            plan.dimensions.width,
            plan.dimensions.height,
            Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP
        )
        if (applyProjectTransform) {
            videoEffects += PositionZoomTransformation(project.zoom, project.visualOffsetX, project.visualOffsetY)
        }
        val effects = Effects(emptyList(), videoEffects)

        return when (background.type) {
            VisualBackgroundType.Video -> {
                val uri = Uri.parse(requireNotNull(background.uriString) { "Background video URI is missing" })
                val item = EditedMediaItem.Builder(MediaItem.fromUri(uri))
                    .setRemoveAudio(true)
                    .setDurationUs(readDurationUs(uri))
                    .setFrameRate(plan.settings.frameRate)
                    .setEffects(effects)
                    .build()
                EditedMediaItemSequence.Builder(setOf(C.TRACK_TYPE_VIDEO))
                    .addItem(item)
                    .setIsLooping(true)
                    .build()
            }
            VisualBackgroundType.Image -> {
                buildImageBackgroundSequence(
                    uri = Uri.parse(requireNotNull(background.uriString) { "Background image URI is missing" }),
                    plan = plan,
                    effects = effects
                )
            }
            VisualBackgroundType.BuiltIn -> {
                val preset = BuiltInBackgrounds.byId(background.id) ?: BuiltInBackgrounds.presets.first()
                val image = File(workingDirectory, "generated-background-${preset.id}-${plan.dimensions.width}x${plan.dimensions.height}.png")
                BuiltInBackgroundRenderer.render(preset, plan.dimensions.width, plan.dimensions.height, image)
                generated += image
                buildImageBackgroundSequence(Uri.fromFile(image), plan, effects)
            }
            VisualBackgroundType.None -> {
                val preset = BuiltInBackgrounds.presets.first()
                val image = File(workingDirectory, "generated-background-default-${plan.dimensions.width}x${plan.dimensions.height}.png")
                BuiltInBackgroundRenderer.render(preset, plan.dimensions.width, plan.dimensions.height, image)
                generated += image
                buildImageBackgroundSequence(Uri.fromFile(image), plan, effects)
            }
        }
    }

    private fun buildImageBackgroundSequence(
        uri: Uri,
        plan: ExportPlan,
        effects: Effects
    ): EditedMediaItemSequence {
        val media = MediaItem.Builder()
            .setUri(uri)
            .setImageDurationMs(plan.outputDurationMs)
            .build()
        val item = EditedMediaItem.Builder(media)
            .setFrameRate(plan.settings.frameRate)
            .setEffects(effects)
            .build()
        return EditedMediaItemSequence.withVideoFrom(listOf(item))
    }
    private fun readDurationUs(uri: Uri): Long {
        val retriever = MediaMetadataRetriever()
        return try {
            if (uri.scheme == "file") retriever.setDataSource(requireNotNull(uri.path)) else retriever.setDataSource(context, uri)
            val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull()
                ?.coerceAtLeast(1L)
                ?: 1L
            durationMs * 1000L
        } finally {
            retriever.release()
        }
    }

}
