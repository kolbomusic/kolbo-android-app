package com.kolbomusic.singstudio.core.dsp

import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import kotlin.math.roundToInt

internal data class MonoWav(
    val sampleRate: Int,
    val samples: FloatArray
)

internal object WavPcm16 {
    fun readMono(file: File): MonoWav {
        require(file.exists() && file.length() >= 44L) { "קובץ WAV חסר או פגום" }
        RandomAccessFile(file, "r").use { raf ->
            val riff = ByteArray(4).also(raf::readFully).toString(Charsets.US_ASCII)
            require(riff == "RIFF") { "פורמט WAV לא נתמך" }
            raf.skipBytes(4)
            val wave = ByteArray(4).also(raf::readFully).toString(Charsets.US_ASCII)
            require(wave == "WAVE") { "פורמט WAV לא נתמך" }

            var sampleRate = 0
            var channels = 0
            var bits = 0
            var dataOffset = -1L
            var dataSize = 0L
            while (raf.filePointer + 8 <= raf.length()) {
                val chunkId = ByteArray(4).also(raf::readFully).toString(Charsets.US_ASCII)
                val chunkSize = raf.readUInt32LE()
                val chunkStart = raf.filePointer
                when (chunkId) {
                    "fmt " -> {
                        val format = raf.readUInt16LE()
                        channels = raf.readUInt16LE()
                        sampleRate = raf.readUInt32LE().toInt()
                        raf.skipBytes(6)
                        bits = raf.readUInt16LE()
                        require(format == 1) { "נדרש PCM WAV" }
                    }
                    "data" -> {
                        dataOffset = raf.filePointer
                        dataSize = chunkSize
                        break
                    }
                }
                raf.seek(chunkStart + chunkSize + (chunkSize and 1L))
            }
            require(dataOffset >= 0 && dataSize > 0) { "WAV ללא נתוני אודיו" }
            require(channels == 1 && bits == 16) { "בשלב זה מנוע ה־DSP דורש WAV Mono 16-bit" }
            require(sampleRate in 8_000..192_000) { "קצב דגימה לא תקין" }

            val sampleCountLong = dataSize / 2L
            require(sampleCountLong <= Int.MAX_VALUE) { "הטייק ארוך מדי לעיבוד" }
            val estimatedMemory = sampleCountLong * 10L
            val safeBudget = Runtime.getRuntime().maxMemory() / 3L
            require(estimatedMemory < safeBudget) {
                "אין מספיק זיכרון לעיבוד בטוח של הטייק במכשיר הזה"
            }

            raf.seek(dataOffset)
            val samples = FloatArray(sampleCountLong.toInt())
            val buffer = ByteArray(64 * 1024)
            var sampleIndex = 0
            var pendingLowByte: Int? = null
            var remaining = dataSize
            while (remaining > 0L && sampleIndex < samples.size) {
                val wanted = minOf(buffer.size.toLong(), remaining).toInt()
                val count = raf.read(buffer, 0, wanted)
                if (count <= 0) break
                remaining -= count
                var i = 0
                if (pendingLowByte != null && count > 0) {
                    val lowByte = pendingLowByte
                    val value = (lowByte and 0xFF) or (buffer[0].toInt() shl 8)
                    samples[sampleIndex++] = value.toShort() / 32768f
                    pendingLowByte = null
                    i = 1
                }
                while (i + 1 < count && sampleIndex < samples.size) {
                    val value = (buffer[i].toInt() and 0xFF) or (buffer[i + 1].toInt() shl 8)
                    samples[sampleIndex++] = value.toShort() / 32768f
                    i += 2
                }
                if (i < count) pendingLowByte = buffer[i].toInt()
            }
            require(sampleIndex == samples.size) { "קריאת WAV נקטעה" }
            return MonoWav(sampleRate, samples)
        }
    }

    fun writeMonoAtomic(destination: File, sampleRate: Int, samples: FloatArray) {
        destination.parentFile?.mkdirs()
        val temp = File(destination.parentFile, destination.name + ".partial")
        if (temp.exists()) temp.delete()
        FileOutputStream(temp).use { fos ->
            val out = BufferedOutputStream(fos, 64 * 1024)
                val dataBytes = samples.size.toLong() * 2L
                out.write("RIFF".toByteArray(Charsets.US_ASCII))
                out.writeU32LE(36L + dataBytes)
                out.write("WAVE".toByteArray(Charsets.US_ASCII))
                out.write("fmt ".toByteArray(Charsets.US_ASCII))
                out.writeU32LE(16L)
                out.writeU16LE(1)
                out.writeU16LE(1)
                out.writeU32LE(sampleRate.toLong())
                out.writeU32LE(sampleRate.toLong() * 2L)
                out.writeU16LE(2)
                out.writeU16LE(16)
                out.write("data".toByteArray(Charsets.US_ASCII))
                out.writeU32LE(dataBytes)

                val buffer = ByteArray(64 * 1024)
                var bi = 0
                for (sample in samples) {
                    val pcm = (sample.coerceIn(-1f, 0.999969f) * 32768f).roundToInt().coerceIn(-32768, 32767)
                    buffer[bi++] = (pcm and 0xFF).toByte()
                    buffer[bi++] = ((pcm ushr 8) and 0xFF).toByte()
                    if (bi >= buffer.size - 1) {
                        out.write(buffer, 0, bi)
                        bi = 0
                    }
                }
                if (bi > 0) out.write(buffer, 0, bi)
                out.flush()
            fos.fd.sync()
        }
        if (destination.exists()) destination.delete()
        runCatching {
            Files.move(temp.toPath(), destination.toPath(), StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING)
        }.getOrElse {
            Files.move(temp.toPath(), destination.toPath(), StandardCopyOption.REPLACE_EXISTING)
        }
    }

    private fun RandomAccessFile.readUInt16LE(): Int {
        val b0 = readUnsignedByte()
        val b1 = readUnsignedByte()
        return b0 or (b1 shl 8)
    }

    private fun RandomAccessFile.readUInt32LE(): Long {
        val b0 = readUnsignedByte().toLong()
        val b1 = readUnsignedByte().toLong()
        val b2 = readUnsignedByte().toLong()
        val b3 = readUnsignedByte().toLong()
        return b0 or (b1 shl 8) or (b2 shl 16) or (b3 shl 24)
    }

    private fun BufferedOutputStream.writeU16LE(value: Int) {
        write(value and 0xFF)
        write((value ushr 8) and 0xFF)
    }

    private fun BufferedOutputStream.writeU32LE(value: Long) {
        write((value and 0xFF).toInt())
        write(((value ushr 8) and 0xFF).toInt())
        write(((value ushr 16) and 0xFF).toInt())
        write(((value ushr 24) and 0xFF).toInt())
    }
}
