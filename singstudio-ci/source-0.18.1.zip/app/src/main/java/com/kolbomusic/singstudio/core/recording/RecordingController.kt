package com.kolbomusic.singstudio.core.recording

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class RecordingController(private val context: Context) {

    fun start() {
        val intent = Intent(context, RecordingForegroundService::class.java)
            .setAction(RecordingForegroundService.ACTION_START)
        ContextCompat.startForegroundService(context, intent)
    }

    fun stop() {
        val intent = Intent(context, RecordingForegroundService::class.java)
            .setAction(RecordingForegroundService.ACTION_STOP)
        context.startService(intent)
    }
}
