package com.kolbomusic.singstudio.ui.accessibility

import androidx.compose.runtime.compositionLocalOf

data class KolboAccessibilityPreferences(
    val largeControls: Boolean = true,
    val reduceMotion: Boolean = false
)

val LocalKolboAccessibility = compositionLocalOf { KolboAccessibilityPreferences() }
