package com.kolbomusic.singstudio.core.library

import android.content.Context
import java.io.File
import java.util.UUID

class LibraryRepository(context: Context) {
    private val appContext = context.applicationContext
    private val store = LibraryIndexStore(appContext)
    private val thumbnails = VideoThumbnailGenerator(appContext)
    private val lock = Any()

    fun load(): List<LibraryItem> = synchronized(lock) {
        val stored = store.load()
        val clean = sanitize(stored)
        if (clean != stored) store.save(clean)
        clean
    }

    fun registerTakeDraft(
        takeId: String,
        title: String,
        rawVocalPath: String,
        sourceTitle: String?,
        aspectRatio: String?
    ): LibraryItem = synchronized(lock) {
        val raw = File(rawVocalPath)
        require(raw.isFile) { "RAW vocal is missing" }
        val now = System.currentTimeMillis()
        val items = store.load().toMutableList()
        val existingIndex = items.indexOfFirst { it.takeId == takeId }
        val existing = items.getOrNull(existingIndex)
        val item = (existing ?: LibraryItem(
            id = UUID.nameUUIDFromBytes(takeId.toByteArray(Charsets.UTF_8)).toString(),
            takeId = takeId,
            title = normalizedTitle(title, sourceTitle),
            createdAtEpochMs = raw.lastModified().takeIf { it > 0L } ?: now,
            updatedAtEpochMs = now,
            status = LibraryItemStatus.Draft
        )).copy(
            title = normalizedTitle(title, sourceTitle),
            updatedAtEpochMs = now,
            rawVocalPath = raw.absolutePath,
            sourceTitle = sourceTitle,
            aspectRatio = aspectRatio
        )
        if (existingIndex >= 0) items[existingIndex] = item else items += item
        store.save(sanitize(items))
        item
    }

    fun registerDraft(
        takeId: String,
        title: String,
        projectPath: String,
        sourceTitle: String?,
        aspectRatio: String?
    ): LibraryItem = synchronized(lock) {
        val now = System.currentTimeMillis()
        val items = store.load().toMutableList()
        val existingIndex = items.indexOfFirst { it.takeId == takeId }
        val existing = items.getOrNull(existingIndex)
        val item = (existing ?: LibraryItem(
            id = UUID.nameUUIDFromBytes(takeId.toByteArray(Charsets.UTF_8)).toString(),
            takeId = takeId,
            title = normalizedTitle(title, sourceTitle),
            createdAtEpochMs = now,
            updatedAtEpochMs = now,
            status = LibraryItemStatus.Draft
        )).copy(
            title = normalizedTitle(title, sourceTitle),
            updatedAtEpochMs = now,
            status = if (existing?.status == LibraryItemStatus.Ready) LibraryItemStatus.Ready else LibraryItemStatus.Draft,
            projectPath = projectPath,
            sourceTitle = sourceTitle,
            aspectRatio = aspectRatio
        )
        if (existingIndex >= 0) items[existingIndex] = item else items += item
        store.save(sanitize(items))
        item
    }

    fun registerExport(
        takeId: String,
        title: String,
        exportFile: File,
        projectPath: String?,
        sourceTitle: String?,
        aspectRatio: String?,
        durationMs: Long,
        sha256: String?
    ): LibraryItem = synchronized(lock) {
        require(exportFile.isFile && exportFile.length() > 0L) { "Export file is missing" }
        val now = System.currentTimeMillis()
        val items = store.load().toMutableList()
        val existingIndex = items.indexOfFirst { it.takeId == takeId }
        val existing = items.getOrNull(existingIndex)
        val id = existing?.id ?: UUID.nameUUIDFromBytes(takeId.toByteArray(Charsets.UTF_8)).toString()
        val thumb = thumbnails.create(exportFile, id) ?: existing?.thumbnailPath
        val item = (existing ?: LibraryItem(
            id = id,
            takeId = takeId,
            title = normalizedTitle(title, sourceTitle),
            createdAtEpochMs = exportFile.lastModified().takeIf { it > 0L } ?: now,
            updatedAtEpochMs = now,
            status = LibraryItemStatus.Ready
        )).copy(
            title = normalizedTitle(title, sourceTitle),
            updatedAtEpochMs = now,
            status = LibraryItemStatus.Ready,
            projectPath = projectPath ?: existing?.projectPath,
            exportPath = exportFile.absolutePath,
            thumbnailPath = thumb,
            durationMs = durationMs.coerceAtLeast(0L),
            fileSizeBytes = exportFile.length(),
            sha256 = sha256,
            aspectRatio = aspectRatio,
            sourceTitle = sourceTitle
        )
        if (existingIndex >= 0) items[existingIndex] = item else items += item
        store.save(sanitize(items))
        item
    }

    fun rename(id: String, title: String): LibraryItem? = mutate(id) { item ->
        item.copy(title = title.trim().take(120).ifBlank { item.title }, updatedAtEpochMs = System.currentTimeMillis())
    }

    fun setFavorite(id: String, favorite: Boolean): LibraryItem? = mutate(id) { item ->
        item.copy(favorite = favorite, updatedAtEpochMs = System.currentTimeMillis())
    }

    fun setGalleryUri(id: String, uri: String): LibraryItem? = mutate(id) { item ->
        item.copy(galleryUri = uri, updatedAtEpochMs = System.currentTimeMillis())
    }

    fun deletePrivateProject(id: String): Boolean = synchronized(lock) {
        val items = store.load().toMutableList()
        val index = items.indexOfFirst { it.id == id }
        if (index < 0) return@synchronized false
        val item = items[index]
        listOfNotNull(item.thumbnailPath, item.exportPath, item.projectPath, item.rawVocalPath).forEach { path ->
            safeDeleteAppOwned(path)
        }
        items.removeAt(index)
        store.save(sanitize(items))
        true
    }

    fun find(id: String): LibraryItem? = load().firstOrNull { it.id == id }

    private fun mutate(id: String, transform: (LibraryItem) -> LibraryItem): LibraryItem? = synchronized(lock) {
        val items = store.load().toMutableList()
        val index = items.indexOfFirst { it.id == id }
        if (index < 0) return@synchronized null
        val updated = transform(items[index])
        items[index] = updated
        store.save(sanitize(items))
        updated
    }

    private fun safeDeleteAppOwned(path: String) {
        val file = File(path)
        if (!file.exists()) return
        val allowedRoots = listOfNotNull(
            appContext.filesDir,
            appContext.getExternalFilesDir(null),
            appContext.getExternalFilesDir(android.os.Environment.DIRECTORY_MUSIC),
            appContext.getExternalFilesDir(android.os.Environment.DIRECTORY_MOVIES)
        ).map { runCatching { it.canonicalFile }.getOrNull() }
        val target = runCatching { file.canonicalFile }.getOrNull() ?: return
        if (allowedRoots.any { root -> root != null && target.path.startsWith(root.path + File.separator) }) {
            runCatching { if (target.isDirectory) target.deleteRecursively() else target.delete() }
        }
    }

    private fun sanitize(items: List<LibraryItem>): List<LibraryItem> = items
        .distinctBy { it.id }
        .map { item ->
            val exportExists = item.exportPath?.let { File(it).isFile } == true
            val projectExists = item.projectPath?.let { File(it).isFile } == true
            val rawExists = item.rawVocalPath?.let { File(it).isFile } == true
            when {
                item.status == LibraryItemStatus.Ready && exportExists -> item
                projectExists || rawExists -> item.copy(status = LibraryItemStatus.Draft, exportPath = null, fileSizeBytes = 0L, sha256 = null)
                else -> item
            }
        }
        .filter { item ->
            item.rawVocalPath?.let { File(it).exists() } == true ||
                item.projectPath?.let { File(it).exists() } == true ||
                item.exportPath?.let { File(it).exists() } == true
        }

    private fun normalizedTitle(title: String, sourceTitle: String?): String =
        title.trim().take(120).ifBlank { sourceTitle?.trim()?.take(120).orEmpty() }.ifBlank { "ביצוע חדש" }
}
