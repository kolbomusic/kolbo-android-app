package com.kolbomusic.singstudio.core.camera

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Environment
import android.os.SystemClock
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.kolbomusic.singstudio.core.model.CameraFacing
import com.kolbomusic.singstudio.core.model.OutputAspectRatio
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File


data class CameraCaptureState(
    val bound: Boolean = false,
    val recording: Boolean = false,
    val facing: CameraFacing = CameraFacing.Front,
    val activeFilePath: String? = null,
    val startedElapsedRealtimeNs: Long? = null,
    val recordedDurationNs: Long = 0L,
    val finalizedFilePath: String? = null,
    val errorMessage: String? = null
)

data class CameraCaptureStart(
    val expectedFinalFilePath: String,
    val startedElapsedRealtimeNs: Long
)

data class CameraCaptureResult(
    val file: File,
    val startedElapsedRealtimeNs: Long,
    val durationNs: Long
)

class CameraCaptureEngine(private val appContext: Context) {
    private val _state = MutableStateFlow(CameraCaptureState())
    val state: StateFlow<CameraCaptureState> = _state.asStateFlow()

    private var provider: ProcessCameraProvider? = null
    private var preview: Preview? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var activeRecording: Recording? = null
    private var startDeferred: CompletableDeferred<CameraCaptureStart>? = null
    private var finalizeDeferred: CompletableDeferred<Result<CameraCaptureResult>>? = null
    private var activeFile: File? = null
    private var expectedFinalFile: File? = null

    fun bind(
        lifecycleOwner: LifecycleOwner,
        previewView: PreviewView,
        facing: CameraFacing,
        preferConcurrentVideoCompatibility: Boolean = false,
        onError: (String) -> Unit = {}
    ) {
        if (ContextCompat.checkSelfPermission(appContext, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            val message = "נדרשת הרשאת מצלמה"
            _state.value = _state.value.copy(bound = false, errorMessage = message)
            onError(message)
            return
        }

        val mainExecutor = ContextCompat.getMainExecutor(appContext)
        ProcessCameraProvider.getInstance(appContext).addListener({
            runCatching {
                if (ContextCompat.checkSelfPermission(appContext, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                    throw SecurityException("נדרשת הרשאת מצלמה")
                }
                val cameraProvider = ProcessCameraProvider.getInstance(appContext).get()
                val selector = selectorFor(facing)
                val previewUseCase = Preview.Builder().build().also {
                    it.surfaceProvider = previewView.surfaceProvider
                }
                // YouTube playback already consumes a hardware decoder/compositor path.
                // The camera is only a small PiP in that mode, so prefer SD first to
                // preserve decoder/encoder headroom and keep the karaoke video visible.
                val qualityOrder = if (preferConcurrentVideoCompatibility) {
                    listOf(Quality.SD, Quality.HD, Quality.FHD)
                } else {
                    listOf(Quality.HD, Quality.FHD, Quality.SD)
                }
                val recorder = Recorder.Builder()
                    .setQualitySelector(
                        QualitySelector.fromOrderedList(
                            qualityOrder,
                            FallbackStrategy.lowerQualityOrHigherThan(Quality.SD)
                        )
                    )
                    .build()
                val video = VideoCapture.withOutput(recorder)

                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(lifecycleOwner, selector, previewUseCase, video)

                provider = cameraProvider
                preview = previewUseCase
                videoCapture = video
                _state.value = _state.value.copy(
                    bound = true,
                    facing = facing,
                    errorMessage = null
                )
            }.onFailure { throwable ->
                val message = throwable.message ?: "לא ניתן לפתוח את המצלמה"
                _state.value = _state.value.copy(bound = false, errorMessage = message)
                onError(message)
            }
        }, mainExecutor)
    }

    fun rebind(
        lifecycleOwner: LifecycleOwner,
        previewView: PreviewView,
        facing: CameraFacing,
        preferConcurrentVideoCompatibility: Boolean = false,
        onError: (String) -> Unit = {}
    ) {
        check(activeRecording == null) { "לא ניתן להחליף מצלמה באמצע טייק" }
        bind(lifecycleOwner, previewView, facing, preferConcurrentVideoCompatibility, onError)
    }

    fun startRecording(takeId: String, aspectRatio: OutputAspectRatio): Result<Unit> {
        if (activeRecording != null) return Result.failure(IllegalStateException("המצלמה כבר מקליטה"))
        val capture = videoCapture ?: return Result.failure(IllegalStateException("המצלמה עדיין לא מוכנה"))

        return runCatching {
            val directory = videoDirectory().also { it.mkdirs() }
            check(directory.usableSpace >= MIN_FREE_SPACE_BYTES) {
                "אין מספיק מקום פנוי לצילום וידאו. פנה לפחות 256MB."
            }
            val file = File(directory, "$takeId-camera.mp4.partial")
            val finalFile = File(directory, "$takeId-camera.mp4")
            if (file.exists()) file.delete()
            if (finalFile.exists()) finalFile.delete()
            activeFile = file
            expectedFinalFile = finalFile
            startDeferred = CompletableDeferred()
            finalizeDeferred = CompletableDeferred()

            val outputOptions = FileOutputOptions.Builder(file).build()
            // Deliberately do not call withAudioEnabled(): vocal RAW is captured by
            // the dedicated audio engine. This prevents duplicated/processed audio.
            activeRecording = capture.output
                .prepareRecording(appContext, outputOptions)
                .start(ContextCompat.getMainExecutor(appContext)) { event ->
                    when (event) {
                        is VideoRecordEvent.Start -> {
                            val startedNs = SystemClock.elapsedRealtimeNanos()
                            _state.value = _state.value.copy(
                                recording = true,
                                activeFilePath = file.absolutePath,
                                startedElapsedRealtimeNs = startedNs,
                                finalizedFilePath = null,
                                errorMessage = null
                            )
                            startDeferred?.complete(CameraCaptureStart(finalFile.absolutePath, startedNs))
                        }

                        is VideoRecordEvent.Status -> {
                            _state.value = _state.value.copy(
                                recordedDurationNs = event.recordingStats.recordedDurationNanos
                            )
                        }

                        is VideoRecordEvent.Finalize -> {
                            val startedNs = _state.value.startedElapsedRealtimeNs
                            val durationNs = event.recordingStats.recordedDurationNanos
                            val error = if (event.hasError()) {
                                "שמירת צילום המצלמה נכשלה (${event.error})"
                            } else null

                            val result = if (error == null && startedNs != null && file.exists() && file.length() > 0L) {
                                val moved = file.renameTo(finalFile)
                                val outputFile = if (moved) finalFile else file
                                Result.success(CameraCaptureResult(outputFile, startedNs, durationNs))
                            } else {
                                Result.failure(IllegalStateException(error ?: "צילום המצלמה לא התחיל כראוי"))
                            }

                            val finalPath = result.getOrNull()?.file?.absolutePath
                            _state.value = _state.value.copy(
                                recording = false,
                                activeFilePath = null,
                                finalizedFilePath = finalPath,
                                recordedDurationNs = durationNs,
                                errorMessage = result.exceptionOrNull()?.message
                            )
                            if (startDeferred?.isCompleted == false && startedNs == null) {
                                startDeferred?.completeExceptionally(
                                    result.exceptionOrNull() ?: IllegalStateException("צילום המצלמה לא התחיל")
                                )
                            }
                            finalizeDeferred?.complete(result)
                            activeRecording = null
                            activeFile = null
                            expectedFinalFile = null
                        }
                    }
                }
        }
    }

    suspend fun awaitStarted(timeoutMs: Long = 8_000L): Result<CameraCaptureStart> {
        val alreadyStarted = _state.value.startedElapsedRealtimeNs
        val finalPath = expectedFinalFile?.absolutePath
        if (_state.value.recording && alreadyStarted != null && finalPath != null) {
            return Result.success(CameraCaptureStart(finalPath, alreadyStarted))
        }
        val deferred = startDeferred ?: return Result.failure(IllegalStateException("צילום המצלמה לא הופעל"))
        val started = withTimeoutOrNull(timeoutMs) { runCatching { deferred.await() } }
            ?: Result.failure(IllegalStateException("המצלמה לא התחילה לצלם בזמן"))
        return started
    }

    suspend fun stopAndAwaitFinalized(timeoutMs: Long = 12_000L): Result<CameraCaptureResult> {
        val recording = activeRecording
            ?: return finalizedResultFromState()
        val deferred = finalizeDeferred
            ?: return Result.failure(IllegalStateException("אין תהליך שמירה פעיל למצלמה"))
        recording.stop()
        return withTimeoutOrNull(timeoutMs) { deferred.await() }
            ?: Result.failure(IllegalStateException("שמירת סרטון המצלמה התעכבה מעבר למותר"))
    }

    fun abort() {
        runCatching { activeRecording?.close() }
        activeRecording = null
        activeFile?.delete()
        activeFile = null
        expectedFinalFile = null
        _state.value = _state.value.copy(recording = false, activeFilePath = null)
    }

    fun release() {
        abort()
        runCatching { provider?.unbindAll() }
        provider = null
        preview = null
        videoCapture = null
    }

    private fun finalizedResultFromState(): Result<CameraCaptureResult> {
        val path = _state.value.finalizedFilePath
            ?: return Result.failure(IllegalStateException("אין צילום מצלמה פעיל או שמור"))
        val start = _state.value.startedElapsedRealtimeNs
            ?: return Result.failure(IllegalStateException("חסר סמן התחלה של המצלמה"))
        val file = File(path)
        return if (file.exists() && file.length() > 0L) {
            Result.success(CameraCaptureResult(file, start, _state.value.recordedDurationNs))
        } else {
            Result.failure(IllegalStateException("קובץ המצלמה אינו זמין"))
        }
    }

    private fun selectorFor(facing: CameraFacing): CameraSelector = when (facing) {
        CameraFacing.Front -> CameraSelector.DEFAULT_FRONT_CAMERA
        CameraFacing.Back -> CameraSelector.DEFAULT_BACK_CAMERA
    }

    private fun videoDirectory(): File {
        val root = appContext.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: appContext.filesDir
        return File(root, "KolboStudio/Takes")
    }

    private companion object {
        const val MIN_FREE_SPACE_BYTES = 256L * 1024L * 1024L
    }
}
