package com.kolbomusic.singstudio.ui.playback

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.kolbomusic.singstudio.core.model.PlaybackSource
import com.kolbomusic.singstudio.core.model.PlaybackSourceType
import com.kolbomusic.singstudio.core.playback.YouTubeNavigationPolicy
import com.kolbomusic.singstudio.core.playback.YouTubeUrlParser
import com.kolbomusic.singstudio.ui.theme.GraphiteElevated
import com.kolbomusic.singstudio.ui.theme.WarmGold

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun YouTubeBrowserScreen(
    onBack: () -> Unit,
    onSelected: (PlaybackSource) -> Unit
) {
    var candidateId by remember { mutableStateOf<String?>(null) }
    var candidateTitle by remember { mutableStateOf("שיר מ־YouTube") }
    var browserWebView by remember { mutableStateOf<WebView?>(null) }

    DisposableEffect(Unit) {
        onDispose {
            runCatching { browserWebView?.stopLoading() }
            runCatching { browserWebView?.destroy() }
            browserWebView = null
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.statusBars)
            .windowInsetsPadding(WindowInsets.navigationBars)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = {
                    val browser = browserWebView
                    if (browser?.canGoBack() == true) browser.goBack() else onBack()
                },
                modifier = Modifier.heightIn(min = 56.dp)
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "חזרה")
            }
            Column(modifier = Modifier.weight(1f)) {
                Text("בחר שיר ב־YouTube", style = MaterialTheme.typography.titleLarge, modifier = Modifier.semantics { heading() })
                Text("אפשר לבחור קריוקי או שיר רגיל. פתח סרטון ואז לחץ בחירה.", style = MaterialTheme.typography.bodySmall)
            }
        }

        AndroidView(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            factory = { context ->
                WebView(context).apply {
                    browserWebView = this
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.mediaPlaybackRequiresUserGesture = true
                    settings.allowFileAccess = false
                    settings.allowContentAccess = false
                    settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                    settings.safeBrowsingEnabled = true
                    webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                            return !YouTubeNavigationPolicy.isAllowed(request?.url?.toString())
                        }

                        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                            YouTubeUrlParser.extractVideoId(url)?.let { candidateId = it }
                            candidateTitle = view?.title?.takeIf { !it.isNullOrBlank() } ?: candidateTitle
                        }

                        override fun onPageFinished(view: WebView?, url: String?) {
                            YouTubeUrlParser.extractVideoId(url)?.let { candidateId = it }
                            candidateTitle = view?.title?.takeIf { !it.isNullOrBlank() } ?: candidateTitle
                        }
                    }
                    loadUrl("https://m.youtube.com/")
                }
            }
        )

        candidateId?.let { id ->
            Card(
                modifier = Modifier.fillMaxWidth().padding(12.dp),
                colors = CardDefaults.cardColors(containerColor = GraphiteElevated)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("נמצא סרטון לבחירה", color = WarmGold, style = MaterialTheme.typography.titleMedium)
                    Text(candidateTitle, maxLines = 2)
                    Button(
                        onClick = {
                            onSelected(
                                PlaybackSource(
                                    id = "youtube-$id",
                                    type = PlaybackSourceType.YouTube,
                                    title = candidateTitle,
                                    youtubeVideoId = id
                                )
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 64.dp)
                            .semantics { contentDescription = "בחר את השיר הזה" }
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null)
                        Text("  בחר את השיר")
                    }
                }
            }
        }
    }
}
