package com.kolbomusic.singstudio.core.audio

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.os.Environment
import android.os.SystemClock
import androidx.core.content.ContextCompat
import com.kolbomusic.singstudio.core.device.DeviceCapabilityProbe
import com.kolbomusic.singstudio.core.model.AudioInputProfile
import com.kolbomusic.singstudio.core.model.CameraSyncMarker
import com.kolbomusic.singstudio.core.model.PlaybackSyncMarker
import com.kolbomusic.singstudio.core.model.VisualScene
import com.kolbomusic.singstudio.core.model.RecordingPhase
import com.kolbomusic.singstudio.core.model.RecordingState
import com.kolbomusic.singstudio.core.model.RecordingTelemetry
import com.kolbomusic.singstudio.core.playback.PlaybackSyncMath
import com.kolbomusic.singstudio.core.recording.TakeRecoveryManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.sqrt

class Pcm16AudioRecorder(private val appContext: Context) : AudioCaptureEngine {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val isCapturing = AtomicBoolean(false)
    private val _state = MutableStateFlow(RecordingState())
    override val state: StateFlow<RecordingState> = _state.asStateFlow()

    private var captureJob: Job? = null
    private var audioRecord: AudioRecord? = null
    private var activeSession: ActiveSession? = null
    @Volatile private var pendingVisualScene: VisualScene? = null

    init {
        scope.launch {
            val recovered = TakeRecoveryManager(takesDirectory()).recoverInterruptedTakes()
            if (recovered > 0) {
                _state.value = _state.value.copy(recoveredTakeCount = recovered)
            }
        }
    }

    override suspend fun start(): Result<Unit> = withContext(Dispatchers.IO) {
        if (isCapturing.get()) return@withContext Result.success(Unit)
        if (ContextCompat.checkSelfPermission(appContext, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            return@withContext Result.failure(SecurityException("נדרשת הרשאת מיקרופון"))
        }

        runCatching {
            _state.value = _state.value.copy(
                phase = RecordingPhase.Starting,
                telemetry = RecordingTelemetry(),
                errorMessage = null,
                savedFilePath = null,
                playbackStartOffsetMs = null,
                cameraStartOffsetMs = null,
                cameraFilePath = null
            )

            val capabilities = DeviceCapabilityProbe(appContext).probe()
            check(capabilities.hasMicrophone) { "לא נמצא מיקרופון במכשיר" }
            val directory = takesDirectory().also { it.mkdirs() }
            check(directory.usableSpace >= MIN_FREE_SPACE_BYTES) {
                "אין מספיק מקום פנוי לטייק חדש. פנה לפחות 128MB."
            }
            val (input, recorder) = prepareAudioRecord(capabilities)

            val session = createSession(input)
            activeSession = session
            audioRecord = recorder
            isCapturing.set(true)
            recorder.startRecording()

            _state.value = _state.value.copy(
                phase = RecordingPhase.Recording,
                activeTakeId = session.id
            )

            captureJob = scope.launch {
                captureLoop(recorder, session)
            }
        }.onFailure { throwable ->
            isCapturing.set(false)
            releaseRecorder()
            _state.value = _state.value.copy(
                phase = RecordingPhase.Error,
                errorMessage = throwable.message ?: "שגיאת הקלטה"
            )
        }
    }

    override suspend fun stop(): Result<File> = withContext(Dispatchers.IO) {
        val session = activeSession
            ?: return@withContext Result.failure(IllegalStateException("אין טייק פעיל"))

        runCatching {
            _state.value = _state.value.copy(phase = RecordingPhase.Stopping)
            isCapturing.set(false)
            runCatching { audioRecord?.stop() }
            captureJob?.cancelAndJoin()
            captureJob = null
            releaseRecorder()

            check(session.pcmFile.exists() && session.pcmFile.length() > 0L) {
                "לא התקבל אודיו מהמיקרופון"
            }

            WavFileTools.finalizePcm16Mono(
                pcmFile = session.pcmFile,
                destination = session.finalWav,
                sampleRate = session.profile.sampleRate
            )
            check(WavFileTools.validatePcm16Mono(session.finalWav)) {
                "בדיקת תקינות WAV נכשלה; קובץ ה־RAW נשמר לשחזור"
            }

            session.pcmFile.delete()
            writeFinalMetadata(session)
            session.partialMetadata.delete()
            activeSession = null

            _state.value = _state.value.copy(
                phase = RecordingPhase.Saved,
                telemetry = _state.value.telemetry.copy(linearLevel = 0f, clipping = false),
                activeTakeId = null,
                savedFilePath = session.finalWav.absolutePath,
                errorMessage = null
            )

            session.finalWav
        }.onFailure { throwable ->
            releaseRecorder()
            activeSession = null
            _state.value = _state.value.copy(
                phase = RecordingPhase.Error,
                activeTakeId = null,
                errorMessage = throwable.message ?: "שמירת הטייק נכשלה"
            )
        }
    }

    override fun configureVisualScene(scene: VisualScene) {
        pendingVisualScene = scene
        activeSession?.let { session ->
            session.visualScene = scene
            writePartialMetadata(session)
        }
    }

    override fun markPlaybackStarted(marker: PlaybackSyncMarker) {
        val session = activeSession ?: return
        session.playbackSyncMarker = marker
        val offsetMs = PlaybackSyncMath.offsetMs(
            session.startedElapsedNs,
            marker.startedElapsedRealtimeNs
        )
        writePartialMetadata(session)
        _state.value = _state.value.copy(playbackStartOffsetMs = offsetMs)
    }

    override fun markCameraStarted(marker: CameraSyncMarker) {
        val session = activeSession ?: return
        session.cameraSyncMarker = marker
        val offsetMs = PlaybackSyncMath.offsetMs(
            session.startedElapsedNs,
            marker.startedElapsedRealtimeNs
        )
        writePartialMetadata(session)
        _state.value = _state.value.copy(
            cameraStartOffsetMs = offsetMs,
            cameraFilePath = marker.filePath
        )
    }

    override fun resetSavedState() {
        if (_state.value.phase == RecordingPhase.Saved || _state.value.phase == RecordingPhase.Error) {
            _state.value = _state.value.copy(
                phase = RecordingPhase.Idle,
                telemetry = RecordingTelemetry(),
                savedFilePath = null,
                playbackStartOffsetMs = null,
                cameraStartOffsetMs = null,
                cameraFilePath = null,
                errorMessage = null
            )
        }
    }

    override fun restoreSavedTake(
        rawFilePath: String,
        playbackStartOffsetMs: Long?,
        cameraStartOffsetMs: Long?,
        cameraFilePath: String?
    ): Result<Unit> = runCatching {
        check(!isCapturing.get()) { "לא ניתן לשחזר פרויקט בזמן הקלטה" }
        val raw = File(rawFilePath).canonicalFile
        val root = takesDirectory().canonicalFile
        check(raw.path.startsWith(root.path + File.separator) && raw.isFile) { "קובץ RAW אינו שייך לאחסון הטייקים של האפליקציה" }
        if (cameraFilePath != null) {
            val camera = File(cameraFilePath)
            check(camera.isFile) { "קובץ המצלמה של הפרויקט חסר" }
        }
        _state.value = RecordingState(
            phase = RecordingPhase.Saved,
            savedFilePath = raw.absolutePath,
            playbackStartOffsetMs = playbackStartOffsetMs,
            cameraStartOffsetMs = cameraStartOffsetMs,
            cameraFilePath = cameraFilePath,
            recoveredTakeCount = _state.value.recoveredTakeCount
        )
    }


    private fun prepareAudioRecord(
        capabilities: com.kolbomusic.singstudio.core.model.DeviceCapabilities
    ): Pair<AudioInputProfile, AudioRecord> {
        var lastError: Throwable? = null
        for (profile in AudioInputSelector.candidates(capabilities)) {
            val candidate = runCatching { buildAudioRecord(profile) }
                .onFailure { lastError = it }
                .getOrNull() ?: continue

            if (candidate.state == AudioRecord.STATE_INITIALIZED) {
                return profile to candidate
            }
            candidate.release()
        }
        throw IllegalStateException(
            "לא נמצא מסלול מיקרופון תואם במכשיר",
            lastError
        )
    }

    private fun buildAudioRecord(profile: AudioInputProfile): AudioRecord {
        if (ContextCompat.checkSelfPermission(appContext, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            throw SecurityException("נדרשת הרשאת מיקרופון")
        }

        val format = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(profile.sampleRate)
            .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
            .build()

        return AudioRecord.Builder()
            .setAudioSource(profile.audioSource)
            .setAudioFormat(format)
            .setBufferSizeInBytes(profile.bufferSizeBytes)
            .build()
    }

    private suspend fun captureLoop(recorder: AudioRecord, session: ActiveSession) {
        val shortsPerRead = (session.profile.bufferSizeBytes / 2).coerceAtLeast(512)
        val shortBuffer = ShortArray(shortsPerRead)
        val byteBuffer = ByteArray(shortsPerRead * 2)
        var lastUiUpdate = 0L
        var clippedFrames = 0L
        var totalFrames = 0L

        try {
            BufferedOutputStream(FileOutputStream(session.pcmFile, true), 64 * 1024).use { output ->
                while (isCapturing.get()) {
                    val read = recorder.read(shortBuffer, 0, shortBuffer.size, AudioRecord.READ_BLOCKING)
                    if (read <= 0) {
                        if (!isCapturing.get()) break
                        if (read == AudioRecord.ERROR_DEAD_OBJECT || read == AudioRecord.ERROR_INVALID_OPERATION) {
                            throw IllegalStateException("זרם המיקרופון נותק")
                        }
                        continue
                    }

                    var peak = 0
                    var sumSquares = 0.0
                    var byteIndex = 0
                    var localClips = 0
                    for (index in 0 until read) {
                        val sample = shortBuffer[index].toInt()
                        val magnitude = abs(sample).coerceAtMost(32_767)
                        if (magnitude > peak) peak = magnitude
                        if (magnitude >= 32_500) localClips++
                        sumSquares += sample.toDouble() * sample.toDouble()

                        byteBuffer[byteIndex++] = (sample and 0xFF).toByte()
                        byteBuffer[byteIndex++] = ((sample shr 8) and 0xFF).toByte()
                    }
                    output.write(byteBuffer, 0, read * 2)

                    totalFrames += read
                    clippedFrames += localClips

                    val now = SystemClock.elapsedRealtime()
                    if (now - lastUiUpdate >= 50L) {
                        val rms = sqrt(sumSquares / read.toDouble()) / 32_767.0
                        val peakNorm = (peak / 32_767.0).coerceIn(0.0, 1.0)
                        val peakDb = if (peakNorm > 0.000001) {
                            (20.0 * log10(peakNorm)).toFloat()
                        } else {
                            -96f
                        }
                        _state.value = _state.value.copy(
                            phase = RecordingPhase.Recording,
                            telemetry = RecordingTelemetry(
                                linearLevel = rms.coerceIn(0.0, 1.0).toFloat(),
                                peakDbfs = peakDb.coerceAtLeast(-96f),
                                clipping = localClips > 0,
                                elapsedMs = now - session.startedElapsedMs
                            )
                        )
                        lastUiUpdate = now
                    }
                }
                output.flush()
            }
        } catch (throwable: Throwable) {
            if (isCapturing.get()) {
                isCapturing.set(false)
                _state.value = _state.value.copy(
                    phase = RecordingPhase.Error,
                    errorMessage = throwable.message ?: "זרם ההקלטה הופסק"
                )
            }
        } finally {
            session.totalFrames = totalFrames
            session.clippedFrames = clippedFrames
        }
    }

    private fun createSession(profile: AudioInputProfile): ActiveSession {
        val directory = takesDirectory().also { it.mkdirs() }
        val id = "take-${System.currentTimeMillis()}-${UUID.randomUUID().toString().take(8)}"
        val session = ActiveSession(
            id = id,
            profile = profile,
            startedEpochMs = System.currentTimeMillis(),
            startedElapsedMs = SystemClock.elapsedRealtime(),
            startedElapsedNs = SystemClock.elapsedRealtimeNanos(),
            pcmFile = File(directory, "$id.pcm.partial"),
            partialMetadata = File(directory, "$id.session.partial.json"),
            finalMetadata = File(directory, "$id.json"),
            finalWav = File(directory, "$id.wav"),
            visualScene = pendingVisualScene
        )

        writePartialMetadata(session)
        return session
    }

    private fun writePartialMetadata(session: ActiveSession) {
        val marker = session.playbackSyncMarker
        val json = JSONObject()
            .put("id", session.id)
            .put("sampleRate", session.profile.sampleRate)
            .put("channels", 1)
            .put("bitsPerSample", 16)
            .put("audioSource", session.profile.sourceLabel)
            .put("startedAtEpochMs", session.startedEpochMs)

        session.visualScene?.let { scene ->
            json.put("visualMode", scene.mode.name)
                .put("outputAspectRatio", scene.aspectRatio.name)
                .put("cameraFacing", scene.cameraFacing.name)
                .put("backgroundType", scene.background.type.name)
            scene.background.id?.let { json.put("backgroundId", it) }
            scene.background.title?.let { json.put("backgroundTitle", it) }
            scene.background.uriString?.let { json.put("backgroundUri", it) }
        }

        session.cameraSyncMarker?.let { camera ->
            json.put("cameraFile", camera.filePath)
                .put("cameraFacing", camera.cameraFacing.name)
                .put("cameraRequestedAspectRatio", camera.requestedAspectRatio.name)
                .put(
                    "cameraStartOffsetMs",
                    PlaybackSyncMath.offsetMs(session.startedElapsedNs, camera.startedElapsedRealtimeNs)
                )
        }

        if (marker != null) {
            json.put("playbackSourceId", marker.sourceId)
                .put("playbackSourceType", marker.sourceType)
                .put("playbackSourceTitle", marker.sourceTitle)
                .put("playbackPositionMs", marker.playbackPositionMs)
                .put(
                    "playbackStartOffsetMs",
                    PlaybackSyncMath.offsetMs(session.startedElapsedNs, marker.startedElapsedRealtimeNs)
                )
        }

        val temporary = File(session.partialMetadata.parentFile, session.partialMetadata.name + ".tmp")
        temporary.writeText(json.toString(2))
        if (!temporary.renameTo(session.partialMetadata)) {
            session.partialMetadata.writeText(json.toString(2))
            temporary.delete()
        }
    }

    private fun writeFinalMetadata(session: ActiveSession) {
        val json = JSONObject()
            .put("id", session.id)
            .put("sampleRate", session.profile.sampleRate)
            .put("channels", 1)
            .put("bitsPerSample", 16)
            .put("audioSource", session.profile.sourceLabel)
            .put("rawPreferred", session.profile.rawPreferred)
            .put("startedAtEpochMs", session.startedEpochMs)
            .put("durationMs", session.totalFrames * 1000L / session.profile.sampleRate)
            .put("totalFrames", session.totalFrames)
            .put("clippedFrames", session.clippedFrames)
            .put("file", session.finalWav.name)
            .put("fileSizeBytes", session.finalWav.length())
            .put("sha256", WavFileTools.sha256(session.finalWav))

        session.visualScene?.let { scene ->
            json.put("visualMode", scene.mode.name)
                .put("outputAspectRatio", scene.aspectRatio.name)
                .put("cameraFacing", scene.cameraFacing.name)
                .put("backgroundType", scene.background.type.name)
            scene.background.id?.let { json.put("backgroundId", it) }
            scene.background.title?.let { json.put("backgroundTitle", it) }
            scene.background.uriString?.let { json.put("backgroundUri", it) }
        }

        session.cameraSyncMarker?.let { camera ->
            json.put("cameraFile", camera.filePath)
                .put("cameraFacing", camera.cameraFacing.name)
                .put("cameraRequestedAspectRatio", camera.requestedAspectRatio.name)
                .put(
                    "cameraStartOffsetMs",
                    PlaybackSyncMath.offsetMs(session.startedElapsedNs, camera.startedElapsedRealtimeNs)
                )
            val cameraFile = File(camera.filePath)
            if (cameraFile.exists() && cameraFile.length() > 0L) {
                json.put("cameraFileSizeBytes", cameraFile.length())
                    .put("cameraSha256", WavFileTools.sha256(cameraFile))
            }
        }

        session.playbackSyncMarker?.let { marker ->
            json.put("playbackSourceId", marker.sourceId)
                .put("playbackSourceType", marker.sourceType)
                .put("playbackSourceTitle", marker.sourceTitle)
                .put("playbackPositionMs", marker.playbackPositionMs)
                .put(
                    "playbackStartOffsetMs",
                    PlaybackSyncMath.offsetMs(session.startedElapsedNs, marker.startedElapsedRealtimeNs)
                )
        }
        session.finalMetadata.writeText(json.toString(2))
    }

    private fun takesDirectory(): File {
        val root = appContext.getExternalFilesDir(Environment.DIRECTORY_MUSIC) ?: appContext.filesDir
        return File(root, "KolboStudio/Takes")
    }

    private fun releaseRecorder() {
        runCatching { audioRecord?.release() }
        audioRecord = null
    }

    private data class ActiveSession(
        val id: String,
        val profile: AudioInputProfile,
        val startedEpochMs: Long,
        val startedElapsedMs: Long,
        val startedElapsedNs: Long,
        val pcmFile: File,
        val partialMetadata: File,
        val finalMetadata: File,
        val finalWav: File,
        var totalFrames: Long = 0,
        var clippedFrames: Long = 0,
        @Volatile var playbackSyncMarker: PlaybackSyncMarker? = null,
        @Volatile var cameraSyncMarker: CameraSyncMarker? = null,
        @Volatile var visualScene: VisualScene? = null
    )

    private companion object {
        const val MIN_FREE_SPACE_BYTES = 128L * 1024L * 1024L
    }
}
