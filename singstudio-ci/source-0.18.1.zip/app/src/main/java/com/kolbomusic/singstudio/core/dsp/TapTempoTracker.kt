package com.kolbomusic.singstudio.core.dsp

import kotlin.math.roundToLong

class TapTempoTracker {
    private val taps = ArrayDeque<Long>()

    fun tap(nowMs: Long): Double? {
        if (taps.isNotEmpty() && nowMs - taps.last() > 2_500L) taps.clear()
        taps.add(nowMs)
        while (taps.size > 6) taps.removeFirst()
        if (taps.size < 3) return null

        val intervals = taps.zipWithNext { a, b -> b - a }
            .filter { it in 250L..1_500L }
        if (intervals.size < 2) return null
        val sorted = intervals.sorted()
        val median = if (sorted.size % 2 == 1) {
            sorted[sorted.size / 2].toDouble()
        } else {
            (sorted[sorted.size / 2 - 1] + sorted[sorted.size / 2]) / 2.0
        }
        if (median <= 0.0) return null
        var bpm = 60_000.0 / median
        while (bpm < 60.0) bpm *= 2.0
        while (bpm > 190.0) bpm /= 2.0
        return bpm.coerceIn(60.0, 190.0)
    }

    fun reset() = taps.clear()
}
