package com.kolbomusic.singstudio.core.editor

import com.kolbomusic.singstudio.core.dsp.BeatDivision
import com.kolbomusic.singstudio.core.dsp.PreviewSource
import com.kolbomusic.singstudio.core.dsp.VocalFxSettings
import com.kolbomusic.singstudio.core.export.ExportResolution
import com.kolbomusic.singstudio.core.export.ExportSettings
import com.kolbomusic.singstudio.core.export.ExportVideoCodec
import com.kolbomusic.singstudio.core.mix.SessionMixSettings
import com.kolbomusic.singstudio.core.model.CameraFacing
import com.kolbomusic.singstudio.core.model.OutputAspectRatio
import com.kolbomusic.singstudio.core.model.PlaybackSource
import com.kolbomusic.singstudio.core.model.PlaybackSourceType
import com.kolbomusic.singstudio.core.model.ProductionMode
import com.kolbomusic.singstudio.core.model.VisualBackground
import com.kolbomusic.singstudio.core.model.VisualBackgroundType
import com.kolbomusic.singstudio.core.model.VisualScene
import org.json.JSONObject
import java.io.File

/**
 * Fully reconstructed, non-destructive project snapshot.
 * Loading never rewrites the source project file. Saving again upgrades it to CURRENT_SCHEMA.
 */
data class RestoredVideoProject(
    val sourceSchema: Int,
    val currentSchema: Int,
    val projectFilePath: String,
    val takeId: String,
    val scene: VisualScene,
    val state: VideoProjectState,
    val playbackSource: PlaybackSource?,
    val productionBackingSource: PlaybackSource?,
    val rawVocalPath: String,
    val processedVocalPath: String?,
    val sessionMixPath: String?,
    val sessionMixSettings: SessionMixSettings,
    val vocalFxSettings: VocalFxSettings,
    val cameraFilePath: String?,
    val playbackStartOffsetMs: Long?,
    val cameraStartOffsetMs: Long?,
    val warnings: List<String>
) {
    val migrated: Boolean get() = sourceSchema != currentSchema
}

object VideoProjectRestoreStore {
    fun load(file: File): RestoredVideoProject {
        require(file.isFile) { "קובץ הפרויקט לא נמצא" }
        val root = JSONObject(file.readText(Charsets.UTF_8))
        val schema = root.optInt("schema", 1)
        val decision = ProjectMigrationPolicy.decide(schema)
        require(decision.accepted) { decision.warnings.firstOrNull() ?: "גרסת פרויקט אינה נתמכת" }

        val takeId = root.optString("takeId").trim()
        require(takeId.isNotEmpty()) { "מזהה הטייק חסר בפרויקט" }

        val rawPath = root.optNullableString("rawVocalPath")
            ?: inferLegacyRawPath(file, takeId)
            ?: throw IllegalStateException("קובץ RAW חסר בפרויקט")
        require(File(rawPath).isFile) { "קובץ ה־RAW של הפרויקט לא נמצא" }

        val aspect = enumOrDefault(root.optString("aspectRatio"), OutputAspectRatio.Portrait9x16)
        val mode = enumOrDefault(root.optString("visualMode"), ProductionMode.Camera)
        val facing = enumOrDefault(root.optString("cameraFacing"), CameraFacing.Front)
        val backgroundType = enumOrDefault(root.optString("backgroundType"), VisualBackgroundType.None)
        val scene = VisualScene(
            mode = mode,
            aspectRatio = aspect,
            cameraFacing = facing,
            background = VisualBackground(
                type = backgroundType,
                id = root.optNullableString("backgroundId"),
                title = root.optNullableString("backgroundTitle"),
                uriString = root.optNullableString("backgroundUri")
            )
        )

        val titleJson = root.optJSONObject("title") ?: JSONObject()
        val title = TitleOverlay(
            text = titleJson.optString("text", ""),
            fontPreset = enumOrDefault(titleJson.optString("fontPreset"), TextFontPreset.Bold),
            fontSizeSp = titleJson.optDouble("fontSizeSp", 40.0).toFloat(),
            colorArgb = titleJson.optLong("colorArgb", 0xFFFFFFFFL),
            outline = titleJson.optBoolean("outline", true),
            shadow = titleJson.optBoolean("shadow", true),
            xNormalized = titleJson.optDouble("xNormalized", 0.5).toFloat(),
            yNormalized = titleJson.optDouble("yNormalized", 0.16).toFloat(),
            animation = enumOrDefault(titleJson.optString("animation"), TextAnimationPreset.Fade),
            startMs = titleJson.optLong("startMs", 0L),
            endMs = titleJson.optLong("endMs", 6_000L)
        ).sanitized()

        val exportJson = root.optJSONObject("export") ?: JSONObject()
        val export = ExportSettings(
            resolution = enumOrDefault(exportJson.optString("resolution"), ExportResolution.FullHD1080),
            codec = enumOrDefault(exportJson.optString("codec"), ExportVideoCodec.H264),
            frameRate = exportJson.optInt("frameRate", 30),
            allowCodecFallback = exportJson.optBoolean("allowCodecFallback", true),
            trimStartMs = exportJson.optLong("trimStartMs", 0L),
            trimEndMs = exportJson.optLong("trimEndMs", 0L)
        )

        val state = VideoProjectState(
            aspectRatio = aspect,
            zoom = root.optDouble("zoom", 1.0).toFloat(),
            visualOffsetX = root.optDouble("visualOffsetX", 0.0).toFloat(),
            visualOffsetY = root.optDouble("visualOffsetY", 0.0).toFloat(),
            title = title,
            exportSettings = export,
            savedProjectPath = file.absolutePath
        ).sanitized()

        val mixJson = root.optJSONObject("mix") ?: JSONObject()
        val mix = SessionMixSettings(
            vocalGainDb = mixJson.optDouble("vocalGainDb", 0.0).toFloat(),
            playbackGainDb = mixJson.optDouble("playbackGainDb", -2.0).toFloat(),
            masterHeadroomDb = mixJson.optDouble("masterHeadroomDb", -3.0).toFloat(),
            previewSource = enumOrDefault(mixJson.optString("previewSource"), PreviewSource.Processed)
        ).sanitized()

        val fxJson = root.optJSONObject("vocalFx") ?: JSONObject()
        val fx = VocalFxSettings(
            enabled = fxJson.optBoolean("enabled", true),
            reverbMix = fxJson.optDouble("reverbMix", 0.20).toFloat(),
            reverbRoom = fxJson.optDouble("reverbRoom", 0.68).toFloat(),
            delayMix = fxJson.optDouble("delayMix", 0.10).toFloat(),
            delayFeedback = fxJson.optDouble("delayFeedback", 0.28).toFloat(),
            delayMs = fxJson.optDouble("delayMs", 280.0).toFloat(),
            delayDivision = enumOrDefault(fxJson.optString("delayDivision"), BeatDivision.DottedEighth),
            outputGainDb = fxJson.optDouble("outputGainDb", 0.0).toFloat()
        ).sanitized()

        val playback = root.optJSONObject("playbackSource")?.toPlaybackSource()
        val productionBacking = root.optJSONObject("productionBackingSource")?.toPlaybackSource()
            ?: playback?.takeIf { it.type != PlaybackSourceType.YouTube }
        val warnings = decision.warnings.toMutableList()
        val processed = root.optNullableString("processedVocalPath").takeIfExistingOrWarn("קובץ הקול המעובד", warnings)
        val mixPath = root.optNullableString("sessionMixPath").takeIfExistingOrWarn("קובץ Session Mix", warnings)
        val camera = root.optNullableString("cameraFilePath").takeIfExistingOrWarn("קובץ המצלמה", warnings)
        if (playback == null) warnings += "מקור הפלייבק חסר; אפשר לפתוח את הפרויקט אך יידרש לבחור מקור מחדש"

        return RestoredVideoProject(
            sourceSchema = schema,
            currentSchema = ProjectMigrationPolicy.CURRENT_SCHEMA,
            projectFilePath = file.absolutePath,
            takeId = takeId,
            scene = scene,
            state = state,
            playbackSource = playback,
            productionBackingSource = productionBacking,
            rawVocalPath = rawPath,
            processedVocalPath = processed,
            sessionMixPath = mixPath,
            sessionMixSettings = mix,
            vocalFxSettings = fx,
            cameraFilePath = camera,
            playbackStartOffsetMs = root.optNullableLong("playbackStartOffsetMs"),
            cameraStartOffsetMs = root.optNullableLong("cameraStartOffsetMs"),
            warnings = warnings.distinct()
        )
    }

    private fun JSONObject.toPlaybackSource(): PlaybackSource? {
        val id = optString("id").trim()
        if (id.isEmpty()) return null
        return PlaybackSource(
            id = id,
            type = enumOrDefault(optString("type"), PlaybackSourceType.LocalAudio),
            title = optString("title", "פלייבק"),
            uriString = optNullableString("uriString"),
            mimeType = optNullableString("mimeType"),
            youtubeVideoId = optNullableString("youtubeVideoId")
        )
    }

    private fun inferLegacyRawPath(projectFile: File, takeId: String): String? {
        val takeDir = projectFile.parentFile?.parentFile ?: return null
        val candidate = File(takeDir, "$takeId.wav")
        return candidate.takeIf { it.isFile }?.absolutePath
    }

    private fun String?.takeIfExistingOrWarn(label: String, warnings: MutableList<String>): String? {
        val path = this?.takeIf { it.isNotBlank() } ?: return null
        if (File(path).isFile) return path
        warnings += "$label לא נמצא; השכבה תיבנה מחדש אם אפשר"
        return null
    }

    private inline fun <reified T : Enum<T>> enumOrDefault(value: String?, fallback: T): T =
        enumValues<T>().firstOrNull { it.name.equals(value, ignoreCase = true) } ?: fallback

    private fun JSONObject.optNullableString(name: String): String? {
        if (!has(name) || isNull(name)) return null
        return optString(name).takeIf { it.isNotBlank() && !it.equals("null", ignoreCase = true) }
    }

    private fun JSONObject.optNullableLong(name: String): Long? {
        if (!has(name) || isNull(name)) return null
        return runCatching { getLong(name) }.getOrNull()
    }
}
