package com.kolbomusic.singstudio.core.dsp

import com.kolbomusic.singstudio.core.audio.WavFileTools
import org.json.JSONObject
import java.io.File
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.sign
import kotlin.math.sqrt

/**
 * Constant-memory vocal processor for full-song takes.
 *
 * The previous DSP path intentionally uses full in-memory buffers for spectral work.
 * That is useful for short takes, but a 3-5 minute 48 kHz recording can exhaust a
 * mobile heap once several processing buffers coexist. This engine performs two
 * streaming passes instead: one analysis pass and one processing pass.
 */
class StreamingVocalDspEngine {
    fun render(
        inputFile: File,
        requestedPreset: VocalPresetId,
        onProgress: (DspStage, Float) -> Unit = { _, _ -> }
    ): DspRenderResult {
        require(WavFileTools.validatePcm16Mono(inputFile)) { "קובץ ההקלטה אינו WAV תקין" }
        val sourceShaBefore = WavFileTools.sha256(inputFile)

        onProgress(DspStage.Loading, 0.03f)
        val analysis = analyse(inputFile) { progress ->
            onProgress(DspStage.Analysing, 0.04f + progress * 0.18f)
        }
        val preset = VocalPresets.resolve(requestedPreset, analysis)
        val resolvedId = if (requestedPreset == VocalPresetId.Auto) analysis.recommendedPreset else requestedPreset

        val processedDir = File(inputFile.parentFile, "processed").also { it.mkdirs() }
        val output = File(
            processedDir,
            inputFile.nameWithoutExtension + "-${resolvedId.name.lowercase()}-vocal.wav"
        )

        Pcm16WavRandomAccessReader(inputFile).use { reader ->
            val processor = StreamProcessor(reader.sampleRate, preset, analysis)
            val blockFrames = 4096
            val samples = FloatArray(blockFrames)
            var frame = 0L
            Pcm16WavAtomicStreamWriter(output, reader.sampleRate).use { writer ->
                while (frame < reader.frameCount) {
                    val requested = minOf(blockFrames.toLong(), reader.frameCount - frame).toInt()
                    val read = reader.readFrames(frame, samples, 0, requested)
                    check(read > 0) { "קריאת ההקלטה נקטעה בזמן עיבוד" }
                    processor.process(samples, read)
                    writer.write(samples, 0, read)
                    frame += read
                    val fraction = frame.toFloat() / reader.frameCount.toFloat()
                    val stage = when {
                        fraction < 0.28f -> DspStage.NoiseReduction
                        fraction < 0.58f -> DspStage.Tone
                        fraction < 0.90f -> DspStage.Dynamics
                        else -> DspStage.Finalising
                    }
                    onProgress(stage, 0.22f + fraction * 0.70f)
                }
                writer.commit()
            }
        }

        onProgress(DspStage.Finalising, 0.94f)
        check(WavFileTools.validatePcm16Mono(output)) { "קובץ העיבוד הסופי נכשל באימות WAV" }
        val outputSha = WavFileTools.sha256(output)
        check(sourceShaBefore == WavFileTools.sha256(inputFile)) { "RAW integrity check failed" }
        writeMetadata(inputFile, output, requestedPreset, resolvedId, preset, analysis, sourceShaBefore, outputSha)
        onProgress(DspStage.Completed, 1f)
        return DspRenderResult(output.absolutePath, outputSha, analysis, resolvedId)
    }

    private fun analyse(input: File, onProgress: (Float) -> Unit): VocalAnalysis {
        Pcm16WavRandomAccessReader(input).use { reader ->
            val block = FloatArray(4096)
            val noiseWindowFrames = (reader.sampleRate / 20).coerceAtLeast(64) // 50 ms
            val noiseLimitFrames = reader.sampleRate.toLong() * 2L
            val noiseWindows = ArrayList<Double>(48)
            var noiseEnergy = 0.0
            var noiseCount = 0
            var frame = 0L
            var sumSquares = 0.0
            var peak = 0.0
            var clipping = 0L
            var samplesSeen = 0L

            while (frame < reader.frameCount) {
                val requested = minOf(block.size.toLong(), reader.frameCount - frame).toInt()
                val read = reader.readFrames(frame, block, 0, requested)
                check(read > 0) { "קריאת ההקלטה נקטעה בזמן ניתוח" }
                for (i in 0 until read) {
                    val value = block[i].toDouble()
                    val magnitude = abs(value)
                    peak = maxOf(peak, magnitude)
                    sumSquares += value * value
                    if (magnitude >= 0.985) clipping++

                    if (frame + i < noiseLimitFrames) {
                        noiseEnergy += value * value
                        noiseCount++
                        if (noiseCount >= noiseWindowFrames) {
                            noiseWindows += sqrt(noiseEnergy / noiseCount)
                            noiseEnergy = 0.0
                            noiseCount = 0
                        }
                    }
                }
                frame += read
                samplesSeen += read
                if ((frame / block.size) % 32L == 0L || frame == reader.frameCount) {
                    onProgress(frame.toFloat() / reader.frameCount.toFloat())
                }
            }
            if (noiseCount > 0) noiseWindows += sqrt(noiseEnergy / noiseCount)

            val rms = if (samplesSeen > 0L) sqrt(sumSquares / samplesSeen) else 0.0
            val rmsDb = linearToDb(rms)
            val peakDb = linearToDb(peak)
            val sortedNoise = noiseWindows.sorted()
            val noiseLinear = if (sortedNoise.isEmpty()) 1e-6 else {
                sortedNoise[(sortedNoise.size * 0.25).toInt().coerceIn(0, sortedNoise.lastIndex)]
            }
            val noiseDb = linearToDb(noiseLinear)
            val dynamic = (peakDb - rmsDb).coerceIn(0.0, 40.0)
            val recommended = when {
                samplesSeen > 0L && clipping > samplesSeen / 1000L -> VocalPresetId.Natural
                noiseDb > -43.0 -> VocalPresetId.Studio
                rmsDb < -30.0 -> VocalPresetId.Studio
                dynamic > 17.0 -> VocalPresetId.Ballad
                else -> VocalPresetId.Mizrahi
            }
            return VocalAnalysis(
                durationMs = reader.frameCount * 1000L / reader.sampleRate,
                sampleRate = reader.sampleRate,
                peakDbfs = peakDb,
                rmsDbfs = rmsDb,
                estimatedNoiseFloorDbfs = noiseDb,
                clippingSamples = clipping,
                dynamicRangeEstimateDb = dynamic,
                recommendedPreset = recommended
            )
        }
    }

    private class StreamProcessor(
        sampleRate: Int,
        private val preset: VocalPreset,
        analysis: VocalAnalysis
    ) {
        private val hp = Biquad.highPass(sampleRate, preset.highPassHz)
        private val warmth = Biquad.lowShelf(sampleRate, 190.0, preset.warmthDb)
        private val presence = Biquad.peaking(sampleRate, 3_200.0, 0.85, preset.presenceDb)
        private val deEsserDetector = Biquad.highPass(sampleRate, minOf(5_600.0, sampleRate * 0.2), 0.707)
        private val gateThresholdDb = maxOf(
            preset.gateThresholdDb,
            analysis.estimatedNoiseFloorDbfs + preset.noiseFloorMarginDb
        ).coerceIn(-58.0, -43.0)
        private val gateAttack = coefficient(5.0, sampleRate)
        private val gateRelease = coefficient(220.0, sampleRate)
        private val deEsserAttack = coefficient(2.0, sampleRate)
        private val deEsserRelease = coefficient(75.0, sampleRate)
        private val compressorAttack = coefficient(preset.compressorAttackMs, sampleRate)
        private val compressorRelease = coefficient(preset.compressorReleaseMs, sampleRate)
        private val outputGain = dbToLinear(preset.outputGainDb.coerceIn(-2.0, 1.0))
        private val limiterCeiling = dbToLinear(preset.limiterCeilingDb)
        private var gateEnvelope = 0.0
        private var gateGain = 1.0
        private var deEsserEnvelope = 0.0
        private var compressorEnvelope = 0.0

        private fun linearToDb(value: Double): Double =
            if (value <= 1e-12) -120.0 else 20.0 * log10(value)

        private fun dbToLinear(db: Double): Double = 10.0.pow(db / 20.0)

        private fun coefficient(ms: Double, sampleRate: Int): Double =
            exp(-1.0 / (0.001 * ms.coerceAtLeast(0.1) * sampleRate))

        fun process(samples: FloatArray, count: Int) {
            for (i in 0 until count) {
                var x = samples[i].toDouble()

                // Adaptive downward expansion. It is intentionally gentler than a hard
                // gate so phrase endings and breaths remain natural.
                val level = abs(x)
                val envCoeff = if (level > gateEnvelope) gateAttack else gateRelease
                gateEnvelope = level + envCoeff * (gateEnvelope - level)
                val envDb = linearToDb(gateEnvelope)
                val underDb = (gateThresholdDb - envDb).coerceAtLeast(0.0)
                val reductionDb = (-underDb * preset.noiseReductionStrength * 0.34)
                    .coerceAtLeast(maxOf(preset.gateFloorDb, -10.0))
                val targetGate = dbToLinear(reductionDb)
                val gainCoeff = if (targetGate > gateGain) gateAttack else gateRelease
                gateGain = targetGate + gainCoeff * (gateGain - targetGate)
                x *= gateGain

                x = hp.process(x)
                x = warmth.process(x)
                x = presence.process(x)

                // De-ess only the high-frequency branch. The previous implementation
                // multiplied the entire vocal by the de-esser gain and could make the
                // microphone sound dull/thin whenever an S/T transient was detected.
                val hfSample = deEsserDetector.process(x)
                val hf = abs(hfSample)
                val deCoeff = if (hf > deEsserEnvelope) deEsserAttack else deEsserRelease
                deEsserEnvelope = hf + deCoeff * (deEsserEnvelope - hf)
                val deOver = (linearToDb(deEsserEnvelope) - preset.deEsserThresholdDb).coerceAtLeast(0.0)
                val deReductionDb = (-deOver * 0.38).coerceAtLeast(-minOf(preset.deEsserMaxReductionDb, 4.0))
                val hfGain = dbToLinear(deReductionDb)
                x = (x - hfSample) + (hfSample * hfGain)

                val compLevel = abs(x).coerceAtLeast(1e-9)
                val compCoeff = if (compLevel > compressorEnvelope) compressorAttack else compressorRelease
                compressorEnvelope = compLevel + compCoeff * (compressorEnvelope - compLevel)
                val compDb = linearToDb(compressorEnvelope)
                if (compDb > preset.compressorThresholdDb) {
                    val compressedDb = preset.compressorThresholdDb +
                        (compDb - preset.compressorThresholdDb) / preset.compressorRatio
                    x *= dbToLinear(compressedDb - compDb)
                }

                x *= outputGain
                val magnitude = abs(x)
                if (magnitude > limiterCeiling) {
                    x = sign(x) * limiterCeiling
                }
                samples[i] = x.coerceIn(-0.9995, 0.9995).toFloat()
            }
        }
    }

    private fun writeMetadata(
        input: File,
        output: File,
        requestedPreset: VocalPresetId,
        resolvedPreset: VocalPresetId,
        preset: VocalPreset,
        analysis: VocalAnalysis,
        sourceSha: String,
        outputSha: String
    ) {
        val json = JSONObject()
            .put("schema", 2)
            .put("engine", "KolboStreamingVocalDSP")
            .put("engineVersion", "0.17.0")
            .put("constantMemory", true)
            .put("sourceFile", input.name)
            .put("sourceSha256", sourceSha)
            .put("outputFile", output.name)
            .put("outputSha256", outputSha)
            .put("requestedPreset", requestedPreset.name)
            .put("resolvedPreset", resolvedPreset.name)
            .put("sampleRate", analysis.sampleRate)
            .put("durationMs", analysis.durationMs)
            .put("inputPeakDbfs", analysis.peakDbfs)
            .put("inputRmsDbfs", analysis.rmsDbfs)
            .put("estimatedNoiseFloorDbfs", analysis.estimatedNoiseFloorDbfs)
            .put("clippingSamples", analysis.clippingSamples)
            .put("dynamicRangeEstimateDb", analysis.dynamicRangeEstimateDb)
            .put("noiseReductionStrength", preset.noiseReductionStrength)
            .put("highPassHz", preset.highPassHz)
            .put("compressorRatio", preset.compressorRatio)
            .put("limiterCeilingDb", preset.limiterCeilingDb)
        File(output.parentFile, output.nameWithoutExtension + ".dsp.json")
            .writeText(json.toString(2), Charsets.UTF_8)
    }

    private fun linearToDb(value: Double): Double =
        if (value <= 1e-12) -120.0 else 20.0 * log10(value)

    private fun dbToLinear(db: Double): Double = 10.0.pow(db / 20.0)

    private fun coefficient(ms: Double, sampleRate: Int): Double =
        exp(-1.0 / (0.001 * ms.coerceAtLeast(0.1) * sampleRate))
}
