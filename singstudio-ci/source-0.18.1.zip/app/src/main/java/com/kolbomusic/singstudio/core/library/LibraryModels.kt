package com.kolbomusic.singstudio.core.library

enum class LibraryItemStatus(val labelHe: String) {
    Draft("טיוטה"),
    Ready("מוכן")
}

enum class LibraryFilter(val labelHe: String) {
    All("הכול"),
    Drafts("טיוטות"),
    Ready("מוכנים"),
    Favorites("מועדפים")
}

data class LibraryItem(
    val id: String,
    val takeId: String,
    val title: String,
    val createdAtEpochMs: Long,
    val updatedAtEpochMs: Long,
    val status: LibraryItemStatus,
    val favorite: Boolean = false,
    val rawVocalPath: String? = null,
    val projectPath: String? = null,
    val exportPath: String? = null,
    val galleryUri: String? = null,
    val thumbnailPath: String? = null,
    val durationMs: Long = 0L,
    val fileSizeBytes: Long = 0L,
    val sha256: String? = null,
    val aspectRatio: String? = null,
    val sourceTitle: String? = null
) {
    fun matches(filter: LibraryFilter): Boolean = when (filter) {
        LibraryFilter.All -> true
        LibraryFilter.Drafts -> status == LibraryItemStatus.Draft
        LibraryFilter.Ready -> status == LibraryItemStatus.Ready
        LibraryFilter.Favorites -> favorite
    }
}

data class LibraryState(
    val loading: Boolean = true,
    val items: List<LibraryItem> = emptyList(),
    val filter: LibraryFilter = LibraryFilter.All,
    val searchQuery: String = "",
    val message: String? = null,
    val errorMessage: String? = null
) {
    val visibleItems: List<LibraryItem>
        get() {
            val q = searchQuery.trim()
            return items.asSequence()
                .filter { it.matches(filter) }
                .filter {
                    q.isEmpty() || it.title.contains(q, ignoreCase = true) ||
                        (it.sourceTitle?.contains(q, ignoreCase = true) == true)
                }
                .sortedByDescending { it.updatedAtEpochMs }
                .toList()
        }
}
