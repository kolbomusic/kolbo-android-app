#include <jni.h>
#include <oboe/Oboe.h>
#include <memory>
#include <sstream>

namespace {
std::string resultText(oboe::Result result) {
    return oboe::convertToText(result);
}
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_kolbomusic_singstudio_core_nativeaudio_OboeAudioProbe_nativeProbe(
        JNIEnv* env,
        jobject /* thiz */) {
    oboe::AudioStreamBuilder builder;
    builder.setDirection(oboe::Direction::Output)
            ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
            ->setSharingMode(oboe::SharingMode::Shared)
            ->setFormat(oboe::AudioFormat::Float)
            ->setChannelCount(1);

    std::shared_ptr<oboe::AudioStream> stream;
    const auto result = builder.openStream(stream);
    if (result != oboe::Result::OK || !stream) {
        const std::string text = "FAIL|" + resultText(result);
        return env->NewStringUTF(text.c_str());
    }

    std::ostringstream out;
    out << "PASS"
        << "|api=" << (stream->usesAAudio() ? "AAudio" : "OpenSLES")
        << "|sampleRate=" << stream->getSampleRate()
        << "|framesPerBurst=" << stream->getFramesPerBurst()
        << "|bufferCapacityFrames=" << stream->getBufferCapacityInFrames();
    stream->close();
    const auto text = out.str();
    return env->NewStringUTF(text.c_str());
}
